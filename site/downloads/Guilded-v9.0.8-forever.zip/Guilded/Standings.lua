-- No guild data is shipped. Your paired companion supplies this file.
GuildedStandings = { updatedAt = nil, baseGp = 0, players = {} }
GuildedLedgerAccepted = {}
GuildedItems = nil
GuildedLoot = nil
GuildedNextRaid = nil
GuildedRaids = nil
GuildedDungeonAccepted = {}
GuildedDungeonBoard = nil
