-- Guilded is intentionally manual-first. Combat and loot events are hints, not proof.
local addonName, ns = ...
ns = ns or {}
Guilded = ns

local PREFIX = "Guilded"
local DB_VERSION = 4
-- SavedVariables are rewritten on every logout; unbounded journals slowly
-- make login/logout (and the companion's parse) slower for months, so the
-- informational logs are capped. The EPGP ledger is NOT capped: the
-- companion identifies entries by id/position and it is the audit trail.
local MAX_EVENTS = 1000
-- (9.3.8) The SavedVariables file grew past 3 MB; these logs are only history, so they age out too.
-- The audit log (GuildedDB.events) is read by nothing; parked guilds keep a short tail of both logs.
local EVENT_KEEP_DAYS = 30
local PARKED_EVENT_KEEP = 100
local PARKED_LOG_KEEP = 300
local PARKED_LOG_DAYS = 90
-- A parked guild nobody played in for this long, with no points and no unsent dungeon run, is forgotten.
local PARKED_GUILD_DAYS = 180
local MAX_EXPORT_MARKERS = 10
local MAX_EPGP_AMOUNT = 100000
-- Addon messages longer than 255 bytes are rejected by the client.
local MAX_ADDON_MESSAGE = 255
-- Another officer's award heard in the group counts toward priority until Discord has it, at
-- most this long (their companion normally uploads it within minutes).
local PEER_LEDGER_SECONDS = 12 * 60 * 60
local MAX_PEER_LEDGER = 500
local db
local ledgerRoster
local activeRaid

local function L(text) return ns.L and ns.L(text) or text end

local function now()
  return date("!%Y-%m-%dT%H:%M:%SZ")
end

local function playerName()
  if ns.util and ns.util.unitKey then return ns.util.unitKey("player") or "Unknown" end
  local name = UnitName("player")
  -- Same spelling as everyone else's entry for you (no realm part).
  if type(name) == "string" and not (issecretvalue ~= nil and issecretvalue(name) == true) then
    name = string.match(name, "^([^%-%s]+)") or name
  end
  return name or "Unknown"
end

local function message(text)
  -- The optional Guilded chat tab (Modules/ChatTab.lua), otherwise the main chat window.
  local tab = ns.chatFrame and select(2, pcall(ns.chatFrame)) or nil
  local frame = (type(tab) == "table" and tab.AddMessage) and tab or DEFAULT_CHAT_FRAME
  frame:AddMessage("|cffd4af37[Guilded]|r " .. tostring(text))
  -- Lets the tools panel show the latest result without reading chat.
  if ns.onMessage then pcall(ns.onMessage, tostring(text)) end
end

-- Midnight-era clients can hand addons "secret" values (e.g. chat text during
-- boss encounters) that error when compared or pattern-matched.
local function isSecret(value)
  return issecretvalue ~= nil and issecretvalue(value) == true
end

-- One canonical spelling per character, so "bob", "Bob" and "Bob-Realm"
-- (addon-message senders and guild roster names carry the realm) never end
-- up as separate ledger, roster, or attendance entries. Only ASCII letters
-- change case; accented names pass through untouched.
local function normalizeName(name)
  if ns.util and ns.util.characterKey then return ns.util.characterKey(name) end
  if type(name) ~= "string" or isSecret(name) then return nil end
  name = string.match(name, "^%s*(.-)%s*$")
  -- Fallback only (Util.lua normally answers): the pre-8.5 first-name key.
  name = string.match(name, "^([^%-%s]+)") or name
  if name == "" then return nil end
  return string.upper(string.sub(name, 1, 1)) .. string.lower(string.sub(name, 2))
end

local function defaultSettings()
  return {
    officerRanks = { [0] = true, [1] = true },
    officers = {},
    announceChannel = "RAID",
    captureLoot = true,
    -- The one-line result after each of my duels (Modules/Duels.lua); /guilded duels line off sets it to false.
    duelLine = true
  }
end

local function asTable(value)
  if type(value) == "table" then return value end
  return {}
end

-- History, reports and the active-raid resume walk raids as an array. Older
-- saves used id -> raid, which made #raids == 0 and dropped the open raid.
local function asRaidList(value)
  if type(value) ~= "table" then return {} end
  local count = #value
  local list = {}
  for i = 1, count do list[i] = value[i] end
  for key, raid in pairs(value) do
    if type(key) ~= "number" or key < 1 or key > count or key ~= math.floor(key) then
      list[#list + 1] = raid
    end
  end
  return list
end

local function isoDaysAgo(days)
  return date("!%Y-%m-%dT%H:%M:%SZ", time() - days * 86400)
end

-- Drops the oldest entries of a list written oldest-first: too many, or older than `isOld` says.
local function trimOldest(list, keep, isOld)
  if type(list) ~= "table" then return end
  while #list > keep or (list[1] ~= nil and isOld and isOld(list[1])) do table.remove(list, 1) end
end

local function hasUnsyncedRun(parked)
  local runs = type(parked.dungeon) == "table" and parked.dungeon.runs
  for _, run in pairs(type(runs) == "table" and runs or {}) do
    if type(run) == "table" and not run.synced then return true end
  end
  return false
end

local function hasPoints(parked)
  for field, value in pairs(parked) do
    if (field == "epgp" or field == "dkp" or string.find(string.lower(tostring(field)), "ledger", 1, true)) and type(value) == "table" and next(value) ~= nil then return true end
  end
  return false
end

-- (9.3.8) Keeps GuildedDB from growing for ever: the audit log by age, the data parked for other guilds by a short tail of their logs,
-- and a parked guild nobody has played in for half a year (when it holds no points and no run the bot has not confirmed). The loaded
-- guild's own data (roster, ledger, raids, runs) is never touched here.
local function trimBulk(root)
  if type(root) ~= "table" then return end
  local oldIso = isoDaysAgo(EVENT_KEEP_DAYS)
  trimOldest(root.events, MAX_EVENTS, function(event) return type(event) == "table" and type(event.at) == "string" and event.at < oldIso end)
  if type(root.otherGuilds) ~= "table" then return end
  local oldAt = time() - PARKED_LOG_DAYS * 86400
  local forget = time() - PARKED_GUILD_DAYS * 86400
  for key, parked in pairs(root.otherGuilds) do
    if type(parked) ~= "table" then
      root.otherGuilds[key] = nil
    else
      -- Parked data written before this stamp existed starts its half year now.
      if type(parked.parkedAt) ~= "number" then parked.parkedAt = time() end
      if parked.parkedAt < forget and not hasUnsyncedRun(parked) and not hasPoints(parked) then
        root.otherGuilds[key] = nil
      else
        -- (audit) A leftover already folded into the real key (mergedIntoHome: the blank-realm "Guild-" copy, an old spaced
        -- spelling) keeps its records but not the copies of what the companion and guildmates rebuild: the standings
        -- board was 1.5 MB of the owner's 4.3 MB saved file. The real key has its own.
        if parked.mergedIntoHome then
          parked.dungeonBoard, parked.standings, parked.peerRoster = nil, nil, nil
        end
        trimOldest(parked.events, PARKED_EVENT_KEEP)
        if type(parked.guildLog) == "table" then
          trimOldest(parked.guildLog.events, PARKED_LOG_KEEP, function(event) return type(event) == "table" and type(event.at) == "number" and event.at < oldAt end)
        end
      end
    end
  end
end
ns.trimBulk = trimBulk

local function ensureDb()
  -- Early builds saved under the old name; adopt that data once. A non-table
  -- value (a damaged SavedVariables file) is not usable and must not be indexed.
  if type(GuildedDB) ~= "table" and type(_G.QuebecGoldDB) == "table" then
    GuildedDB = _G.QuebecGoldDB
    _G.QuebecGoldDB = nil
  end
  if type(GuildedDB) ~= "table" then GuildedDB = {} end
  db = GuildedDB
  db.version = DB_VERSION
  db.addonVersion = (C_AddOns and C_AddOns.GetAddOnMetadata and C_AddOns.GetAddOnMetadata(addonName, "Version")) or (GetAddOnMetadata and GetAddOnMetadata(addonName, "Version")) or "6.1.0"
  -- Fill in any setting missing from an older saved file instead of only
  -- creating settings when the whole table is absent.
  db.settings = asTable(db.settings)
  for key, value in pairs(defaultSettings()) do
    if db.settings[key] == nil then db.settings[key] = value end
  end
  db.raids = asRaidList(db.raids)
  db.roster = asTable(db.roster)
  db.attendance = asTable(db.attendance)
  db.bosses = asTable(db.bosses)
  db.epgp = asTable(db.epgp)
  if type(db.dkp) == "table" then
    for name, old in pairs(db.dkp) do
      db.epgp[name] = db.epgp[name] or { ep = 0, gp = 0, ledger = {} }
      for _, entry in pairs(old.ledger or {}) do
        table.insert(db.epgp[name].ledger, {
          epAmount = entry.amount, gpAmount = 0, type = "IMPORT",
          reason = "Legacy DKP: " .. tostring(entry.reason or "Imported"),
          at = entry.at, by = entry.by, raid = entry.raid
        })
      end
      db.epgp[name].ep = db.epgp[name].ep + (old.balance or 0)
    end
    db.dkp = nil
  end
  db.ledgerSeq = tonumber(db.ledgerSeq) or 0
  -- Other officers' awards not in the Discord standings yet: [ledger id] = { name, ep, gp, coreId, by, at }.
  db.peerLedger = asTable(db.peerLedger)
  local peerCutoff = (GetServerTime and GetServerTime() or time()) - PEER_LEDGER_SECONDS
  for id, peer in pairs(db.peerLedger) do
    if type(peer) ~= "table" or (tonumber(peer.at) or 0) < peerCutoff then db.peerLedger[id] = nil end
  end
  db.readiness = asTable(db.readiness)
  db.attunements = asTable(db.attunements)
  -- Diagnostics: blocked-action reports (ADDON_ACTION_BLOCKED/FORBIDDEN,
  -- which name the exact function WoW refused to let an addon call) and
  -- captured Lua errors. See /guilded diag.
  db.diagnostics = asTable(db.diagnostics)
  -- Roster digests broadcast by other guildmates' clients (gear/profession
  -- summary only, not full detail) so one officer's export can carry the
  -- whole online guild's readiness picture, not just their own.
  db.peerRoster = asTable(db.peerRoster)
  -- (9.0.10) One name per profession whatever the game language ("Cuisine" and "Cooking" were two): fix older saved data.
  if ns.util and ns.util.normalizeProfessionData then pcall(ns.util.normalizeProfessionData, db) end
  db.loot = asTable(db.loot)
  -- Raid templates: name -> { title, coreId } (/guilded template).
  db.raidTemplates = asTable(db.raidTemplates)
  -- Who was actually in the raid group during each raid: [raidId][name] =
  -- { firstSeen, lastSeen }. Filled automatically while a raid is active.
  db.presence = asTable(db.presence)
  db.events = asTable(db.events)
  trimBulk(db)
  -- Older versions stored a full copy of the database per export, which
  -- the SavedVariables writer duplicates on disk every time. Keep markers only.
  db.exports = asTable(db.exports)
  for key, value in pairs(db.exports) do
    if type(value) == "table" and value.roster then db.exports[key] = { exportedAt = key } end
  end

  -- A raid survives /reload and disconnects: without this, a crash mid-raid
  -- left the raid open forever and every later attendance call failed.
  activeRaid = nil
  if db.activeRaidId then
    for _, raid in ipairs(db.raids) do
      if raid.id == db.activeRaidId and not raid.endedAt then activeRaid = raid end
    end
    if not activeRaid then db.activeRaidId = nil end
  end
end

-- The roster keeps everyone the addon has met. Only entries the guild roster confirmed are
-- guild members: raid pugs are kept (attendance history needs them) with inGuild = false,
-- and a member who leaves the guild is marked inGuild = false the next time the roster loads.
-- Entries from before this field existed have no inGuild and count as members.
local function noteSeen(name)
  if not db.roster[name] then db.roster[name] = { firstSeen = now(), inGuild = false } end
end

local function isGuildMember(name)
  name = normalizeName(name)
  local entry = name and db and db.roster[name]
  return entry ~= nil and entry.inGuild ~= false
end

local function logEvent(kind, payload)
  table.insert(db.events, {
    at = now(), kind = kind, player = playerName(), data = payload
  })
  if #db.events > MAX_EVENTS then table.remove(db.events, 1) end
  -- Something worth saving happened: tell the sync module (Modules/SyncNow.lua).
  if ns.syncNow and ns.syncNow.mark then ns.syncNow.mark() end
end

-- Records a diagnostic entry (blocked action or captured Lua error) so it
-- survives past the moment it happened -- the in-game popup for a blocked
-- action disappears without saying which function was blocked, and a
-- regular Lua error can scroll off before anyone reads it. /guilded diag prints
-- the last few of these.
-- `foreign` marks noise from other addons (recorded quietly, evicted first).
-- Consecutive identical entries collapse into one with a count, so an
-- unrelated addon erroring every few seconds can't flood the log.
-- Anything reported before the saved database exists (which is exactly when a
-- load-time blocked-action popup fires) is held here and flushed on login,
-- instead of being silently dropped.
local pendingDiagnostics = {}

local function logDiagnostic(kind, detail, foreign)
  if not db then
    if #pendingDiagnostics < 25 then
      table.insert(pendingDiagnostics, { kind = kind, detail = detail, foreign = foreign })
    end
    return
  end
  db.diagnostics = db.diagnostics or {}
  local list = db.diagnostics
  local last = list[#list]
  if last and last.kind == kind and last.detail == detail then
    last.count = (last.count or 1) + 1
    last.at = now()
    return
  end
  table.insert(list, { at = now(), kind = kind, detail = detail, count = 1, foreign = foreign or false })
  while #list > 25 do
    local removeIndex = 1
    for i = 1, #list do
      if list[i].foreign then
        removeIndex = i
        break
      end
    end
    table.remove(list, removeIndex)
  end
  -- Slow-handler timings are recorded quietly; only real problems print.
  if not foreign and kind ~= "SLOW" and kind ~= "SEND" and kind ~= "RECIPES" then
    message("|cffff5555[Diagnostic]|r " .. kind .. ": " .. detail .. " (see /guilded diag)")
  end
end

-- Records Lua errors (other addons' errors are kept quietly as "foreign")
-- and always chains to the previous handler, so BugSack/the default error
-- frame keep working. The recording itself is pcall-guarded: an error inside
-- an error handler would hide the original error.
local previousErrorHandler = geterrorhandler and geterrorhandler()
if seterrorhandler then
  seterrorhandler(function(err)
    pcall(function()
      local text = tostring(err)
      logDiagnostic("LUA_ERROR", text, not string.find(text, "Guilded", 1, true))
    end)
    if previousErrorHandler then return previousErrorHandler(err) end
  end)
end

local function isOfficer()
  if not db then return false end
  local name = playerName()
  -- No guild, no officer status: a name left in the officer list (or a rank number) means nothing without a guild.
  if IsInGuild and not IsInGuild() then return false end
  if db.settings.officers[name] then return true end
  local _, _, rankIndex = GetGuildInfo("player")
  return rankIndex ~= nil and db.settings.officerRanks[rankIndex] == true
end

local function isGuildMaster()
  local _, _, rankIndex = GetGuildInfo("player")
  return rankIndex == 0
end

-- Rank check for someone else, from the guild roster (used to decide whether
-- to trust an officer-only message another client broadcast).
local function isOfficerName(name)
  name = normalizeName(name)
  if not db or not name then return false end
  if db.settings.officers[name] then return true end
  if not GetNumGuildMembers or not GetGuildRosterInfo then return false end
  for i = 1, GetNumGuildMembers() do
    local rosterName, _, rankIndex = GetGuildRosterInfo(i)
    if normalizeName(rosterName) == name then
      return rankIndex ~= nil and db.settings.officerRanks[rankIndex] == true
    end
  end
  return false
end

local function requireOfficer()
  if not isOfficer() then
    message(L("Officer or guild-master rank is required for this command."))
    return false
  end
  return true
end

-- Splits on whitespace but keeps "double quoted phrases" together, so
-- /guilded attune Bob "Onyxia Key" works as documented.
local function split(text)
  local result = {}
  text = text or ""
  local pos = 1
  while true do
    local s = string.find(text, "%S", pos)
    if not s then break end
    if string.sub(text, s, s) == '"' then
      local e = string.find(text, '"', s + 1, true)
      table.insert(result, string.sub(text, s + 1, (e or 0) - 1))
      if not e then break end
      pos = e + 1
    else
      local e = string.find(text, "%s", s)
      table.insert(result, string.sub(text, s, (e or 0) - 1))
      if not e then break end
      pos = e
    end
  end
  return result
end

-- Shared helpers and the paced message queue live in Util.lua (loaded first).
local util = ns.util
local comm = ns.comm

-- Sending can be refused (not in a group, throttled, encounter lockdown);
-- none of that should ever break the command that triggered it.
local function send(messageText, target)
  comm.send(PREFIX, messageText, target or "RAID")
end

local function registerPrefix()
  comm.register(PREFIX)
end

-- Assigned below groupMembers(); declared here so raid start/end can use it.
local recordPresence
-- Assigned below (needs the export box); raidEnd prints it.
local raidSummaryLines

local function raidStart(title)
  if activeRaid then
    message(string.format(L("Raid '%s' is still active. Use /guilded end first."), activeRaid.title))
    return
  end
  if not title or title == "" then title = "Raid" end
  -- A saved template ("/guilded start Tuesday MC") brings its title and selects its raid core.
  -- The Raid page saves "Tuesday MC" as tuesday-mc, so both spellings find it.
  local key = string.lower(title)
  local template = db.raidTemplates and (db.raidTemplates[key] or db.raidTemplates[(string.gsub(key, "%s+", "-"))])
  if template then
    title = template.title or title
    if template.coreId and ns.loot and ns.loot.core and ns.runCommand then pcall(ns.runCommand, "core " .. template.coreId) end
  end
  activeRaid = {
    -- Server clock, so ids and times from different officers' clients agree.
    id = tostring(util.serverTime()) .. "-" .. playerName(),
    title = title,
    startedAt = now(), endedAt = nil, startedBy = playerName()
  }
  local core = ns.loot and ns.loot.core and ns.loot.core()
  if core then activeRaid.coreId = core.id end
  table.insert(db.raids, activeRaid)
  recordPresence()
  db.activeRaidId = activeRaid.id
  if ns.loot and ns.loot.pricingContext then ns.loot.pricingContext() end
  logEvent("RAID_START", { id = activeRaid.id, title = activeRaid.title })
  send("RAID_START|" .. activeRaid.id .. "|" .. activeRaid.title)
  message(string.format(L("Started raid: %s"), activeRaid.title))
end

local function raidEnd()
  if not activeRaid then message(L("No active raid.")); return end
  if ns.council and ns.council.current and ns.council.current.pricing then
    message(L("Award or cancel the current priced item before ending this raid.")); return
  end
  recordPresence()
  activeRaid.endedAt = now()
  logEvent("RAID_END", { id = activeRaid.id })
  send("RAID_END|" .. activeRaid.id)
  message(string.format(L("Ended raid: %s"), activeRaid.title))
  local ended = activeRaid
  activeRaid = nil
  db.activeRaidId = nil
  -- What was recorded, so the officer can check it before logging out (/guilded summary to copy).
  if raidSummaryLines then
    for _, line in ipairs(raidSummaryLines(ended)) do message(line) end
    message(L("/guilded summary opens it to copy into Discord or a forum."))
  end
end

local function setAttendance(name, status, quiet)
  if not activeRaid then message(L("Start a raid first.")); return end
  name = normalizeName(name) or playerName()
  status = string.upper(status or "PRESENT")
  if status ~= "PRESENT" and status ~= "ABSENT" and status ~= "LATE" then
    message(L("Status must be PRESENT, ABSENT, or LATE.")); return
  end
  db.attendance[activeRaid.id] = db.attendance[activeRaid.id] or {}
  db.attendance[activeRaid.id][name] = { status = status, at = now(), by = playerName() }
  noteSeen(name)
  logEvent("ATTENDANCE", { raid = activeRaid.id, name = name, status = status })
  send("ATTENDANCE|" .. activeRaid.id .. "|" .. name .. "|" .. status)
  if not quiet then message(name .. " marked " .. status .. ".") end
  return true
end

local function bossKill(name)
  if not activeRaid then message(L("Start a raid first.")); return end
  if not name or name == "" then message(L("Usage: /guilded boss <name>")); return end
  db.bosses[activeRaid.id] = db.bosses[activeRaid.id] or {}
  table.insert(db.bosses[activeRaid.id], { name = name, at = now(), by = playerName() })
  logEvent("BOSS_KILL", { raid = activeRaid.id, boss = name })
  send("BOSS_KILL|" .. activeRaid.id .. "|" .. name)
  message(string.format(L("Recorded boss kill: %s"), name))
end

local EPGP_KINDS = {
  EP_AWARD = { command = "award", ep = 1, gp = 0 },
  GP_AWARD = { command = "gp", ep = 0, gp = 1 },
  ADJUSTMENT = { command = "deduct", ep = -1, gp = 0 },
  -- Takes GP back (a mistaken charge, a returned item). Stored as an
  -- ADJUSTMENT with a negative GP amount, which the bot already imports.
  GP_DEDUCT = { command = "gpdeduct", ep = 0, gp = -1, type = "ADJUSTMENT" }
}

-- Every ledger entry gets a permanent unique id. The companion sends it to
-- the bot, which uses it to skip entries it already imported: each export
-- carries the whole ledger, so without ids every import would re-add them.
local function nextLedgerId()
  db.ledgerSeq = (db.ledgerSeq or 0) + 1
  return string.format("%s-%d-%d", playerName(), util.serverTime(), db.ledgerSeq)
end

-- The downloaded ledger is a baseline. Only new, unacknowledged local entries are
-- overlaid, so loot priority changes immediately and does not double on the next sync.
function ns.effectiveStanding(rawName, coreId)
  local name = normalizeName(rawName)
  local s = db and db.standings
  local players, baseGp = s and s.players, s and s.baseGp or 0
  if coreId then
    players = nil
    for _, core in ipairs(db and db.lootRules and db.lootRules.cores or {}) do
      if core.id == coreId then players, baseGp = core.players, core.baseGp or 0; break end
    end
  end
  -- (9.0) Older standings may still hold this character under its first name only.
  local baselineKey = players and util.findCharacterKey(players, name)
  local baseline = baselineKey and players[baselineKey]
  local ep, gp = baseline and baseline.ep or 0, baseline and baseline.gp or 0
  local accepted = db and db.acceptedLedgerRefs or {}
  for character, account in pairs(db and db.epgp or {}) do
    local other = players and players[character]
    local sameAccount = character == name or character == baselineKey or (baseline and baseline.account and other and other.account == baseline.account)
    if sameAccount then
      for _, entry in ipairs(account.ledger or {}) do
        local samePool = (entry.coreId or "") == (coreId or "")
        local ref = "addon:qg:" .. tostring(entry.id)
        local includedInLocalPublish = not coreId and s and s.localPublish == true and db.localPublishedRefs and db.localPublishedRefs[entry.id]
        if samePool and entry.voided then
          -- Voided in game (/guilded void). One the standings already count is taken back out
          -- until Discord's reversal arrives; one Discord never had simply does not count.
          local counted = entry.wasCounted or accepted[ref] or includedInLocalPublish
          if baseline and counted and not entry.voidAcked and not accepted["void:" .. ref] then
            ep, gp = ep - (entry.epAmount or 0), gp - (entry.gpAmount or 0)
          end
        elseif samePool and (not baseline or (entry.pending and not accepted[ref] and not includedInLocalPublish)) then
          ep, gp = ep + (entry.epAmount or 0), gp + (entry.gpAmount or 0)
        end
      end
      -- Old standalone data can contain balances without a ledger.
      if not baseline and not coreId and #(account.ledger or {}) == 0 then ep, gp = ep + (account.ep or 0), gp + (account.gp or 0) end
    end
  end
  -- Awards another officer made in this raid (heard in the group, see handlePeerLedger): two
  -- officers handing out loot see each other's GP at once, not after both companions synced.
  local nowSeconds = util.serverTime()
  for id, peer in pairs(db and db.peerLedger or {}) do
    if (peer.coreId or "") == (coreId or "") and not accepted["addon:qg:" .. tostring(id)]
      and nowSeconds - (tonumber(peer.at) or 0) < PEER_LEDGER_SECONDS then
      local other = players and players[peer.name]
      if peer.name == name or (baseline and baseline.account and other and other.account == baseline.account) then
        ep, gp = ep + (tonumber(peer.ep) or 0), gp + (tonumber(peer.gp) or 0)
      end
    end
  end
  -- GP counts as at least 1, as in EPGP (Modules/Sync.lua, src/services/epgp.ts).
  return { ep = ep, gp = gp, pr = ep / math.max(1, gp + math.max(0, baseGp)) }
end

local function changeEpgp(rawName, rawAmount, reason, kind, quiet)
  local spec = EPGP_KINDS[kind]
  local name = normalizeName(rawName)
  -- Rounded before it is checked: 0.4 rounds to 0, and a zero entry is not a ledger entry
  -- (Discord refuses one).
  local amount = tonumber(rawAmount)
  if amount then amount = math.floor(amount + 0.5) end
  if not name or not amount or amount <= 0 or amount > MAX_EPGP_AMOUNT then
    message(string.format(L("Usage: /guilded %s <player> <amount 1-%d> [reason]"), spec.command, MAX_EPGP_AMOUNT)); return
  end
  -- The bot requires a reason of at least 3 characters on import.
  if not reason or string.len(reason) < 3 then reason = "Manual adjustment" .. (reason and reason ~= "" and (": " .. reason) or "") end
  db.epgp[name] = db.epgp[name] or { ep = 0, gp = 0, ledger = {} }
  local account = db.epgp[name]
  local core = ns.loot and ns.loot.core()
  local coreId = core and core.pool and core.id or nil
  -- A guild that keeps points per raid core has no guild pool: Discord would hold this entry
  -- back, so it is refused here, where the officer can still pick the core.
  local lootRules = ns.getLootRules and ns.getLootRules()
  if lootRules and lootRules.coreOnly and not coreId then
    message(L("This guild keeps EP and GP per raid core. Pick the core first: /guilded core <name>."))
    return
  end
  local standing = ns.effectiveStanding(name, coreId)
  if spec.gp < 0 then
    -- GP never goes below zero: deduct at most what the player has.
    if standing.gp <= 0 then message(name .. " has no GP to deduct."); return end
    amount = math.min(amount, standing.gp)
  end
  local epAmount, gpAmount = spec.ep * amount, spec.gp * amount
  if not coreId then
    account.ep = account.ep + epAmount
    account.gp = account.gp + gpAmount
  end
  local id = nextLedgerId()
  table.insert(account.ledger, {
    id = id, pending = true, coreId = coreId, epAmount = epAmount, gpAmount = gpAmount, type = spec.type or kind, reason = reason,
    at = now(), by = playerName(), raid = activeRaid and activeRaid.id
  })
  logEvent(spec.type or kind, { name = name, epAmount = epAmount, gpAmount = gpAmount, reason = reason })
  -- Other officers in the group count it at once (handlePeerLedger).
  local channel = util.groupChannel()
  if channel then comm.send(PREFIX, string.format("LEDGER|%s|%s|%d|%d|%s", id, name, epAmount, gpAmount, coreId or ""), channel, nil, nil, "interactive") end
  if not quiet then
    -- The totals of the pool the entry went to (a core's own pool, or the guild's).
    local after = ns.effectiveStanding(name, coreId)
    message(string.format("%s EP %d, GP %d (%s), PR %.3f.", name, after.ep, after.gp, reason, after.pr))
  end
  return true
end

local function describeEntry(name, entry)
  local parts = {}
  if (entry.epAmount or 0) ~= 0 then table.insert(parts, string.format("%+d EP", entry.epAmount)) end
  if (entry.gpAmount or 0) ~= 0 then table.insert(parts, string.format("%+d GP", entry.gpAmount)) end
  return string.format("%s %s (%s)", name, table.concat(parts, ", "), tostring(entry.reason or ""))
end

-- /guilded void [player | last]: takes back the newest entry you made (for that player, or of
-- all). The ledger is never edited: the entry stays, marked voided. Discord never imports a
-- voided entry it did not have yet, and reverses one it already had.
local function voidEntry(target)
  local wanted = target and target ~= "" and string.lower(target) ~= "last" and normalizeName(target) or nil
  local function seq(entry) return tonumber(string.match(tostring(entry.id or ""), "%-(%d+)$")) or 0 end
  local foundName, found
  for name, account in pairs(db.epgp) do
    if not wanted or name == wanted then
      for _, entry in ipairs(account.ledger or {}) do
        -- An author can recover their own entries from another officer and still void them.
        local fromOtherAuthor = entry.fromPeer and entry.by ~= playerName()
        if entry.id and not entry.voided and not fromOtherAuthor and (not found or seq(entry) > seq(found)) then foundName, found = name, entry end
      end
    end
  end
  if not found then
    message(wanted and string.format("%s has no ledger entry to void.", wanted) or "There is no ledger entry to void.")
    return
  end
  -- Already in Discord's standings (sent and accepted) or still only on this PC?
  found.wasCounted = not found.pending
  found.voided, found.voidedBy, found.pending = now(), playerName(), nil
  if not found.coreId then
    local account = db.epgp[foundName]
    account.ep = (account.ep or 0) - (found.epAmount or 0)
    account.gp = (account.gp or 0) - (found.gpAmount or 0)
  end
  logEvent("VOID", { name = foundName, id = found.id, epAmount = found.epAmount, gpAmount = found.gpAmount })
  local channel = util.groupChannel()
  if channel then comm.send(PREFIX, "LEDGERVOID|" .. found.id, channel, nil, nil, "interactive") end
  message(string.format(L("Voided: %s. Discord takes it back with the next upload."), describeEntry(foundName, found)))
  return true
end

-- LEDGER|<id>|<player>|<ep>|<gp>|<core id> and LEDGERVOID|<id>, from an officer in your group.
-- Only officers keep them (they decide loot), and only until Discord has the entry.
local function handlePeerLedger(text, channel, sender)
  if channel ~= "RAID" and channel ~= "PARTY" then return end
  local author = normalizeName(sender)
  if not author or not isOfficer() or not isOfficerName(author) or not util.inMyGroup(sender) then return end
  local voidedId = string.match(text, "^LEDGERVOID|([^|]+)$")
  if voidedId then
    local peer = db.peerLedger[voidedId]
    if peer and peer.by == author then db.peerLedger[voidedId] = nil end
    if ns.onLootChange then pcall(ns.onLootChange) end
    return
  end
  local id, name, ep, gp, coreId = string.match(text, "^LEDGER|([^|]+)|([^|]+)|(%-?%d+)|(%-?%d+)|([^|]*)$")
  ep, gp, name = tonumber(ep), tonumber(gp), normalizeName(name)
  if not id or not name or not ep or not gp or (ep == 0 and gp == 0) then return end
  -- A ledger id starts with its author's name: nobody speaks for another officer's ledger.
  if string.sub(id, 1, #author + 1) ~= author .. "-" then return end
  if math.abs(ep) > MAX_EPGP_AMOUNT or math.abs(gp) > MAX_EPGP_AMOUNT then return end
  if not db.peerLedger[id] then
    local count = 0
    for _ in pairs(db.peerLedger) do count = count + 1 end
    if count >= MAX_PEER_LEDGER then return end
  end
  db.peerLedger[id] = { name = name, ep = ep, gp = gp, coreId = coreId ~= "" and coreId or nil, by = author, at = util.serverTime() }
  if ns.onLootChange then pcall(ns.onLootChange) end
end

-- Everyone in your current raid or party, plus you, as normalized names.
local function groupMembers()
  local names, seen = {}, {}
  local function add(name)
    name = normalizeName(name)
    if name and not seen[name] then
      seen[name] = true
      table.insert(names, name)
    end
  end
  add(playerName())
  if IsInRaid and IsInRaid() and GetNumGroupMembers and GetRaidRosterInfo then
    for i = 1, GetNumGroupMembers() do add((GetRaidRosterInfo(i))) end
  elseif IsInGroup and IsInGroup() then
    for i = 1, 4 do
      if UnitExists("party" .. i) then add((UnitName("party" .. i))) end
    end
  end
  return names
end

-- /guilded attendance group [status]: one command for the whole raid.
recordPresence = function()
  if not activeRaid then return end
  db.presence[activeRaid.id] = db.presence[activeRaid.id] or {}
  local seen = db.presence[activeRaid.id]
  for _, name in ipairs(groupMembers()) do
    seen[name] = seen[name] or { firstSeen = now() }
    seen[name].lastSeen = now()
    noteSeen(name)
  end
end

-- /guilded attendance seen: PRESENT for everyone who was in the group at any
-- point during this raid, without overwriting anything already recorded
-- (so a manual LATE or ABSENT stays).
local function seenAttendance()
  if not activeRaid then message(L("Start a raid first.")); return end
  recordPresence()
  local recorded = db.attendance[activeRaid.id] or {}
  local count = 0
  for name in pairs(db.presence[activeRaid.id] or {}) do
    if not recorded[name] and setAttendance(name, "PRESENT", true) then count = count + 1 end
    recorded = db.attendance[activeRaid.id]
  end
  message(string.format(L("Marked %d more player(s) PRESENT from who was in the raid group."), count))
end

-- /guilded attendance roster: the selected raid core's roster against who is in the group:
-- PRESENT for its players here, ABSENT for its mains who are not (bench players are left as
-- they are). Anything already recorded stays.
local function rosterAttendance()
  if not activeRaid then message(L("Start a raid first.")); return end
  local core = ns.loot and ns.loot.core and ns.loot.core()
  if not (core and core.roster and #core.roster > 0 and ns.loot.rosterCheck) then
    -- Seen in game: a Discord core with no roster yet was told to use the Local guild page.
    if not core then message(L("Choose a raid core first: /guilded core <name>."))
    elseif core.localOnly then message((core.name or "This core") .. " has no raiders yet: add them on the Local guild page (step 3).")
    else message((core.name or "This core") .. " has no roster from Discord yet; it comes with the companion upload.") end
    return
  end
  recordPresence()
  local check = ns.loot.rosterCheck(core, groupMembers())
  local recorded = db.attendance[activeRaid.id] or {}
  local present, absent = 0, 0
  for _, row in ipairs(check.present) do
    if not recorded[row.name] and setAttendance(row.name, "PRESENT", true) then present = present + 1 end
    recorded = db.attendance[activeRaid.id] or {}
  end
  for _, row in ipairs(check.missing) do
    if not recorded[row.name] and setAttendance(row.name, "ABSENT", true) then absent = absent + 1 end
    recorded = db.attendance[activeRaid.id] or {}
  end
  message(string.format("%s roster: %d marked PRESENT, %d mains marked ABSENT, %d on the bench, %d fill-ins not on the roster.",
    core.name or "Core", present, absent, #check.bench, #check.fillIns))
end

-- /guilded note <text>: a note on the running raid (shown in its summary).
local function raidNote(text)
  if not activeRaid then message(L("Start a raid first.")); return end
  text = string.gsub(text or "", "[|%c]", "")
  if text == "" then message(L("Usage: /guilded note <text>")); return end
  activeRaid.notes = activeRaid.notes or {}
  table.insert(activeRaid.notes, { at = now(), by = playerName(), text = string.sub(text, 1, 200) })
  logEvent("RAID_NOTE", { raid = activeRaid.id, text = text })
  message(string.format(L("Note added to %s."), activeRaid.title))
end

-- /guilded template save <name> [title] | list | remove <name>
local function raidTemplate(args)
  local sub = string.lower(args[2] or "")
  if sub == "save" and args[3] then
    local name = string.lower(args[3])
    local title = table.concat(args, " ", 4)
    if title == "" then title = activeRaid and activeRaid.title or args[3] end
    local core = ns.loot and ns.loot.core and ns.loot.core()
    db.raidTemplates[name] = { title = title, coreId = core and core.id or nil }
    message(string.format(L("Template %s saved: %s%s. Start it with /guilded start %s."), args[3], title,
      core and string.format(L(" (core %s)"), core.name or core.id) or "", args[3]))
  elseif sub == "remove" and args[3] then
    db.raidTemplates[string.lower(args[3])] = nil
    message(string.format(L("Template %s removed."), args[3]))
  else
    local names = {}
    for name, t in pairs(db.raidTemplates) do table.insert(names, name .. " (" .. (t.title or name) .. ")") end
    table.sort(names)
    message(#names > 0 and ("Raid templates: " .. table.concat(names, ", ")) or "No raid templates yet: /guilded template save <name> [title] (uses the selected raid core).")
  end
end

-- /guilded raid discard: drops a raid started by mistake, only while nothing was recorded in it.
local function discardRaid()
  if not activeRaid then message(L("No active raid.")); return end
  local id = activeRaid.id
  local function has(t) return t and next(t) ~= nil end
  local entries = 0
  for _, account in pairs(db.epgp or {}) do
    for _, entry in ipairs(account.ledger or {}) do if entry.raid == id and not entry.voided then entries = entries + 1 end end
  end
  local loot = 0
  for _, row in ipairs(db.loot or {}) do if row.raid == id then loot = loot + 1 end end
  if has(db.attendance[id]) or has(db.bosses[id]) or entries > 0 or loot > 0 then
    message(L("This raid already has attendance, bosses, EP/GP or loot: end it with /guilded end instead."))
    return
  end
  for i = #db.raids, 1, -1 do if db.raids[i].id == id then table.remove(db.raids, i) end end
  db.presence[id] = nil
  logEvent("RAID_DISCARD", { id = id })
  send("RAID_END|" .. id)
  message(string.format(L("Discarded the raid %s (nothing was recorded in it)."), activeRaid.title))
  activeRaid = nil
  db.activeRaidId = nil
end

local function groupAttendance(status)
  if not activeRaid then message(L("Start a raid first.")); return end
  local count = 0
  for _, name in ipairs(groupMembers()) do
    if setAttendance(name, status or "PRESENT", true) then count = count + 1 end
  end
  message(string.format(L("Marked %d group member(s) %s."), count, string.upper(status or "PRESENT")))
end

-- /guilded snapshot [label]: a named "who is here right now" (pre-pull, after a
-- boss...). It also records presence for the active raid, so it counts toward
-- attendance, and is kept (last 50) for disputes: /guilded snapshot list.
local function takeSnapshot(label)
  local names = groupMembers()
  db.snapshots = db.snapshots or {}
  table.insert(db.snapshots, { at = now(), label = label or "", raid = activeRaid and activeRaid.id or nil, names = names })
  while #db.snapshots > 50 do table.remove(db.snapshots, 1) end
  if activeRaid then recordPresence() end
  message(string.format(L("Snapshot%s: %d player(s)%s."), (label and label ~= "") and (" '" .. label .. "'") or "", #names,
    activeRaid and string.format(L(" in raid '%s'"), activeRaid.title) or L(" (no raid running, so not counted for attendance)")))
end

local function listSnapshots()
  local list = db.snapshots or {}
  if #list == 0 then message(L("No snapshots yet. /guilded snapshot [label]")); return end
  for i = math.max(1, #list - 4), #list do
    local entry = list[i]
    message(string.format("%s  %s  %d player(s)", entry.at, entry.label ~= "" and entry.label or "(no label)", #entry.names))
  end
end

-- /guilded award group <amount> [reason]: EP to everyone in the group.
-- A consumable penalty (Modules/Consumables.lua) lowers the amount for players this raid's scan
-- saw without a flask or food; one cut to nothing is skipped rather than recorded as zero.
local function groupAward(rawAmount, reason)
  local names = groupMembers()
  local count, reduced = 0, {}
  for _, name in ipairs(names) do
    local amount, note = rawAmount, reason
    local cut = ns.consumables and ns.consumables.penaltyFor and ns.consumables.penaltyFor(name, rawAmount)
    if cut then
      amount = cut.amount
      note = ((reason and reason ~= "") and (reason .. "; ") or "") .. cut.note
      table.insert(reduced, name)
    end
    if cut and amount < 1 then
      -- Nothing left to award.
    elseif changeEpgp(name, amount, note, "EP_AWARD", true) then count = count + 1 else return end
  end
  message(string.format(L("Awarded %s EP to %d group member(s)%s."), tostring(rawAmount), count,
    (reason and reason ~= "") and (" (" .. reason .. ")") or ""))
  if #reduced > 0 then message(string.format(L("Consumable penalty applied to %d player(s): %s."), #reduced, table.concat(reduced, ", "))) end
end

local function collectProfessions()
  -- GetProfessions() returns up to 6 slot indices (some may be nil), so index
  -- by count rather than ipairs, which would stop at the first hole.
  local result = {}
  if not GetProfessions or not GetProfessionInfo then return result, false end
  local complete = true
  local indices = { GetProfessions() }
  local count = select("#", GetProfessions())
  for i = 1, count do
    local index = indices[i]
    if index then
      local name, _, skillLevel, _, _, _, skillLine = GetProfessionInfo(index)
      if name then
        -- The same profession is the same name on every client: the English name (Util.lua), by skill line id first.
        local key = ns.util and ns.util.professionName and ns.util.professionName(name, skillLine) or name
        table.insert(result, { name = key, skillLevel = skillLevel or 0 })
      else complete = false end
    end
  end
  return result, complete
end
ns.collectProfessions = collectProfessions

-- Who this character is, for the Discord bot's /character link. Class and
-- race use the English file tokens (WARRIOR, NightElf) so the bot reads them
-- the same on any client language.
local function collectCharacter()
  local professions, complete = collectProfessions()
  local _, classFile = UnitClass("player")
  local _, raceFile = UnitRace("player")
  local spec
  if GetSpecialization and GetSpecializationInfo then
    local index = GetSpecialization()
    if index then
      local _, specName = GetSpecializationInfo(index)
      spec = specName
    end
  end
  -- Classic clients expose talent trees rather than Retail specializations.
  -- Only a unique tree with spent points identifies the current build.
  if not spec and GetNumTalentTabs and GetTalentTabInfo then
    local ok, tabs = pcall(GetNumTalentTabs)
    local group = 1
    if GetActiveTalentGroup then
      local groupOk, active = pcall(GetActiveTalentGroup)
      if groupOk and type(active) == "number" then group = active end
    end
    local most, tied, selected = 0, false, nil
    for index = 1, (ok and type(tabs) == "number" and math.min(tabs, 10) or 0) do
      local treeOk, treeName, _, points = pcall(GetTalentTabInfo, index, false, false, group)
      if treeOk and not isSecret(treeName) and not isSecret(points) and type(treeName) == "string" and type(points) == "number" then
        if points > most then most, tied, selected = points, false, treeName
        elseif points == most and points > 0 then tied = true end
      end
    end
    if most > 0 and not tied then spec = selected end
  end
  -- This character's rank in its own guild (GetGuildInfo: guild, rank name, 0-based index; the
  -- guild master is 0). Empty until the client knows the guild; later captures fill it in.
  local rankName, rankIndex
  if GetGuildInfo then
    local ok, _, name, index = pcall(GetGuildInfo, "player")
    if ok and type(name) == "string" and not isSecret(name) and name ~= "" and type(index) == "number" and index >= 0 and index < 20 then
      rankName, rankIndex = string.sub(name, 1, 60), index
    end
  end
  return {
    guildRankName = rankName,
    guildRankIndex = rankIndex,
    name = ns.util.bareName(playerName()),
    -- (stage B) The character id (low part of the GUID, hex); nil when the client gives none.
    id = ns.util.unitId("player"),
    displayName = ns.util.unitDisplayName("player"),
    gameEdition = ns.util.gameEdition(),
    interface = ns.util.clientInterface(),
    realm = (ns.compat and ns.compat.identity().realm) or (GetRealmName and GetRealmName()) or "",
    class = classFile or "",
    race = raceFile or "",
    level = UnitLevel("player") or 0,
    spec = spec or "",
    professions = professions,
    professionsComplete = complete,
    professionsAt = now(),
    capturedAt = now()
  }
end

-- /guilded verify: the member's code from Discord (/character link), kept with this guild's saved
-- data so every character of this WoW account repeats it in its digest ("V:"). An officer's upload
-- then links each of them to that member. Eight letters, no I or O (the bot's alphabet).
local function validVerifyCode(code)
  if type(code) ~= "string" or #code ~= 8 or not string.match(code, "^%u+$") or string.find(code, "[IO]") then return nil end
  return code
end
-- What people paste: lower case, a dash, a space in the middle.
local function verifyCodeFrom(text)
  return validVerifyCode(string.upper((string.gsub(text or "", "[^%a]", ""))))
end

-- One line the player pastes into Discord: /character link line_or_code:<line>
local function characterString(info)
  local professions = {}
  for _, profession in ipairs(info.professions or {}) do
    table.insert(professions, (string.gsub(profession.name, "[|;,:]", "")) .. ":" .. tostring(profession.skillLevel))
  end
  -- ";" separates the fields: "|" is WoW's colour-code escape, and a "|R" in
  -- the name ("Ray") was being eaten by the chat frame (QG1 lines broke).
  local function clean(value) return (string.gsub(tostring(value or ""), "[|;]", "")) end
  return "QG2;" .. table.concat({
    clean(info.name), clean(info.realm), clean(info.class), clean(info.race),
    tostring(info.level or 0), clean(info.spec), table.concat(professions, ","), clean(info.displayName),
    clean(info.gameEdition), clean(info.interface)
  }, ";")
end

local base64Encode = util.base64Encode

-- One paste for Discord's /character link: who you are (the QG1 line), your
-- last gear check, active consumables and attunements. It is only ever YOUR
-- data, so there is no ledger and no officer review step.
local function selfExportString(info, snapshot, attunements)
  local lines = { characterString(info) }
  if snapshot then
    table.insert(lines, string.format("R|%s|%s", tostring(snapshot.status or ""), tostring(snapshot.itemLevel or "")))
    for _, finding in ipairs(snapshot.findings or {}) do
      table.insert(lines, string.format("F|%s|%s|%s", finding.code or "", finding.severity or "", (string.gsub(finding.message or "", "[\n|]", " "))))
    end
    for _, row in ipairs(snapshot.consumables or {}) do
      table.insert(lines, string.format("C|%s|%s", row.category or "", (string.gsub(row.name or "", "|", " "))))
    end
  end
  local names = {}
  for name in pairs(attunements or {}) do table.insert(names, name) end
  table.sort(names)
  for _, name in ipairs(names) do
    table.insert(lines, string.format("A|%s|%d", (string.gsub(name, "|", " ")), attunements[name].completed and 1 or 0))
  end
  return "QGEXP1:" .. base64Encode(table.concat(lines, "\n"))
end

local exportFrame
local exportTitle = "Guilded - copy this line (Ctrl+C), then in Discord: /character link"
local function showCharacterExport(text, title, anchor, onNext)
  exportTitle = title or exportTitle
  if exportFrame and exportFrame.titleText then exportFrame.titleText:SetText(exportTitle) end
  if not exportFrame then
    exportFrame = CreateFrame("Frame", "GuildedCharacterExport", UIParent, BackdropTemplateMixin and "BackdropTemplate" or nil)
    exportFrame:SetSize(520, 110)
    exportFrame:SetPoint("CENTER")
    exportFrame:SetFrameStrata("DIALOG")
    exportFrame:EnableMouse(true)
    exportFrame:SetMovable(true)
    exportFrame:RegisterForDrag("LeftButton")
    exportFrame:SetScript("OnDragStart", exportFrame.StartMoving)
    exportFrame:SetScript("OnDragStop", exportFrame.StopMovingOrSizing)
    if exportFrame.SetClampedToScreen then exportFrame:SetClampedToScreen(true) end
    if exportFrame.SetBackdrop then exportFrame:SetBackdrop({ bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background", edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border", tile = true, tileSize = 32, edgeSize = 32, insets = { left = 8, right = 8, top = 8, bottom = 8 } }) end
    local background = exportFrame:CreateTexture(nil, "BACKGROUND")
    background:SetPoint("TOPLEFT", exportFrame, "TOPLEFT", 8, -8)
    background:SetPoint("BOTTOMRIGHT", exportFrame, "BOTTOMRIGHT", -8, 8)
    background:SetColorTexture(0, 0, 0, 0.85)
    if UISpecialFrames then table.insert(UISpecialFrames, "GuildedCharacterExport") end
    local title = exportFrame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    title:SetPoint("TOP", 0, -10)
    title:SetText(exportTitle)
    exportFrame.titleText = title
    local scroll = CreateFrame("ScrollFrame", nil, exportFrame, "UIPanelScrollFrameTemplate")
    scroll:SetPoint("TOPLEFT", 15, -36)
    scroll:SetSize(470, 24)
    local box = CreateFrame("EditBox", nil, scroll)
    box:SetSize(490, 24)
    scroll:SetScrollChild(box)
    box:SetAutoFocus(true)
    box:SetFontObject(ChatFontNormal or GameFontNormal)
    box:SetScript("OnEscapePressed", function() exportFrame:Hide() end)
    box:SetScript("OnEnterPressed", function() exportFrame:Hide() end)
    local close = CreateFrame("Button", nil, exportFrame, "UIPanelButtonTemplate")
    close:SetSize(80, 22)
    close:SetPoint("BOTTOM", 0, 10)
    close:SetText(ns.L and ns.L("Close") or "Close")
    close:SetScript("OnClick", function() exportFrame:Hide() end)
    exportFrame.box = box
    exportFrame.scroll = scroll
    -- Next (only when the caller passes a callback): shows the following line, e.g. the next name to invite.
    local nextButton = CreateFrame("Button", nil, exportFrame, "UIPanelButtonTemplate")
    nextButton:SetSize(80, 22)
    nextButton:SetPoint("BOTTOMRIGHT", -14, 10)
    nextButton:SetText(ns.L and ns.L("Next") or "Next")
    nextButton:SetScript("OnClick", function() if exportFrame.onNext then exportFrame.onNext() end end)
    nextButton:Hide()
    exportFrame.nextButton = nextButton
  end
  exportFrame.onNext = type(onNext) == "function" and onNext or nil
  if exportFrame.nextButton then
    if exportFrame.onNext then exportFrame.nextButton:Show() else exportFrame.nextButton:Hide() end
  end
  -- A share code is one line; a raid summary has several, so the box grows for those.
  local lines = 1
  for _ in string.gmatch(text or "", "\n") do lines = lines + 1 end
  local multi = lines > 1
  if exportFrame.box.SetMultiLine then exportFrame.box:SetMultiLine(multi) end
  local viewport = multi and math.min(240, lines * 16 + 8) or 24
  exportFrame.box:SetSize(470, multi and math.max(viewport, lines * 16 + 8) or 24)
  exportFrame.scroll:SetSize(470, viewport)
  exportFrame:SetSize(520, viewport + 90)
  exportFrame.box:SetText(text)
  exportFrame.scroll:SetVerticalScroll(0)
  -- Beside a window that asked (the invite list): just below it, so the rows stay visible. Otherwise back in the centre.
  if type(anchor) == "table" and anchor.GetBottom and exportFrame.ClearAllPoints then
    exportFrame:ClearAllPoints()
    exportFrame:SetPoint("TOP", anchor, "BOTTOM", 0, -4)
    exportFrame.anchored = true
  elseif exportFrame.anchored and exportFrame.ClearAllPoints then
    exportFrame:ClearAllPoints()
    exportFrame:SetPoint("CENTER")
    exportFrame.anchored = nil
  end
  exportFrame:Show()
  exportFrame.box:SetFocus()
  exportFrame.box:HighlightText()
end
ns.showCopyText = showCharacterExport

-- End-of-raid summary from what this client recorded. Boss kills and attendance are marked by
-- officers (the game does not report them to addons), so the summary says so.
raidSummaryLines = function(raid)
  if not raid then return { "No raid recorded yet." } end
  local function when(stamp) return stamp and (util.whenText and util.whenText(stamp) or stamp) or nil end
  local lines = { string.format("%s - %s to %s", raid.title or "Raid", when(raid.startedAt) or "?", when(raid.endedAt) or "still running") }
  local counts, marked = { PRESENT = 0, LATE = 0, ABSENT = 0 }, {}
  for name, row in pairs(db.attendance[raid.id] or {}) do
    counts[row.status] = (counts[row.status] or 0) + 1
    marked[name] = true
  end
  local unmarked = {}
  for name in pairs(db.presence[raid.id] or {}) do if not marked[name] then table.insert(unmarked, name) end end
  table.sort(unmarked)
  table.insert(lines, string.format("Attendance (marked by officers): %d present, %d late, %d absent.", counts.PRESENT, counts.LATE, counts.ABSENT))
  if #unmarked > 0 then
    table.insert(lines, string.format("Seen in the group but not marked (%d): %s", #unmarked, table.concat(unmarked, ", ")))
  end
  local bosses = {}
  for _, boss in ipairs(db.bosses[raid.id] or {}) do table.insert(bosses, boss.name) end
  table.insert(lines, #bosses > 0 and ("Bosses (marked by hand): " .. table.concat(bosses, ", ")) or "Bosses: none marked.")
  local ep, gp, entries = 0, 0, 0
  for _, account in pairs(db.epgp or {}) do
    for _, entry in ipairs(account.ledger or {}) do
      if entry.raid == raid.id and not entry.voided then
        entries = entries + 1
        ep, gp = ep + (entry.epAmount or 0), gp + (entry.gpAmount or 0)
      end
    end
  end
  table.insert(lines, string.format("EP/GP: %d entries, %+d EP, %+d GP.", entries, ep, gp))
  local loot = {}
  for _, row in ipairs(db.loot or {}) do
    if row.raid == raid.id then
      table.insert(loot, row.item .. " -> " .. row.player .. ((row.cost or 0) > 0 and (" (" .. row.cost .. " GP)") or ""))
    end
  end
  table.insert(lines, #loot > 0 and ("Loot (" .. #loot .. "): " .. table.concat(loot, "; ")) or "Loot: none recorded.")
  for _, note in ipairs(raid.notes or {}) do table.insert(lines, "Note: " .. note.text) end
  return lines
end

-- /guilded raids [n]: one line per recent raid, newest first, to read or copy.
local function raidHistoryLines(count)
  count = math.max(1, math.min(20, tonumber(count) or 5))
  local lines = {}
  for i = #db.raids, math.max(1, #db.raids - count + 1), -1 do
    local raid = db.raids[i]
    local present = 0
    for _, row in pairs(db.attendance[raid.id] or {}) do if row.status ~= "ABSENT" then present = present + 1 end end
    local bosses = #(db.bosses[raid.id] or {})
    local ep, loot = 0, 0
    for _, account in pairs(db.epgp or {}) do
      for _, entry in ipairs(account.ledger or {}) do if entry.raid == raid.id and not entry.voided then ep = ep + (entry.epAmount or 0) end end
    end
    for _, row in ipairs(db.loot or {}) do if row.raid == raid.id then loot = loot + 1 end end
    local when = util.whenText and util.whenText(raid.startedAt) or raid.startedAt
    table.insert(lines, string.format("%s - %s: %d attended, %d boss(es), %+d EP, %d loot%s", tostring(when or "?"), raid.title or "Raid",
      present, bosses, ep, loot, raid.endedAt and "" or " (running)"))
  end
  if #lines == 0 then lines[1] = "No raids recorded on this PC yet." end
  return lines
end
ns.raidHistoryLines = raidHistoryLines

-- /guilded raids report [n]: each player's attendance over the last n raids recorded on this PC
-- (default 10), with lates, absences, loot and EP from those raids. Officers mark attendance by
-- hand, so "seen" counts players in the group who were never marked. Best attendance first.
local REPORT_PLAYER_LIMIT = 80
local function raidReportLines(count)
  count = math.max(1, math.min(50, tonumber(count) or 10))
  local raids, inWindow = {}, {}
  for i = #db.raids, math.max(1, #db.raids - count + 1), -1 do
    table.insert(raids, db.raids[i])
    inWindow[db.raids[i].id] = true
  end
  if #raids == 0 then return { "No raids recorded on this PC yet." } end
  local players = {}
  local function row(name)
    players[name] = players[name] or { name = name, attended = 0, late = 0, absent = 0, seen = 0, loot = 0, ep = 0 }
    return players[name]
  end
  for _, raid in ipairs(raids) do
    local marked = db.attendance[raid.id] or {}
    for name, mark in pairs(marked) do
      local player = row(name)
      if mark.status == "ABSENT" then player.absent = player.absent + 1
      else
        player.attended = player.attended + 1
        if mark.status == "LATE" then player.late = player.late + 1 end
      end
    end
    for name in pairs(db.presence[raid.id] or {}) do
      if not marked[name] then row(name).seen = row(name).seen + 1 end
    end
  end
  for _, loot in ipairs(db.loot or {}) do
    if loot.raid and inWindow[loot.raid] and loot.player then row(loot.player).loot = row(loot.player).loot + 1 end
  end
  for name, account in pairs(db.epgp or {}) do
    for _, entry in ipairs(account.ledger or {}) do
      if entry.raid and inWindow[entry.raid] and not entry.voided and (entry.epAmount or 0) ~= 0 then
        row(name).ep = row(name).ep + entry.epAmount
      end
    end
  end
  local sorted = {}
  for _, player in pairs(players) do table.insert(sorted, player) end
  table.sort(sorted, function(a, b)
    if a.attended ~= b.attended then return a.attended > b.attended end
    return a.name < b.name
  end)
  local oldest = raids[#raids]
  local lines = { string.format("Attendance over the last %d raid(s) on this PC, since %s (marked by officers):", #raids,
    tostring(util.whenText and util.whenText(oldest.startedAt) or oldest.startedAt or "?")) }
  for i, player in ipairs(sorted) do
    if i > REPORT_PLAYER_LIMIT then
      table.insert(lines, string.format("... and %d more.", #sorted - REPORT_PLAYER_LIMIT))
      break
    end
    local extra = {}
    if player.late > 0 then table.insert(extra, player.late .. " late") end
    if player.absent > 0 then table.insert(extra, player.absent .. " absent") end
    if player.seen > 0 then table.insert(extra, player.seen .. " seen, not marked") end
    if player.loot > 0 then table.insert(extra, player.loot .. " loot") end
    if player.ep ~= 0 then table.insert(extra, string.format("%+d EP", player.ep)) end
    table.insert(lines, string.format("%s: %d/%d (%d%%)%s", player.name, player.attended, #raids,
      math.floor(player.attended * 100 / #raids + 0.5), #extra > 0 and (", " .. table.concat(extra, ", ")) or ""))
  end
  if #sorted == 0 then table.insert(lines, "Nobody was marked or seen in these raids.") end
  return lines
end
ns.raidReportLines = raidReportLines

local sheetText, SHEET_TABLES, SHEET_ROW_LIMIT = ns.createSheetExport(function() return db end)
ns.sheetText = sheetText

local function sheetCommand(kind)
  kind = string.lower(kind or "standings")
  local text, count, cut = sheetText(kind)
  if not text then
    message(L("Usage: /guilded sheet") .. " " .. table.concat(SHEET_TABLES, "|"))
    return
  end
  if count == 0 then message(string.format(L("Nothing to export yet for %s."), kind)); return end
  if cut then message(string.format(L("Only the first %d rows are in the box."), SHEET_ROW_LIMIT)) end
  showCharacterExport(text, L("Guilded - Ctrl+C, then paste into Excel or Google Sheets"))
end
ns.showSheet = sheetCommand

local READINESS_SLOTS = {
  { 1, "Head" }, { 3, "Shoulder" }, { 5, "Chest" }, { 6, "Waist" },
  { 7, "Legs" }, { 8, "Feet" }, { 9, "Wrist" }, { 10, "Hands" },
  { 16, "MainHand" }, { 17, "OffHand" }
}

-- Equipment slots where a missing enchant is worth flagging. Officers can
-- turn the check off or set the level it starts at with /guilded enchants.
local ENCHANTABLE = { Chest = true, Legs = true, Feet = true, Wrist = true, Hands = true, MainHand = true }
-- WoW Forever's level cap is 60.
local DEFAULT_ENCHANT_MIN_LEVEL = 60
-- Below this level an empty head or shoulder slot is normal (levelling gear), so empty slots are
-- only a note there, not "Not ready". /guilded slots level <n> changes it (1 = always count).
local DEFAULT_SLOT_MIN_LEVEL = DEFAULT_ENCHANT_MIN_LEVEL
-- Read-only for other modules (Modules/PugCheck.lua checks other players with the same rules).
ns.gearSlots, ns.enchantableSlots = READINESS_SLOTS, ENCHANTABLE

-- `tries` is set only by the automatic checks (login, gear and talent changes): right after
-- login WoW Forever can report every slot empty for a few seconds, and such a check used to
-- record and share "NOT_READY, 10 empty slots" with the guild. Those checks wait instead.
local GEAR_WAIT_SECONDS, GEAR_WAIT_TRIES = 5, 4
local AUTO_DIGEST_HEARTBEAT = 600
local lastAutoDigest, lastAutoDigestAt = nil, 0
local inspectReadiness

-- /guilded verify, kept audible. The code rides in the guild digest, but the digest only goes out
-- when something changes (and a 10-minute heartbeat while events fire): if no guildmate's
-- companion is online at that moment, nobody hears it. While a code is saved and the member is
-- not yet confirmed, the digest is sent again every VERIFY_RESEND_SECONDS. It goes through
-- ns.comm.send like every digest, so the queue and the per-prefix throttle still apply, and it
-- stops by itself once the code is removed or the member shows up in the shared standings.
local VERIFY_RESEND_SECONDS = 300
local verifyLoopOn = false
local function verifyLinked()
  if ns.isInGameOnly and ns.isInGameOnly() then return false end
  if not ns.getStanding then return false end
  local ok, row = pcall(ns.getStanding, playerName())
  return ok and row ~= nil and row ~= false
end
-- What the window shows: { hasCode, pending (code saved, not confirmed yet), linked }.
ns.verifyStatus = function()
  local hasCode = db ~= nil and validVerifyCode(db.verifyCode) ~= nil
  local linked = verifyLinked()
  return { hasCode = hasCode, linked = linked, pending = hasCode and not linked }
end
local function scheduleVerifyResend()
  if verifyLoopOn or not (C_Timer and C_Timer.After) then return end
  verifyLoopOn = true
  C_Timer.After(VERIFY_RESEND_SECONDS, function()
    verifyLoopOn = false
    if not db or not validVerifyCode(db.verifyCode) or verifyLinked() then return end
    if IsInGuild and IsInGuild() and not (InCombatLockdown and InCombatLockdown()) then
      inspectReadiness(true, "GUILD")
    end
    scheduleVerifyResend()
  end)
end
ns.scheduleVerifyResend = scheduleVerifyResend
local function noGearVisible()
  for _, slot in ipairs(READINESS_SLOTS) do
    if GetInventoryItemLink("player", slot[1]) or (GetInventoryItemID and GetInventoryItemID("player", slot[1])) then return false end
  end
  return true
end

inspectReadiness = function(silent, target, tries)
  if tries and tries < GEAR_WAIT_TRIES and noGearVisible() and C_Timer and C_Timer.After then
    C_Timer.After(GEAR_WAIT_SECONDS, function() inspectReadiness(silent, target, tries + 1) end)
    return
  end
  local professions, complete = collectProfessions()
  local snapshot = { character = playerName(), inspectedAt = now(), items = {}, consumables = {}, professions = professions, professionsComplete = complete, professionsAt = now(), findings = {} }
  local missing = 0
  local missingSlots = {}
  local unenchanted = {}
  local minDurability = 100
  local slotsCount = (UnitLevel("player") or 0) >= (db.settings.slotMinLevel or DEFAULT_SLOT_MIN_LEVEL)
  local lowLevelEmpty = {}
  for _, slot in ipairs(READINESS_SLOTS) do
    local link = GetInventoryItemLink("player", slot[1])
    -- Right after login the link can still be loading while the item id is
    -- already known; an equipped item must never count as missing.
    local itemId = GetInventoryItemID and GetInventoryItemID("player", slot[1])
    if link or itemId then
      -- Item links look like |cAARRGGBB|Hitem:ID:...|h[Name]|h|r; pull the
      -- readable name and numeric id out instead of exporting the raw link.
      local itemName = link and string.match(link, "%[(.-)%]")
      if not itemName or itemName == "" then itemName = "Item " .. tostring(itemId or "?") end
      local row = { slot = slot[2], itemName = itemName, itemId = itemId and tostring(itemId) or (link and string.match(link, "item:(%d+)")) }
      -- The enchant id is the second field of an item link: item:<id>:<enchant>:...
      local enchantId = link and tonumber(string.match(link, "item:%d+:(%d+)"))
      if enchantId and enchantId > 0 then
        row.enchants = { { slot = slot[2], name = "Enchant " .. enchantId, enchantId = tostring(enchantId) } }
      elseif link and ENCHANTABLE[slot[2]] then
        table.insert(unenchanted, slot[2])
      end
      local current, maximum
      if GetInventoryItemDurability then current, maximum = GetInventoryItemDurability(slot[1]) end
      if current and maximum and maximum > 0 then
        row.durability = math.floor(current / maximum * 100)
        if row.durability < minDurability then minDurability = row.durability end
      end
      table.insert(snapshot.items, row)
    elseif slot[2] == "OffHand" then
      -- Two-handed weapons (and some specs) legitimately leave OffHand empty;
      -- that can't be told apart from "forgot to equip" without deeper
      -- tooltip parsing, so treat it as a soft warning, not a hard failure.
      table.insert(snapshot.findings, { code = "MISSING_OFFHAND", severity = "WARNING", message = "No off-hand item equipped (expected when using a two-handed weapon)." })
    elseif not slotsCount then
      table.insert(lowLevelEmpty, slot[2])
    else
      missing = missing + 1
      table.insert(missingSlots, slot[2])
      table.insert(snapshot.findings, { code = "MISSING_" .. string.upper(slot[2]), severity = "ERROR", message = "Missing " .. slot[2] .. " equipment." })
    end
  end
  if #lowLevelEmpty > 0 then
    table.insert(snapshot.findings, { code = "EMPTY_SLOTS_LOW_LEVEL", severity = "INFO",
      message = "Empty slots (normal while levelling): " .. table.concat(lowLevelEmpty, ", ") .. "." })
  end
  -- Consumables: always recorded; only a missing flask/food counts against
  -- readiness while you are in a raid group (idle in town is fine).
  if ns.consumables and (not ns.moduleActive or ns.moduleActive("consumables")) then
    local rowsOk, rows, scanned = pcall(ns.consumables.ownRows)
    if rowsOk and type(rows) == "table" and scanned and scanned.readable then
      snapshot.consumables = rows
      if (IsInRaid and IsInRaid()) or (GetNumRaidMembers and GetNumRaidMembers() > 0) then
        -- Only a complete look proves something is missing (hidden buffs are "unknown").
        local facts = ns.consumables.factsFromScan and ns.consumables.factsFromScan(scanned) or {}
        if facts.flask == false then
          table.insert(snapshot.findings, { code = "NO_FLASK", severity = "WARNING", message = "No flask or elixir active." })
        end
        if facts.food == false then
          table.insert(snapshot.findings, { code = "NO_FOOD", severity = "WARNING", message = "No food buff active." })
        end
      end
    end
  end
  local enchantCheck = db.settings.enchantCheck ~= false
    and (UnitLevel("player") or 0) >= (db.settings.enchantMinLevel or DEFAULT_ENCHANT_MIN_LEVEL)
  if enchantCheck and #unenchanted > 0 then
    table.insert(snapshot.findings, { code = "MISSING_ENCHANTS", severity = "WARNING",
      message = "Missing enchants: " .. table.concat(unenchanted, ", ") .. "." })
  end
  if minDurability < 20 then
    table.insert(snapshot.findings, { code = "LOW_DURABILITY", severity = "WARNING", message = "Lowest equipped durability is " .. minDurability .. "%." })
  end
  if missing == 0 then
    table.insert(snapshot.findings, { code = "GEAR_PRESENT", severity = "INFO", message = "Required gear slots are populated." })
  end
  -- Same rule as the bot's deriveReadinessStatus: any ERROR -> NOT_READY,
  -- any WARNING -> PARTIAL, otherwise READY. (INFO findings don't count; the
  -- old check counted them, so READY was impossible to reach.)
  local hasWarning = false
  for _, finding in ipairs(snapshot.findings) do
    if finding.severity == "WARNING" then hasWarning = true end
  end
  snapshot.status = missing > 0 and "NOT_READY" or hasWarning and "PARTIAL" or "READY"
  -- Item level: earlier notes assumed this client had no such API (it was
  -- thought to be a vanilla-era client). Forever uses the modern API, so try
  -- it, fully guarded so a missing or restricted API can never break inspect.
  pcall(function()
    if GetAverageItemLevel then
      local _, equipped = GetAverageItemLevel()
      if type(equipped) == "number" and equipped > 0 then
        snapshot.itemLevel = math.floor(equipped * 10 + 0.5) / 10
      end
    end
  end)
  db.readiness[playerName()] = snapshot
  logEvent("READINESS", { status = snapshot.status, missing = missing, itemLevel = snapshot.itemLevel })

  local profParts = {}
  for _, profession in ipairs(professions) do
    table.insert(profParts, profession.name .. ":" .. profession.skillLevel)
  end
  -- Compact digest only (no item list/enchants/consumables) so this fits in
  -- a single addon message with no chunking. Broadcast to GUILD by default
  -- so it reaches everyone online, not just the current raid group.
  -- Short reason flags ride along so officers see why a peer is PARTIAL:
  -- NOFLASK, NOFOOD, ENCH:<slots joined by +>. Marked "F:" so an empty
  -- profession field can't shift them.
  local flags = {}
  for _, finding in ipairs(snapshot.findings) do
    if finding.code == "NO_FLASK" then table.insert(flags, "NOFLASK")
    elseif finding.code == "NO_FOOD" then table.insert(flags, "NOFOOD")
    elseif finding.code == "MISSING_ENCHANTS" then table.insert(flags, "ENCH:" .. table.concat(unenchanted, "+")) end
  end
  -- Item level for the officers' Gear page ("IL:58"). Older clients and companions skip flags
  -- they do not know, so this needs no protocol change.
  if snapshot.itemLevel then table.insert(flags, 1, "IL:" .. math.floor(snapshot.itemLevel + 0.5)) end
  -- The short, fixed-size optional fields go first (identity, verify code, flags) so a long profession list can
  -- never push them out: it is the profession list that is cut to what is left. The receiver tells every part
  -- apart by its prefix, so the order does not matter to it.
  local digest = string.format("READINESS|%s|%s|%d|%d", playerName(), snapshot.status, missing, minDurability)
  -- Who this is (class, race, level, spec) so officers' exports can discover
  -- every guildmate running the addon: "I:<CLASS>,<Race>,<level>,<spec>".
  local identityOk, identity = pcall(collectCharacter)
  if identityOk and type(identity) == "table" and identity.class ~= "" then
    local field = "I:" .. table.concat({ identity.class, identity.race, tostring(identity.level or 0),
      (string.gsub(identity.spec or "", "[|,;]", "")) }, ",")
    if #digest + 1 + #field <= MAX_ADDON_MESSAGE then digest = digest .. "|" .. field end
  end
  -- (stage B) This character's id as "ID=<hex>": a prefix older addons do not know (it has no colon, so they never read it as a
  -- profession); receivers keep it beside the sender's name.
  if identityOk and type(identity) == "table" and identity.id then
    local field = "ID=" .. identity.id
    if #digest + 1 + #field <= MAX_ADDON_MESSAGE then digest = digest .. "|" .. field end
  end
  -- The /guilded verify code.
  local verify = validVerifyCode(db.verifyCode)
  if verify and #digest + 3 + #verify <= MAX_ADDON_MESSAGE then digest = digest .. "|V:" .. verify end
  local flagText = table.concat(flags, ",")
  if #flags > 0 and #digest + 3 + #flagText <= MAX_ADDON_MESSAGE then
    digest = digest .. "|F:" .. flagText
  end
  -- Professions get the room that is left (whole entries only); the "P:" mark of a complete list follows only when all fit.
  local room = MAX_ADDON_MESSAGE - #digest - 1 - 16
  local kept, used = {}, 0
  for _, part in ipairs(profParts) do
    local need = #part + (#kept > 0 and 1 or 0)
    if used + need > room then break end
    kept[#kept + 1] = part; used = used + need
  end
  if #kept > 0 then digest = digest .. "|" .. table.concat(kept, ",") end
  if #kept < #profParts then complete = false end
  if complete and #digest + 16 <= MAX_ADDON_MESSAGE then digest = digest .. "|P:" .. tostring((GetServerTime and GetServerTime()) or time()) end
  -- Automatic checks run on every bag or gear change (looting!) and every skill-up. Tell the guild
  -- only when something changed, plus a heartbeat every 10 minutes; requests always get an answer.
  local sameAs = (string.gsub(digest, "|P:%d+", ""))
  local nowTime = time()
  if tries and (target or "GUILD") == "GUILD" and sameAs == lastAutoDigest and nowTime - lastAutoDigestAt < AUTO_DIGEST_HEARTBEAT then
    return
  end
  if tries then lastAutoDigest, lastAutoDigestAt = sameAs, nowTime end
  send(digest, target or "GUILD")
  if not silent then
    local detail = ""
    if missing > 0 then
      detail = string.format(L(" Empty slots: %s."), table.concat(missingSlots, ", "))
    elseif snapshot.status == "PARTIAL" then
      for _, finding in ipairs(snapshot.findings) do
        if finding.severity == "WARNING" then detail = detail .. " " .. finding.message end
      end
    end
    local ilvl = snapshot.itemLevel and string.format(L(" Item level %s."), tostring(snapshot.itemLevel)) or ""
    message(string.format(L("Readiness captured: %s.%s%s"), snapshot.status, detail, ilvl))
  end
end

-- Title-cases attunement keys so "onyxia key" and "Onyxia Key" are one entry
-- on the bot side (it keys attunements by exact name).
local function canonicalKey(key)
  return (string.gsub(key, "(%a)([%w']*)", function(first, rest)
    return string.upper(first) .. string.lower(rest)
  end))
end

local function setAttunement(name, key, completed, silent)
  key = canonicalKey(key)
  db.attunements[name] = db.attunements[name] or {}
  db.attunements[name][key] = { completed = completed, at = now(), by = playerName() }
  logEvent("ATTUNEMENT", { name = name, key = key, completed = completed })
  send("ATTUNEMENT|" .. name .. "|" .. key .. "|" .. tostring(completed), "GUILD")
  if not silent then message(name .. " attunement " .. (completed and "completed" or "cleared") .. ": " .. key .. ".") end
end
ns.setAttunement = setAttunement
ns.canonicalKey = canonicalKey

-- Automatic sync: re-run inspectReadiness (silently, broadcasting to GUILD)
-- on login, on gear changes, and when the raid roster changes, instead of
-- requiring everyone to run /guilded inspect manually. Deliberately event-driven
-- only (no OnUpdate ticker).
local lastAutoSyncAt = 0
local skillCheckPending = false
local AUTO_SYNC_DEBOUNCE_SECONDS = 5
local AUTO_SYNC_RAID_INTERVAL_SECONDS = 600

local function inRaidGroup()
  if IsInRaid then return IsInRaid() end
  if GetNumRaidMembers then return GetNumRaidMembers() > 0 end
  return false
end

-- (9.1.7) Bursty events (a 300-member roster fires GUILD_ROSTER_UPDATE many times in a few seconds, gear
-- changes fire UNIT_INVENTORY_CHANGED in clusters) run their heavy work once, shortly after the last
-- burst began: the first call schedules it, calls while it is pending fold into it. In combat the run
-- waits (the work is not needed there). Without timers it runs at once.
local deferredWork = {}
local function inCombatNow()
  if ns.compat and ns.compat.inCombat then return ns.compat.inCombat() and true or false end
  return (InCombatLockdown and InCombatLockdown()) and true or false
end
local lastWorkAt = {}
-- `leading`: the first call of a burst runs at once (it is the news the rest of the code expects to
-- see), calls within `seconds` of it fold into one more run when the window ends.
local function deferWork(key, seconds, fn, leading)
  if not (C_Timer and C_Timer.After) then pcall(fn) return end
  if leading then
    local at = (GetTime and GetTime()) or 0
    local last = lastWorkAt[key]
    if not deferredWork[key] and (last == nil or at - last >= seconds or at < last) and not inCombatNow() then
      lastWorkAt[key] = at
      local ok, err = pcall(fn)
      if not ok then logDiagnostic("LUA_ERROR", key .. ": " .. tostring(err)) end
      return
    end
    if deferredWork[key] then return end
    deferredWork[key] = true
    local wait = last and math.max(0.5, seconds - (at - last)) or seconds
    local function lateRun()
      if inCombatNow() then C_Timer.After(5, lateRun) return end
      deferredWork[key] = nil
      lastWorkAt[key] = (GetTime and GetTime()) or 0
      local ok2, err2 = pcall(fn)
      if not ok2 then logDiagnostic("LUA_ERROR", key .. ": " .. tostring(err2)) end
    end
    C_Timer.After(wait, lateRun)
    return
  end
  if deferredWork[key] then return end
  deferredWork[key] = true
  local function run()
    if inCombatNow() then C_Timer.After(5, run) return end
    deferredWork[key] = nil
    local ok, err = pcall(fn)
    if not ok then logDiagnostic("LUA_ERROR", key .. ": " .. tostring(err)) end
  end
  C_Timer.After(seconds, run)
end
ns.deferWork = deferWork

local function maybeAutoSync(minInterval)
  local nowTime = time()
  if (nowTime - lastAutoSyncAt) < minInterval then return end
  lastAutoSyncAt = nowTime
  inspectReadiness(true, "GUILD", 0)
end

-- /guilded loot <player> <item, may contain spaces or be a shift-clicked link> [cost]
local function recordLoot(args)
  local name = normalizeName(args[2])
  local last = #args
  local cost = 0
  if last >= 4 and tonumber(args[last]) then
    cost = math.floor(tonumber(args[last]))
    last = last - 1
  end
  local item = table.concat(args, " ", 3, last)
  if not name or item == "" then message(L("Usage: /guilded loot <player> <item> [cost]")); return end
  -- The id lets the bot import each loot row into Discord loot history
  -- exactly once; the boss is the last one killed in this raid, if any.
  local bosses = activeRaid and db.bosses[activeRaid.id]
  local row = { id = nextLedgerId(), player = name, item = item, cost = cost,
    at = now(), by = playerName(), raid = activeRaid and activeRaid.id,
    boss = bosses and bosses[#bosses] and bosses[#bosses].name or nil }
  if ns.lootAwardQuote then row.pricing = ns.lootAwardQuote end
  table.insert(db.loot, row)
  logEvent("LOOT", row)
  send("LOOT|" .. name .. "|" .. item .. "|" .. row.cost)
  message(string.format(L("Recorded loot: %s -> %s."), item, name))
  local lootRules = ns.getLootRules and ns.getLootRules()
  if lootRules and lootRules.coreOnly and not activeRaid then
    message(L("No raid is running: Discord files loot under a raid core only once it belongs to a raid. Use /guilded start before the next item."))
  end
  -- Someone else holding the item (personal or group loot)? Remind them to trade it (Loot.lua).
  if ns.loot and ns.loot.noteAward then pcall(ns.loot.noteAward, item, name) end
end

local function exportData()
  local key = now()
  -- The companion reads the live tables (epgp, readiness, ...) straight from
  -- SavedVariables; an export is just a timestamped marker that tells it
  -- (and you) when the officer last asked for a sync.
  db.exports[key] = { exportedAt = key, by = playerName() }
  local keys = {}
  for existing in pairs(db.exports) do table.insert(keys, existing) end
  table.sort(keys)
  for i = 1, #keys - MAX_EXPORT_MARKERS do db.exports[keys[i]] = nil end
  message(string.format(L("Export marked at %s. /reload (or log out) so the game writes SavedVariables, then run the companion."), key))
end

local function showIdentity()
  if not ns.compat or not ns.compat.identity then return end
  local id = ns.compat.identity()
  local raw = id.raw
  message(string.format(L("Saved data belongs to guild: %s"), tostring(db and db.guildKey or L("(not known yet)"))))
  message(string.format("Identity: name=%s realm=%s (GetRealmName=%s, normalized=%s, UnitName realm=%s, full=%s)",
    id.name, id.hasRealm and id.realm or "(none)", tostring(raw.realmName), tostring(raw.normalizedRealm),
    tostring(raw.unitNameRealm), tostring(raw.fullName)))
end

-- Guilded's own problems come first; other addons' errors (often most of the list) are counted,
-- and listed only with /guilded diag all, so a Guilded problem is not lost among them.
local function showDiagnostics(args)
  showIdentity()
  -- WoW Forever, 8.5: legacy first-name keys (EP/GP accounts first) an officer still has to assign.
  -- (9.1.7) Debug detail: officers, or /guilded diag names|all; ordinary members are not shown it.
  local wantNames = args and (string.lower(args[1] or "") == "names" or string.lower(args[1] or "") == "all")
  -- (9.2.1) The per-name lines are never listed by default (not even for officers: they read as problems in
  -- chat and in "Last problems"); officers get one count line, /guilded diag names|all or /guilded names the detail.
  local legacy = (wantNames or isOfficer()) and ns.util.nameMigrationLines and ns.util.nameMigrationLines(db) or {}
  if #legacy > 0 then
    if wantNames then
      message(string.format(L("%d saved entries still use a first name only:"), #legacy))
      for index = 1, math.min(5, #legacy) do message(legacy[index]) end
    else
      message(string.format(L("%d saved entries still use a first name only: /guilded names lists them."), #legacy))
    end
  end
  if (ns.ignoredMessages or 0) > 0 then
    message(string.format("%d addon message(s) from other players were ignored this session (informational only).", ns.ignoredMessages))
  end
  local all = args and string.lower(args[1] or "") == "all"
  local own, foreign = {}, {}
  for _, entry in ipairs(db.diagnostics or {}) do table.insert(entry.foreign and foreign or own, entry) end
  local function list(entries)
    for i = math.max(1, #entries - 4), #entries do
      local entry = entries[i]
      local repeats = (entry.count or 1) > 1 and (" x" .. entry.count) or ""
      local origin = entry.foreign and " (other addon)" or ""
      message(entry.at .. " [" .. entry.kind .. "]" .. origin .. repeats .. " " .. entry.detail)
    end
  end
  if #own == 0 then
    message(L("No Guilded problems recorded."))
  else
    message(string.format(L("Last %d Guilded problem(s):"), math.min(5, #own)))
    list(own)
  end
  if #foreign == 0 then return end
  if all then
    message(string.format(L("Last %d from other addons:"), math.min(5, #foreign)))
    list(foreign)
  else
    message(string.format(L("%d problem(s) from other addons were also recorded; they are not Guilded's. /guilded diag all lists them."), #foreign))
  end
end

-- /guilded officer add|remove <name>, /guilded officer rank <index> on|off, /guilded officer list
-- Guild master only: changes who the addon treats as an officer without
-- hand-editing SavedVariables.
local function officerCommand(args)
  local action = string.lower(args[2] or "list")
  if action == "list" then
    local names = {}
    for name in pairs(db.settings.officers) do table.insert(names, name) end
    local ranks = {}
    for rank, on in pairs(db.settings.officerRanks) do if on then table.insert(ranks, tostring(rank)) end end
    table.sort(ranks)
    message(string.format(L("Officer rank indexes (0 = guild master): %s"), #ranks > 0 and table.concat(ranks, ", ") or L("none")))
    message(string.format(L("Extra officers: %s"), #names > 0 and table.concat(names, ", ") or L("none")))
    message(isOfficer() and L("You are an officer for this addon.") or L("You are NOT an officer for this addon."))
    return
  end
  if action == "auto" and ns.officerNotes then ns.officerNotes.command(args); return end
  if not isGuildMaster() then message(L("Only the guild master can change officer settings.")); return end
  if action == "add" or action == "remove" then
    local name = normalizeName(args[3])
    if not name then message(L("Usage: /guilded officer add|remove <name>")); return end
    db.settings.officers[name] = action == "add" or nil
    message(string.format(action == "add" and L("%s added as an addon officer.") or L("%s removed as an addon officer."), name))
  elseif action == "rank" then
    local rank = tonumber(args[3])
    local on = string.lower(args[4] or "")
    if not rank or (on ~= "on" and on ~= "off") then message(L("Usage: /guilded officer rank <index> on|off")); return end
    db.settings.officerRanks[rank] = on == "on" or nil
    message(string.format(on == "on" and L("Guild rank index %s is now an officer rank.") or L("Guild rank index %s is no longer an officer rank."), tostring(rank)))
  else
    message(L("Usage: /guilded officer list | add <name> | remove <name> | rank <index> on|off | auto status|professions|epgp|promote|greet|all on|off"))
  end
end

-- Each rank only sees the commands it can use. Module help lines are either
-- plain strings (everyone) or { officer = true, text = "..." }.
local function showFullHelp()
  local officer = isOfficer()
  message(L("|cffffd100Everyday|r"))
  message(L("/guilded menu (or click the minimap coin) | inspect | status | roster | standings [player] | diag | version"))
  message(L("/guilded attune <key> [clear] - mark your own attunement"))
  message(L("/guilded snapshot [label] | list - record who is in the group right now (officers)"))
  message(L("/guilded enchants - show or change the missing-enchant check (on/off, starting level)"))
  message(L("/guilded slots level <n> - from which level empty gear slots count as not ready (default 60)"))
  message(L("/guilded share - one paste with your character, gear check, consumables and attunements (Discord: /character link)"))
  message(L("/guilded character - copy a line to link this character in Discord (/character link)"))
  message(L("/guilded sheet standings|loot|attendance|raids|dungeons - copy a table to paste into Excel or Google Sheets"))
  if officer then
    message(L("|cffffd100Officer|r"))
    message(L("Officer: /guilded start [title] | end | attendance <name>|group|seen [PRESENT|ABSENT|LATE] | boss <name> | summary (what the raid recorded, to copy)"))
    message(L("Officer: /guilded note <text> | template save <name> [title] | template list | attendance roster | raid discard | undo (takes back your last award)"))
    message(L("/guilded raids [n] - recent raids, one line each, to copy | raids report [n] - each player's attendance, loot and EP"))
    message(L("Officer: /guilded award <name>|group <amount> [reason] | gp <name> <amount> [reason] | deduct <name> <amount> [reason] | gpdeduct <name> <amount> [reason]"))
    message(L("Officer: /guilded loot <name> <item> [cost] | export | attune <player> <key> [clear] | officer list|add|remove|rank"))
    message(L("Officer: /guilded void [player] - take back the newest EP/GP entry you made (for that player); Discord reverses it"))
  end
  message(L("|cffffd100More|r"))
  for _, line in pairs(ns.commandHelp or {}) do
    local text = type(line) == "table" and line.text or line
    -- Lines for a module that is off are left out ("/guilded casino ..." -> casino).
    local key = ns.commandModuleOf and ns.commandModuleOf(string.match(text or "", "^/guilded (%a+)"))
    if not key or ns.moduleActive(key) then
      if type(line) ~= "table" or officer or not line.officer then message(L(text)) end
    end
  end
  message(L("/guilded modules - turn optional parts (bidding, dungeons...) on or off"))
end

-- /guilded help: the few commands a member needs. Every other command keeps working and is listed by /guilded help all.
local function showHelp()
  message("|cffffd100Guilded|r")
  message(L("/guilded - open the Guilded window"))
  message(L("/guilded companion - the three steps to set up the companion"))
  message(L("/guilded sync - save your addon data so the companion can send it"))
  message(L("/guilded announce off - stop your guild-chat milestone announcements"))
  message(L("/guilded diag - problems the addon recorded, to copy for a bug report"))
  message(L("/gsos - call guildmates for help"))
  message(L("/gdg - dungeon groups"))
  message(L("/guilded help all - every command"))
end

-- Extension point for modules loaded after Core.lua (see Modules/Casino.lua):
-- ns.commandHandlers["casino"] = function(args) ... end registers /guilded casino ...
-- table.insert(ns.commandHelp, "...") adds a line to /guilded help.
ns.commandHandlers = ns.commandHandlers or {}
ns.commandHelp = ns.commandHelp or {}

-- Commands of features removed in 9.2: they print one line instead of the help text.
-- /guilded <command> is kept for one release so officers' macros explain themselves.
ns.removedCommands = ns.removedCommands or {
  motd = "WoW does not let addons set the guild message.",
  welcome = "WoW does not let addons send the automatic welcome whisper.",
  finder = "Blizzard's group finder is not available to addons on WoW Forever.",
  partners = "levelling partners were replaced by Layer invite (/guilded layer).",
  -- No version number: this one went out after 9.2.0 (the line then reads "was removed: ...").
  free = { text = "Availability sharing was removed because nobody used it.", since = false },
}

-- /guilded probe maps: the client's map ids, names, parents and rectangles, written to the saved variables (probes.maps) so new
-- zones can be read without typed scripts. Plain read-only map calls; nothing is sent.
-- /guilded probe comm [auto]: the two-client addon-message test, run from addon code (no typed script): register a test prefix, join
-- a temporary custom channel, send one addon message on it and one addon whisper to my own full name, log the API results and
-- what came back, then leave the channel. "auto" arms the same probe to run by itself 10 seconds after the next login or /reload.
-- Everything goes through ns.comm.send; the results go to the diagnostics (PROBE) and to probes.comm.
local COMM_PROBE_PREFIX = "GuildedProbe"
local function inCombatNow() return InCombatLockdown and InCombatLockdown() end
local function runCommProbe()
  if inCombatNow() then message(L("Not in combat.")); return end
  local result = { at = now(), steps = {}, heard = {} }
  local function step(text)
    result.steps[#result.steps + 1] = text
    logDiagnostic("PROBE", "comm: " .. text, true)
  end
  db.probes = type(db.probes) == "table" and db.probes or {}
  db.probes.comm = result
  ns.comm.register(COMM_PROBE_PREFIX)
  local listener
  if CreateFrame then
    listener = CreateFrame("Frame")
    listener:RegisterEvent("CHAT_MSG_ADDON")
    listener:SetScript("OnEvent", function(_, _, prefix, text, channel, sender)
      if isSecret(prefix) or isSecret(text) or prefix ~= COMM_PROBE_PREFIX then return end
      result.heard[#result.heard + 1] = tostring(channel) .. ":" .. tostring(text) .. ":" .. (isSecret(sender) and "?" or tostring(sender))
    end)
  end
  local channelName = "GuildedProbe" .. tostring((time and time() or 0) % 100000)
  local joinOk, joinErr = pcall(function()
    if JoinTemporaryChannel then return JoinTemporaryChannel(channelName) end
    if JoinChannelByName then return JoinChannelByName(channelName) end
    error("no join function")
  end)
  step(string.format("join %s: %s", channelName, joinOk and "called" or ("failed " .. tostring(joinErr))))
  local function after(seconds, fn) if C_Timer and C_Timer.After then C_Timer.After(seconds, fn) end end
  after(2, function()
    local id = 0
    local idOk, number = pcall(GetChannelName, channelName)
    if idOk and tonumber(number) then id = tonumber(number) end
    step(string.format("channel number %d (%s)", id, id > 0 and "joined" or "NOT joined"))
    if id > 0 then step("channel send queued: " .. tostring(ns.comm.send(COMM_PROBE_PREFIX, "probe-channel", "CHANNEL", id, nil, "interactive"))) end
    local realm = (GetNormalizedRealmName and GetNormalizedRealmName()) or (GetRealmName and (GetRealmName() or ""):gsub("%s", "")) or ""
    -- The full name alone is what a typed test whispered successfully; "Name-Realm" is sent as a second, separate payload so the result
    -- says which spelling comes back (the first probe sent only "Name-Realm" and heard nothing).
    local plain = UnitName and UnitName("player") or "?"
    local me = plain .. (realm ~= "" and ("-" .. realm) or "")
    step("whisper send queued (name only): " .. tostring(ns.comm.send(COMM_PROBE_PREFIX, "probe-whisper", "WHISPER", plain, nil, "interactive")))
    if me ~= plain then step("whisper send queued (name-realm): " .. tostring(ns.comm.send(COMM_PROBE_PREFIX, "probe-whisper-realm", "WHISPER", me, nil, "interactive"))) end
  end)
  after(8, function()
    local status = ns.comm.status(COMM_PROBE_PREFIX)
    step(string.format("results sent=%d refused=%d errors=%d throttled=%d queued=%d last=%s code=%s", status.sent, status.refused, status.errors,
      status.throttled, status.queued, tostring(status.lastResult), tostring(status.lastCode)))
    step(string.format("heard %d: %s", #result.heard, table.concat(result.heard, ", ")))
    pcall(function() if LeaveChannelByName then LeaveChannelByName(channelName) end end)
    if listener then listener:UnregisterAllEvents() end
    step("left the channel")
    message(L("Comm probe finished: the results are in the diagnostics (PROBE) and the saved variables (probes.comm)."))
  end)
  message(L("Comm probe started: results in about 6 seconds."))
end
ns.runCommProbe = runCommProbe

-- /guilded probe auctions: read-only. Does this client have what the planned Auction House achievements (docs/plans/AH_ACHIEVEMENTS.md) would
-- read? Reports which functions, globals and events exist, the shape (never the content) of the mail inbox headers and invoices, the owned
-- auction list's sale status, and any statistic whose name mentions gold or auctions. No amounts, names or item links are stored. The result
-- goes to chat (one line) and to the saved variables (probes.auctions, kept for one more login like probes.maps); the companion uploads probes to the bot (the owner reads them with /guilded-probes).
local unpack = table.unpack or unpack
local function returnTypes(...)
  local list = {}
  for i = 1, select("#", ...) do list[#list + 1] = type((select(i, ...))) end
  return table.concat(list, ",")
end
local function runAuctionProbe()
  local g = _G
  local r = { at = now(), build = (GetBuildInfo and select(4, GetBuildInfo())) or 0, fn = {}, globals = {}, events = {}, inbox = {}, owned = {}, stats = {} }
  for _, name in ipairs({ "GetInboxNumItems", "GetInboxHeaderInfo", "GetInboxInvoiceInfo", "GetNumAuctionItems", "GetAuctionItemInfo", "GetStatistic", "GetStatisticsCategoryList", "GetMoney" }) do
    r.fn[name] = type(g[name]) == "function"
  end
  r.fn.C_AuctionHouse = type(g.C_AuctionHouse) == "table"
  -- The localized chat/mail format strings (generic text with %s slots, no personal data).
  for _, name in ipairs({ "ERR_AUCTION_SOLD_S", "ERR_AUCTION_WON_S", "ERR_AUCTION_EXPIRED_S", "AUCTION_SOLD_MAIL_SUBJECT", "AUCTION_EXPIRED_MAIL_SUBJECT" }) do
    r.globals[name] = type(g[name]) == "string" and g[name] or ""
  end
  -- An event the client does not know makes RegisterEvent fail: that is the answer.
  if CreateFrame then
    -- One frame, kept: frames cannot be deleted, so a probe run must not make a new one each time.
    local okFrame, frame = true, ns.auctionProbeFrame
    if not frame then okFrame, frame = pcall(CreateFrame, "Frame"); if okFrame then ns.auctionProbeFrame = frame end end
    if okFrame and type(frame) == "table" then
      for _, event in ipairs({ "CHAT_MSG_SYSTEM", "AUCTION_OWNED_LIST_UPDATE", "MAIL_INBOX_UPDATE", "PLAYER_MONEY", "AUCTION_HOUSE_SHOW", "AUCTION_HOUSE_AUCTION_CREATED" }) do
        local ok = pcall(frame.RegisterEvent, frame, event)
        r.events[event] = ok and true or false
        if ok then pcall(frame.UnregisterEvent, frame, event) end
      end
    end
  end
  -- Inbox: how many values the header and the invoice return and their types; which invoice types exist; how many subjects match the sold-mail format.
  if r.fn.GetInboxNumItems then
    local okCount, count = pcall(g.GetInboxNumItems)
    count = okCount and tonumber(count) or 0
    r.inbox.mails = count
    local soldFormat = r.globals.AUCTION_SOLD_MAIL_SUBJECT
    local soldPrefix = soldFormat:match("^(.-)%%s") or ""
    r.inbox.invoiceTypes, r.inbox.soldSubjects = {}, 0
    for i = 1, math.min(count, 20) do
      if r.fn.GetInboxHeaderInfo then
        local packed = { pcall(g.GetInboxHeaderInfo, i) }
        if packed[1] then
          r.inbox.headerReturns = r.inbox.headerReturns or returnTypes(unpack(packed, 2))
          local subject = packed[5]
          if soldPrefix ~= "" and type(subject) == "string" and subject:sub(1, #soldPrefix) == soldPrefix then r.inbox.soldSubjects = r.inbox.soldSubjects + 1 end
        end
      end
      if r.fn.GetInboxInvoiceInfo then
        local packed = { pcall(g.GetInboxInvoiceInfo, i) }
        if packed[1] and packed[2] ~= nil then
          r.inbox.invoiceReturns = r.inbox.invoiceReturns or returnTypes(unpack(packed, 2))
          local kind = tostring(packed[2])
          r.inbox.invoiceTypes[kind] = (r.inbox.invoiceTypes[kind] or 0) + 1
        end
      end
    end
  end
  -- Owned auctions (the list is only filled while the auction house is open).
  r.owned.windowOpen = (g.AuctionFrame and g.AuctionFrame.IsShown and g.AuctionFrame:IsShown()) and true or false
  if r.fn.GetNumAuctionItems then
    local okNum, batch, total = pcall(g.GetNumAuctionItems, "owner")
    r.owned.count = okNum and tonumber(batch) or 0
    r.owned.total = okNum and tonumber(total) or 0
    if r.owned.count > 0 and r.fn.GetAuctionItemInfo then
      local packed = { pcall(g.GetAuctionItemInfo, "owner", 1) }
      if packed[1] then
        r.owned.returns = returnTypes(unpack(packed, 2))
        r.owned.saleStatusType = type(packed[17])
        r.owned.saleStatus = type(packed[17]) == "number" and packed[17] or nil
      end
    end
  end
  -- Statistics: id and name of any whose name mentions gold, auctions or sales, and whether the client has a value for it.
  if r.fn.GetStatisticsCategoryList and g.GetCategoryNumAchievements and g.GetAchievementInfo then
    local okList, categories = pcall(g.GetStatisticsCategoryList)
    for _, category in ipairs(okList and type(categories) == "table" and categories or {}) do
      local okNum, total = pcall(g.GetCategoryNumAchievements, category)
      for i = 1, okNum and tonumber(total) or 0 do
        local okInfo, id, name = pcall(g.GetAchievementInfo, category, i)
        if okInfo and type(name) == "string" and #r.stats < 40 then
          local lower = name:lower()
          if lower:find("gold", 1, true) or lower:find("auction", 1, true) or lower:find("coin", 1, true) or lower:find("sold", 1, true) then
            local okStat, value = pcall(g.GetStatistic, id)
            local has = okStat and type(value) == "string" and value ~= "" and value ~= "--"
            r.stats[#r.stats + 1] = tostring(id) .. "|" .. (name:gsub("[|%c]", " ")) .. "|" .. (has and "value" or "none")
          end
        end
      end
    end
  end
  db.probes = type(db.probes) == "table" and db.probes or {}
  db.probes.auctions = r
  local function yes(flag) return flag and "yes" or "no" end
  if ns.logDiagnostic then ns.logDiagnostic("PROBE", "auctions probed", true) end
  message(string.format(L("Auction probe: inbox %s, invoices %s, sold message %s, owned list %s, %d statistics. Details are in the saved variables (probes.auctions); reload or log out to save the file."),
    yes(r.fn.GetInboxHeaderInfo), yes(r.fn.GetInboxInvoiceInfo), yes(r.globals.ERR_AUCTION_SOLD_S ~= "" and r.events.CHAT_MSG_SYSTEM),
    yes(r.events.AUCTION_OWNED_LIST_UPDATE and r.owned.saleStatusType == "number"), #r.stats))
  if not r.owned.windowOpen then message(L("Open the auction house and run /guilded probe auctions again to read the owned auction list.")) end
end
ns.runAuctionProbe = runAuctionProbe

ns.commandHandlers["probe"] = function(args)
  local what = string.lower((args and args[1]) or "")
  if what == "auctions" then
    if inCombatNow() then message(L("Not in combat.")); return end
    runAuctionProbe()
    return
  end
  if what == "guids" then
    -- Developer probe (docs/plans/CHARACTER_ID_MATCHING_2026-11-20.md, stage 0): read-only, chat frame only, nothing saved or sent.
    -- Does this client give UnitGUID for the player and a party member, and which GetGuildRosterInfo return is the GUID?
    if inCombatNow() then message(L("Not in combat.")); return end
    local function lowId(guid)
      if type(guid) ~= "string" or (ns.isSecret and ns.isSecret(guid)) then return nil end
      local hex = guid:match("^Player%-[^%-]*%-(%x+)$")
      return hex, hex and tonumber(hex, 16) or nil
    end
    local function show(label, guid)
      if guid == nil then message("GUID probe " .. label .. ": no value"); return end
      if ns.isSecret and ns.isSecret(guid) then message("GUID probe " .. label .. ": secret value"); return end
      local hex, dec = lowId(guid)
      message(string.format("GUID probe %s: %s -> low id %s (hex), %s (decimal)", label, tostring(guid), tostring(hex or "?"), tostring(dec or "?")))
    end
    show("player", UnitGUID and UnitGUID("player"))
    local member
    for i = 1, 4 do
      local unit = "party" .. i
      if UnitExists and UnitExists(unit) then member = unit; break end
    end
    if member then show(member, UnitGUID and UnitGUID(member)) else message("GUID probe party: not grouped") end
    if not GetGuildRosterInfo then message("GUID probe roster: no GetGuildRosterInfo"); return end
    if IsInGuild and not IsInGuild() then message("GUID probe roster: not in a guild"); return end
    for row = 1, 3 do
      local values = { pcall(GetGuildRosterInfo, row) }
      if not values[1] then message("GUID probe roster row " .. row .. ": call failed"); break end
      local found
      for index = 2, #values do
        local value = values[index]
        if type(value) == "string" and not (ns.isSecret and ns.isSecret(value)) and value:match("^Player%-[^%-]*%-%x+$") then found = index - 1; break end
      end
      if found then
        local hex, dec = lowId(values[found + 1])
        message(string.format("GUID probe roster row %d: return #%d = %s -> low id %s (hex), %s (decimal)", row, found, tostring(values[found + 1]), tostring(hex or "?"), tostring(dec or "?")))
      else
        message(string.format("GUID probe roster row %d: no GUID among %d returns", row, #values - 1))
      end
    end
    return
  end
  if what == "comm" then
    if string.lower((args and args[2]) or "") == "auto" then
      db.probes = type(db.probes) == "table" and db.probes or {}
      db.probes.commAuto = true
      message(L("Comm probe armed: it runs by itself 10 seconds after the next login or /reload."))
    else
      runCommProbe()
    end
    return
  end
  if what ~= "maps" then message(L("Usage: /guilded probe maps | comm | comm auto | auctions")); return end
  if inCombatNow() then message(L("Not in combat.")); return end
  if not (C_Map and C_Map.GetMapInfo) then message(L("This client has no map data to read.")); return end
  local rows = {}
  for id = 1, 3000 do
    local ok, info = pcall(C_Map.GetMapInfo, id)
    if ok and type(info) == "table" and type(info.name) == "string" then
      local parent = tonumber(info.parentMapID) or 0
      local left, right, top, bottom = "", "", "", ""
      if parent > 0 and C_Map.GetMapRectOnMap then
        local okRect, l, r, t, b = pcall(C_Map.GetMapRectOnMap, id, parent)
        if okRect and type(l) == "number" then left, right, top, bottom = string.format("%.5f", l), string.format("%.5f", r or 0), string.format("%.5f", t or 0), string.format("%.5f", b or 0) end
      end
      rows[#rows + 1] = table.concat({ id, (info.name:gsub("[|%c]", " ")), tostring(info.mapType or ""), parent, left, right, top, bottom }, "|")
    end
  end
  db.probes = type(db.probes) == "table" and db.probes or {}
  db.probes.maps = { at = now(), build = (GetBuildInfo and select(4, GetBuildInfo())) or 0, columns = "id|name|type|parent|left|right|top|bottom", rows = rows }
  if ns.logDiagnostic then ns.logDiagnostic("PROBE", string.format("%d maps read", #rows), true) end
  message(string.format(L("Map probe: %d maps written to the saved variables (probes.maps). Reload or log out to save the file."), #rows))
end
table.insert(ns.commandHelp, "/guilded probe maps - write the game's map ids, names and rectangles to the saved variables for diagnostics; /guilded probe comm [auto] - test addon messages on a temporary channel and by whisper; /guilded probe auctions - check read-only what this client offers for auction achievements; /guilded probe guids - print the player, party and roster GUIDs the client gives (developer probe)")

-- /guilded names: saved first-name keys (from before 8.5) that could not move to a full Forever
-- name on their own. Nothing is changed here; an officer moves or merges them by hand.
ns.commandHandlers["names"] = function()
  local lines = ns.util.nameMigrationLines and ns.util.nameMigrationLines(db) or {}
  if #lines == 0 then message(L("Every saved character uses its full name.")) return end
  message(string.format(L("%d saved entries still use a first name only:"), #lines))
  for index = 1, math.min(20, #lines) do message(lines[index]) end
end
table.insert(ns.commandHelp, "/guilded names - saved entries still filed under a first name shared by several characters (WoW Forever)")

-- Optional modules. Each can be turned off for yourself (/guilded modules off
-- casino) or for the whole guild by an officer (/guilded modules guild off
-- casino; shared through Modules/Sync.lua). Core (raids, EPGP, loot, gear
-- check) and Sync (standings, version check) always run: everything else
-- is built on them.
--
-- Saved settings only exist from PLAYER_LOGIN on, so modules are loaded
-- either way and stay dormant when off: their events, commands, help lines
-- and window tabs check ns.moduleActive(). Turning one off works at once;
-- turning one back on needs a /reload (it has to set itself up at login).
ns.MODULES = {
  { key = "bidding", name = "GP bidding", desc = "in-game GP bids on loot", commands = { "bid" } },
  { key = "council", name = "Loot council", desc = "BiS / upgrade / off-spec answers for loot council guilds", commands = { "council", "lc" } },
  { key = "reserve", name = "Soft reserves", desc = "reserve items for a raid, see who reserved what", commands = { "reserve", "res" } },
  { key = "recipes", name = "Recipes and cooldowns", desc = "who can craft what, profession cooldowns", commands = { "recipes", "cooldowns" } },
  { key = "dungeon", name = "Dungeons", desc = "dungeon run tracking and points", commands = { "dungeon" } },
  { key = "battleground", name = "Battleground capture", desc = "provisional own-character postmatch capture (always on where supported)", commands = { "bgcapture" } },
  { key = "calendar", name = "Calendar", desc = "guild calendar check", commands = { "calendar" } },
  { key = "syncnow", name = "Send to Discord", desc = "a Save button and reminder so the companion uploads sooner", commands = { "sync" } },
  { key = "autoinvite", name = "Auto-invite", desc = "a /ginvite line when someone whispers a phrase", commands = { "autoinvite", "invite" } },
  { key = "backup", name = "Backup and restore", desc = "copy this guild's saved data as one code", commands = { "backup", "restore" } },
  { key = "digest", name = "Login digest", desc = "what changed since your last login", commands = { "digest" } },
  { key = "chattab", name = "Guilded chat tab", desc = "Guilded's own lines in a separate chat tab", commands = { "chat" } },
  { key = "tooltip", name = "Item tooltips", desc = "who wants an item and what it costs, on item tooltips", commands = {} },
  { key = "consumables", name = "Consumable scan", desc = "who is missing a flask or food", commands = { "consumes" } },
  { key = "sim", name = "Test tools", desc = "fake raid and dungeon runs for officers", commands = { "sim" } },
  { key = "guildmap", name = "Guild map", desc = "guildmates on your world map and minimap", commands = { "map" } },
  { key = "scores", name = "Dungeon scores", desc = "a dungeon score per player from recorded runs, on tooltips", commands = { "score" } },
  { key = "guildevents", name = "Guild events", desc = "joins, leaves and rank changes in your chat, and a list of the recent ones", commands = { "events" } },
  { key = "guildlog", name = "Guild event log", desc = "joins, leaves, promotions and removals, kept longer than the game keeps them", commands = { "guildlog" } },
  { key = "recruit", name = "Recruiting", desc = "officers' prospect list", commands = { "recruit" } },
  { key = "chattags", name = "Main names in chat", desc = "the main's name next to an alt in guild and officer chat", commands = { "chattags" } },
  { key = "guildbank", name = "Guild bank snapshot", desc = "what the guild bank held when it was last opened", commands = { "gbank" } },
  { key = "pugcheck", name = "Pug gear check", desc = "item level and missing enchants of group members from outside the guild", commands = { "pugcheck" } },
  { key = "milestones", name = "Milestone announcements", desc = "level, first dungeon clear, honorable kills and duel wins in guild chat, if you turn them on", commands = { "milestones", "announce" } },
  { key = "raidsignup", name = "Raid sign-up", desc = "sign up for guild raids in game, with role and class counts", commands = { "signups" } },
  { key = "worldpvp", name = "World PvP stats", desc = "open-world kills, deaths, defends and calls for help; kills and deaths are shown by zone and position on the public pages of guilds that publish", commands = { "worldpvp", "wpvp" } },
  { key = "duels", name = "Guild duels", desc = "duel results between guildmates and a leaderboard", commands = { "duels" } },
  { key = "imports", name = "Loot imports", desc = "softres.it lists and That's My BiS priorities", commands = { "import", "tmb" } },
}
local MODULE_ALIASES = { map = "guildmap", score = "scores", bid = "bidding", bids = "bidding", gp = "bidding", lc = "council", reserves = "reserve", recipe = "recipes", cooldown = "recipes", crafting = "recipes", softres = "reserve", sr = "reserve", lootcouncil = "council", dungeons = "dungeon", test = "sim", tests = "sim", consumable = "consumables", consumes = "consumables", flask = "consumables",
  log = "guildlog", recruiting = "recruit", tags = "chattags", bank = "guildbank", gbank = "guildbank", pug = "pugcheck", tmb = "imports", import = "imports" }
local moduleByKey, commandModule, activeAtLogin = {}, {}, {}
for _, module in ipairs(ns.MODULES) do
  moduleByKey[module.key] = module
  for _, name in ipairs(module.commands) do commandModule[name] = module.key end
end

local function moduleSettings()
  return GuildedDB and GuildedDB.settings
end

-- Wanted by this player and allowed by the guild.
function ns.moduleEnabled(key)
  if not moduleByKey[key] then return true end
  local s = moduleSettings()
  if not s then return true end
  if s.modules and s.modules[key] == false then return false end
  if s.guildModules and s.guildModules.off and s.guildModules.off[key] then return false end
  return true
end

-- Enabled now AND was enabled at login (so it has set itself up).
function ns.moduleActive(key)
  if activeAtLogin[key] == nil then return ns.moduleEnabled(key) end
  return activeAtLogin[key] and ns.moduleEnabled(key)
end

function ns.moduleName(key)
  return moduleByKey[key] and moduleByKey[key].name or key
end

local function snapshotModules()
  for _, module in ipairs(ns.MODULES) do activeAtLogin[module.key] = ns.moduleEnabled(module.key) end
end

local function moduleStateText(key)
  local s = moduleSettings() or {}
  local guildOff = s.guildModules and s.guildModules.off and s.guildModules.off[key]
  if guildOff then return L("off for the guild") .. (s.guildModules.by and (" (" .. s.guildModules.by .. ")") or "") end
  if s.modules and s.modules[key] == false then return L("off (your choice)") end
  if not activeAtLogin[key] then return L("on after /reload") end
  return L("on")
end
ns.moduleStateText = moduleStateText

-- Guild-wide switches, shared by Sync.lua. Returns false for a stale update.
function ns.applyGuildModules(off, updatedAt, by)
  local s = moduleSettings()
  if not s then return false end
  local current = s.guildModules
  -- A switch dated in the future would pin itself forever; refuse it.
  if util.tooFarAhead(tonumber(updatedAt) or 0) then return false end
  if current and (current.updatedAt or 0) >= (updatedAt or 0) then return false end
  s.guildModules = { off = off or {}, updatedAt = updatedAt, by = by }
  return true
end

local function modulesCommand(args)
  local s = moduleSettings()
  if not s then return end
  local action = string.lower(args[2] or "list")
  local scope = "self"
  if action == "guild" then scope = "guild"; table.remove(args, 2); action = string.lower(args[2] or "list") end
  if action == "list" then
    message(L("Modules (Core raid/EPGP/loot/gear and standings always run):"))
    for _, module in ipairs(ns.MODULES) do
      message(string.format("  %s (%s) - %s: %s", L(module.name), module.key, L(module.desc), moduleStateText(module.key)))
    end
    message(L("/guilded modules on|off <module> - just for you. Officers: /guilded modules guild on|off <module> - for everyone."))
    return
  end
  if action ~= "on" and action ~= "off" then message(L("Usage: /guilded modules [list] | on|off <module> | guild on|off <module>")); return end
  local wanted = string.lower(args[3] or "")
  local key = MODULE_ALIASES[wanted] or wanted
  if not moduleByKey[key] then
    local keys = {}
    for _, module in ipairs(ns.MODULES) do table.insert(keys, module.key) end
    message(string.format(L("Unknown module '%s'. Modules: %s"), wanted, table.concat(keys, ", ")))
    return
  end
  local name = L(moduleByKey[key].name)
  if scope == "guild" then
    if not requireOfficer() then return end
    local off = {}
    for k, v in pairs(s.guildModules and s.guildModules.off or {}) do off[k] = v end
    off[key] = action == "off" or nil
    ns.applyGuildModules(off, (GetServerTime and GetServerTime()) or time(), playerName())
    if ns.onGuildModulesChanged then pcall(ns.onGuildModulesChanged) end
    message(string.format(L("%s is now %s for the whole guild (shared with online members)."), name, L(action)))
  else
    s.modules = s.modules or {}
    if action == "on" then s.modules[key] = nil else s.modules[key] = false end
    if action == "off" then
      message(string.format(L("%s is off for you. /guilded modules on %s to turn it back on."), name, key))
    elseif s.guildModules and s.guildModules.off and s.guildModules.off[key] then
      message(string.format(L("%s is turned off for the whole guild by an officer, so it stays off."), name))
    end
  end
  if action == "on" and scope == "self" and ns.moduleEnabled(key) then
    if activeAtLogin[key] then message(string.format(L("%s is on for you."), name))
    else message(string.format(L("%s is on. Type /reload to start it."), name)) end
  elseif action == "on" and scope == "guild" and ns.moduleEnabled(key) and not activeAtLogin[key] then
    message(string.format(L("%s is on. Type /reload to start it."), name))
  end
  if ns.onModulesChange then pcall(ns.onModulesChange) end
end

ns.commandModuleOf = function(name) return name and commandModule[string.lower(name)] end

local function command(text)
  if not db then message(L("Still loading, try again in a moment.")); return end
  local args = split(text)
  -- A bare /guilded opens the window (the help is long); /guilded help lists every command.
  if not args[1] and ns.commandHandlers and ns.commandHandlers["menu"] then
    ns.commandHandlers["menu"]({})
    return
  end
  local action = string.lower(args[1] or "help")
  if action == "help" then
    if string.lower(args[2] or "") == "all" then showFullHelp() else showHelp() end
  elseif action == "status" then
    message(activeRaid and string.format(L("Active raid: %s (started %s)"), activeRaid.title, activeRaid.startedAt) or L("No active raid."))
  elseif action == "roster" then
    local names = {}
    for name in pairs(db.roster) do
      if isGuildMember(name) then table.insert(names, name) end
    end
    table.sort(names)
    message(string.format(L("%d guild member(s): %s"), #names, table.concat(names, ", ")))
  elseif action == "snapshot" then
    if string.lower(args[2] or "") == "list" then listSnapshots()
    elseif requireOfficer() then takeSnapshot(table.concat(args, " ", 2)) end
  elseif action == "enchants" then
    local sub = string.lower(args[2] or "")
    if sub == "on" or sub == "off" then
      db.settings.enchantCheck = (sub == "on")
      message(sub == "on" and L("Enchant check on.") or L("Enchant check off."))
    elseif sub == "level" and tonumber(args[3]) then
      db.settings.enchantMinLevel = math.floor(tonumber(args[3]))
      message(string.format(L("Enchants are checked from level %d."), db.settings.enchantMinLevel))
    else
      message(string.format(L("Enchant check is %s, from level %d. /guilded enchants on|off|level <n>."),
        db.settings.enchantCheck ~= false and L("on") or L("off"), db.settings.enchantMinLevel or DEFAULT_ENCHANT_MIN_LEVEL))
    end
  elseif action == "slots" then
    local sub = string.lower(args[2] or "")
    if sub == "level" and tonumber(args[3]) then
      db.settings.slotMinLevel = math.max(1, math.floor(tonumber(args[3])))
      message(string.format(L("Empty gear slots count as not ready from level %d."), db.settings.slotMinLevel))
      inspectReadiness(true, "GUILD")
    else
      message(string.format(L("Empty gear slots count as not ready from level %d. /guilded slots level <n> (1 = always)."),
        db.settings.slotMinLevel or DEFAULT_SLOT_MIN_LEVEL))
    end
  elseif action == "share" then
    -- Refresh the gear check, then export everything about YOU in one paste.
    inspectReadiness(true, "GUILD")
    local info = collectCharacter()
    db.character = info
    local code = selfExportString(info, db.readiness[playerName()], db.attunements[playerName()])
    message(string.format(L("Your share code is %d characters (also shown in a box to copy). In Discord: /character link"), #code))
    showCharacterExport(code, "Guilded - copy this (Ctrl+C), then in Discord: /character link")
    ns.lastShareCode = code
  elseif action == "character" then
    local info = collectCharacter()
    db.character = info
    local line = characterString(info)
    message(string.format(L("Your character line (also shown in a box to copy): %s"), line))
    showCharacterExport(line)
  elseif action == "verify" then
    -- Retired in November 2026 (owner decision: links are confirmed by sync, the code was friction and
    -- confusion). The command stays for one release so a member typing it from habit gets one short
    -- line. A code already saved on this account is still repeated in the digest (the bot accepts
    -- already-issued codes for one release); "off" still removes it.
    if string.lower(args[2] or "") == "off" and db.verifyCode then
      db.verifyCode = nil
      inspectReadiness(true, "GUILD")
    end
    message(L("No longer needed: links are confirmed by sync."))
  elseif action == "start" then if requireOfficer() then raidStart(table.concat(args, " ", 2)) end
  elseif action == "end" then if requireOfficer() then raidEnd() end
  elseif action == "summary" then
    -- The running raid, else the last one recorded.
    local raid = activeRaid or db.raids[#db.raids]
    local text = table.concat(raidSummaryLines(raid), "\n")
    for _, line in ipairs(raidSummaryLines(raid)) do message(line) end
    if raid then showCharacterExport(text, "Guilded - raid summary: copy it (Ctrl+C) into Discord or a forum") end
  elseif action == "attendance" and string.lower(args[2] or "") == "group" then
    if requireOfficer() then groupAttendance(args[3]) end
  elseif action == "attendance" and string.lower(args[2] or "") == "seen" then
    if requireOfficer() then seenAttendance() end
  elseif action == "attendance" and string.lower(args[2] or "") == "roster" then
    if requireOfficer() then rosterAttendance() end
  elseif action == "note" then if requireOfficer() then raidNote(table.concat(args, " ", 2)) end
  elseif action == "template" or action == "templates" then if requireOfficer() then raidTemplate(args) end
  elseif action == "raid" and string.lower(args[2] or "") == "discard" then if requireOfficer() then discardRaid() end
  elseif action == "undo" then if requireOfficer() then voidEntry("last") end
  elseif action == "sheet" or action == "spreadsheet" or action == "excel" then sheetCommand(args[2])
  elseif action == "raids" and string.lower(args[2] or "") == "report" then
    local lines = raidReportLines(args[3])
    for _, line in ipairs(lines) do message(line) end
    if #db.raids > 0 then showCharacterExport(table.concat(lines, "\n"), "Guilded - attendance report: copy it (Ctrl+C) into Discord or a forum") end
  elseif action == "raids" then
    local lines = raidHistoryLines(args[2])
    for _, line in ipairs(lines) do message(line) end
    if #db.raids > 0 then showCharacterExport(table.concat(lines, "\n"), "Guilded - raid history: copy it (Ctrl+C) into Discord or a forum") end
  elseif action == "award" and string.lower(args[2] or "") == "group" then
    if requireOfficer() then groupAward(args[3], table.concat(args, " ", 4)) end
  elseif action == "attendance" then if requireOfficer() then setAttendance(args[2], args[3]) end
  elseif action == "boss" then if requireOfficer() then bossKill(table.concat(args, " ", 2)) end
  elseif action == "award" then if requireOfficer() then changeEpgp(args[2], args[3], table.concat(args, " ", 4), "EP_AWARD") end
  elseif action == "gp" then if requireOfficer() then changeEpgp(args[2], args[3], table.concat(args, " ", 4), "GP_AWARD") end
  elseif action == "deduct" then if requireOfficer() then changeEpgp(args[2], args[3], table.concat(args, " ", 4), "ADJUSTMENT") end
  elseif action == "gpdeduct" then if requireOfficer() then changeEpgp(args[2], args[3], table.concat(args, " ", 4), "GP_DEDUCT") end
  elseif action == "loot" then if requireOfficer() then recordLoot(args) end
  elseif action == "void" then if requireOfficer() then voidEntry(args[2]) end
  elseif action == "attune" and ns.attunements and (function()
      local sub = string.lower(args[2] or "")
      return sub == "auto" or sub == "track" or sub == "untrack" or sub == "tracked"
    end)() then
    ns.attunements.command(args)
  elseif action == "attune" then
    local completed = true
    local last = string.lower(args[#args] or "")
    if #args > 2 and (last == "false" or last == "clear" or last == "no") then
      completed = false
      table.remove(args, #args)
    end
    -- "/guilded attune Onyxia Key" is a key for yourself; the first word is only
    -- treated as a player when it is a known guild member and a key follows.
    local target = playerName()
    local keyStart = 2
    local candidate = normalizeName(args[2])
    if args[3] and candidate and isGuildMember(candidate) and candidate ~= playerName() then
      target, keyStart = candidate, 3
    end
    local key = table.concat(args, " ", keyStart)
    if key == "" then message(L("Usage: /guilded attune <key> [clear] | /guilded attune <player> <key> [clear]")); return end
    if target ~= playerName() and not requireOfficer() then return end
    setAttunement(target, key, completed)
  elseif action == "inspect" then inspectReadiness()
  elseif action == "export" then if requireOfficer() then exportData() end
  elseif action == "diag" then showDiagnostics({ args[2] })
  elseif action == "officer" then officerCommand(args)
  elseif action == "modules" or action == "module" then modulesCommand(args)
  elseif commandModule[action] and not ns.moduleActive(commandModule[action]) then
    local key = commandModule[action]
    message(string.format(L("%s is %s. /guilded modules to see or change it."), L(ns.moduleName(key)), moduleStateText(key)))
  elseif ns.removedCommands[action] then
    local removed = ns.removedCommands[action]
    if type(removed) == "table" and removed.since == false then
      message(string.format(L("/guilded %s was removed: %s"), action, L(removed.text)))
    else
      message(string.format(L("/guilded %s was removed in 9.2: %s"), action, L(type(removed) == "table" and removed.text or removed)))
    end
  elseif ns.commandHandlers[action] then
    -- args[1] is the action itself; hand the module the remaining tokens.
    table.remove(args, 1)
    ns.commandHandlers[action](args)
  else showHelp() end
end

local parseRoll = ns.createRollParser(normalizeName, isSecret)

local function handlePeerReadiness(text, sender, channel)
  local parts = {}
  for part in string.gmatch(text, "[^|]+") do table.insert(parts, part) end
  if parts[1] ~= "READINESS" or not parts[2] then return end
  -- A client may only report its own character; otherwise anyone could
  -- overwrite a guildmate's readiness in every officer's export.
  -- (8.5) An older addon names a Forever character by first name only: still the sender's own
  -- digest when the first name matches; it is kept under the sender's full name.
  local name = normalizeName(sender)
  if not name or not ns.util.sameCharacter(parts[2], sender) then return end
  -- The guild channel only carries guildmates; in a raid or party a pug's digest would end
  -- up in every officer's export (and the bot would "discover" them), so only members count.
  if channel ~= "GUILD" and not isGuildMember(name) then return end
  -- The text comes from another player's client. Only well-formed pieces are kept: this ends
  -- up in the officer's upload, and one odd value must not spoil it.
  local professions, flags, identity, professionsAt, verify, peerId = "", "", nil, nil, nil, nil
  for index = 6, #parts do
    if string.sub(parts[index], 1, 3) == "ID=" then peerId = ns.util.validId(string.sub(parts[index], 4))
    elseif string.sub(parts[index], 1, 2) == "F:" then flags = string.sub(parts[index], 3, 120)
    -- Kept under the sender's name only (checked above), which is what makes it proof.
    elseif string.sub(parts[index], 1, 2) == "V:" then verify = validVerifyCode(string.sub(parts[index], 3))
    elseif string.sub(parts[index], 1, 2) == "I:" then
      local class, race, level, spec = string.match(string.sub(parts[index], 3), "^([^,]*),([^,]*),(%d*),?(.*)$")
      level = tonumber(level) or 0
      if class and string.match(class, "^%u+$") and #class <= 20 then
        identity = {
          class = class, race = string.match(race or "", "^%a+$") and string.sub(race, 1, 30) or "",
          level = (level >= 0 and level <= 100) and level or 0, spec = string.sub(spec or "", 1, 40)
        }
      end
    elseif string.sub(parts[index], 1, 2) == "P:" then professionsAt = tonumber(string.sub(parts[index], 3))
    elseif professions == "" then
      local kept = {}
      for profession, skill in string.gmatch(parts[index], "([^:,]+):(%d+)") do
        if #kept < 10 and #profession <= 40 and #skill <= 4 then table.insert(kept, profession .. ":" .. skill) end
      end
      professions = table.concat(kept, ",")
      -- An older client sends its own language's names: store the canonical ones.
      if ns.util and ns.util.professionSkillText then professions = ns.util.professionSkillText(professions) end
    end
  end
  local STATUSES = { READY = true, PARTIAL = true, NOT_READY = true }
  local previous = db.peerRoster[name]
  if previous and previous.professionsAt and (not professionsAt or previous.professionsAt > professionsAt) then
    professions, professionsAt = previous.professions, previous.professionsAt
  end
  -- A digest that lacks the identity (an older client, or one whose message ran long) keeps the identity (the verify code is not kept: a digest without it means the player turned it off).
  if previous then
    identity = identity or previous.identity
  end
  db.peerRoster[name] = {
    status = STATUSES[parts[3] or ""] and parts[3] or "UNKNOWN",
    missing = math.max(0, math.min(20, tonumber(parts[4]) or 0)),
    minDurability = math.max(0, math.min(100, tonumber(parts[5]) or 100)),
    professions = professions,
    professionsComplete = professionsAt ~= nil,
    professionsAt = professionsAt,
    flags = flags,
    identity = identity,
    id = peerId or (previous and previous.id) or nil,
    verify = verify,
    updatedAt = now(),
    -- When it arrived (seconds), so the Ready page can say how old it is.
    seenAt = (GetServerTime and GetServerTime()) or time(),
    reportedBy = name
  }
  if ns.onPeerReadiness then pcall(ns.onPeerReadiness, name) end
end

-- A "ready check" from someone in your raid or party: look at yourself again and answer on
-- the group channel. At most once per 20 seconds, never in combat, and only when it
-- came through the raid or party channel (not from a stranger's whisper).
local lastReadyAnswerAt = 0
local lastProfessionAnswerAt = 0
local function handleReadyRequest(channel, sender)
  if channel ~= "RAID" and channel ~= "PARTY" then return end
  -- Only an officer, the group leader or an assistant can ask (not any random raider).
  if not (ns.ready and ns.ready.isRequester and ns.ready.isRequester(sender)) then return end
  if (InCombatLockdown and InCombatLockdown()) then return end
  local nowSeconds = (GetServerTime and GetServerTime()) or time()
  if nowSeconds - lastReadyAnswerAt < 20 then return end
  lastReadyAnswerAt = nowSeconds
  if ns.inspectReadiness then pcall(ns.inspectReadiness, true, channel) end
  -- Also share what you carry right now (flask, food, weapon enchant, ...): the requester's
  -- page shows it even when the game hides your buffs from them.
  if ns.ready and ns.ready.broadcastSelf then pcall(ns.ready.broadcastSelf, channel) end
end

-- ---------------------------------------------------------------------
-- One saved-data set per WoW guild. A WoW install with characters in two
-- guilds must not mix their ledgers, rosters and raids, so the active data
-- lives at the top of GuildedDB (every module reads it as before) and the
-- data of other guilds is parked in GuildedDB.otherGuilds[key]. When the
-- character's guild differs from the one the data belongs to, the two are
-- swapped in place. The guild is only known once the client has loaded it,
-- so this is tried on entering the world and on guild roster updates.
-- ---------------------------------------------------------------------
local KEEP_AT_ROOT = { version = true, guildKey = true, guildEdition = true, otherGuilds = true, bridgeCompanionGuild = true }
local guildResolved = false

-- WoW Forever's realms are synced server segments: GetRealmName differs per character, but the
-- fourth GetGuildInfo result is the guild's home realm when the character is on another segment.
-- Reading it makes every guildmate (and every alt on this PC) share one guild key.
local function guildHomeRealm()
  if not (ns.util.isForever() and GetGuildInfo) then return nil end
  local ok, _, _, _, home = pcall(GetGuildInfo, "player")
  if ok and type(home) == "string" and home ~= "" and not isSecret(home) then return home end
  return nil
end

-- Forever realm names arrive both with spaces ("CAMWOW US2 Realm 2 PvP", GetRealmName) and
-- without ("CAMWOWUS2Realm2PvP", the home realm from GetGuildInfo): keys always use the compact form.
local function compactRealm(realm)
  return (string.gsub(realm, "%s+", ""))
end

-- How much guild data a saved set holds (roster entries and dungeon runs): the tie-break between two stored keys.
local function guildDataWeight(data)
  local n = 0
  if type(data) ~= "table" then return n end
  for _ in pairs(type(data.roster) == "table" and data.roster or {}) do n = n + 1 end
  local runs = type(data.dungeon) == "table" and data.dungeon.runs
  for _ in pairs(type(runs) == "table" and runs or {}) do n = n + 1 end
  return n
end

-- The key already stored for this guild name. Used when the game gives no realm at all (Forever 1.60.1 hides realm
-- names), so the existing key stays the identity. (9.4.6) Several keys of one guild name can be stored: the real
-- "Guild-<realm>" key, an old spaced spelling already merged into it (mergedIntoHome) and a "Guild-" key that 9.4.4
-- created when the realm went blank (it parked the real data). The order is: never an alias already merged into another
-- key, a key with a realm over "Guild-", the compact realm spelling over a spaced one, the active key over a parked one,
-- the one holding more data, then the alphabetical first. Only a guild never stored gets "Guild-" (in currentGuildKey).
local function storedKeyForGuild(guildName)
  local prefix = guildName .. "-"
  local function matches(key)
    return type(key) == "string" and string.sub(key, 1, #prefix) == prefix and not string.find(string.sub(key, #prefix + 1), "-", 1, true)
  end
  local candidates = {}
  local function consider(key, data, active)
    if not matches(key) then return end
    local realm = string.sub(key, #prefix + 1)
    candidates[#candidates + 1] = { key = key, data = data, rank = {
      (type(data) == "table" and data.mergedIntoHome) and 0 or 1,
      realm ~= "" and 1 or 0,
      string.find(realm, "%s") and 0 or 1,
      active and 1 or 0,
    } }
  end
  if not db then return nil end
  consider(db.guildKey, db, true)
  if type(db.otherGuilds) == "table" then
    for key, data in pairs(db.otherGuilds) do
      if key ~= db.guildKey then consider(key, data, false) end
    end
  end
  local function better(a, b)
    for i = 1, #a.rank do
      if a.rank[i] ~= b.rank[i] then return a.rank[i] > b.rank[i] end
    end
    a.weight = a.weight or guildDataWeight(a.data)
    b.weight = b.weight or guildDataWeight(b.data)
    if a.weight ~= b.weight then return a.weight > b.weight end
    return a.key < b.key
  end
  local best
  for _, candidate in ipairs(candidates) do
    if not best or better(candidate, best) then best = candidate end
  end
  return best and best.key or nil
end

-- Returns the guild key, the key built from this character's own realm (same form), and that key
-- as older versions wrote it (spaces kept). The fourth result is whether the home realm is known:
-- on Forever a missing home realm may only mean the guild info has not arrived yet.
local function currentGuildKey()
  if not (IsInGuild and IsInGuild()) then return nil end
  local guildName = GetGuildInfo and GetGuildInfo("player")
  if type(guildName) ~= "string" or guildName == "" or isSecret(guildName) then return nil end
  local realm = (ns.compat and ns.compat.identity().realm) or (GetRealmName and GetRealmName()) or ""
  if type(realm) ~= "string" or isSecret(realm) or realm == "0" then realm = "" end
  local rawOwn = guildName .. "-" .. realm
  local home = guildHomeRealm()
  if ns.util.isForever() and home == nil and realm == "" then
    -- (WoW Forever 1.60.1) The game no longer reveals any realm: keep the key this guild is already stored under, so
    -- only the realm part disappearing is never taken for a guild switch. Nothing is parked, nothing is reset.
    local key = storedKeyForGuild(guildName) or (guildName .. "-")
    return key, key, key, true
  end
  if ns.util.isForever() then
    return guildName .. "-" .. compactRealm(home or realm), guildName .. "-" .. compactRealm(realm), rawOwn, home ~= nil
  end
  return guildName .. "-" .. (home or realm), rawOwn, rawOwn, home ~= nil
end
ns.currentGuildKey = currentGuildKey

-- Returns "recorded", "same", "switched" or nil (guild not known yet / no guild).
-- (The Lua test harness sets GUILDED_TEST_HOME_WAIT so ordinary tests do not wait.)
local HOME_WAIT_SECONDS = rawget(_G, "GUILDED_TEST_HOME_WAIT") or 20
local homeWaitStart, homeWaitOver
local function homeNow() return (GetServerTime and GetServerTime()) or time() end
local function guildPart(text) return (string.match(text, "^(.*)%-[^%-]*$")) or text end
-- A key with its realm part written without spaces (the guild name keeps its own spaces: "Quebec Gold-CAMWOWUS2Realm2PvP").
local function compactGuildKey(text)
  local guild, realm = string.match(text, "^(.*)%-([^%-]*)$")
  if not guild then return text end
  return guild .. "-" .. compactRealm(realm)
end
-- Never merged between guild keys: points are only ever owned by the key that earned them.
local function isLedgerField(field)
  return field == "epgp" or field == "dkp" or string.find(string.lower(tostring(field)), "ledger", 1, true) ~= nil
end

-- (9.4.6) Moves into `home` what a second saved set of the SAME guild holds and `home` lacks: whole sections `home`
-- has empty (never points, settings or bookkeeping), and every dungeon run by id. A run both hold stays home's copy
-- (marked synced when the other copy was confirmed by the bot). Whatever moved, or was a duplicate run, leaves `from`,
-- so nothing is saved twice and the companion never sends a run from both places. Returns sections moved, runs moved.
local FOLD_SKIP = { settings = true, mergedIntoHome = true, parkedAt = true }
local function foldGuildData(home, from)
  local sections, runsMoved = 0, 0
  if type(home) ~= "table" or type(from) ~= "table" or home == from then return sections, runsMoved end
  for field, value in pairs(from) do
    local have = home[field]
    local empty = have == nil or (type(have) == "table" and next(have) == nil)
    if not FOLD_SKIP[field] and not KEEP_AT_ROOT[field] and not isLedgerField(field) and empty
      and not (type(value) == "table" and next(value) == nil) then
      home[field] = value
      sections = sections + 1
    end
  end
  for field in pairs(home) do
    if from[field] ~= nil and from[field] == home[field] then from[field] = nil end
  end
  local fromRuns = type(from.dungeon) == "table" and type(from.dungeon.runs) == "table" and from.dungeon.runs
  if fromRuns and type(home.dungeon) == "table" then
    if type(home.dungeon.runs) ~= "table" then home.dungeon.runs = {} end
    local homeRuns = home.dungeon.runs
    local ids = {}
    for id in pairs(fromRuns) do ids[#ids + 1] = id end
    for _, id in ipairs(ids) do
      local run, mine = fromRuns[id], homeRuns[id]
      if mine == nil then
        homeRuns[id] = run
        runsMoved = runsMoved + 1
      elseif type(run) == "table" and type(mine) == "table" and run.synced and not mine.synced then
        mine.synced = run.synced
      end
      fromRuns[id] = nil
    end
  end
  return sections, runsMoved
end

-- (9.4.6) An older spelling of this guild's key ("Guild-CAMWOW US2 Realm 2 PvP") that an earlier merge already folded
-- into it (mergedIntoHome): move any run it still holds into the loaded data and drop it, unless it holds points.
local function dropMergedAliases(key)
  if type(db.otherGuilds) ~= "table" then return end
  local drop = {}
  for otherKey, parked in pairs(db.otherGuilds) do
    if otherKey ~= key and type(parked) == "table" and parked.mergedIntoHome == key and type(otherKey) == "string"
      and compactGuildKey(otherKey) ~= otherKey and compactGuildKey(otherKey) == key then
      foldGuildData(db, parked)
      if not hasPoints(parked) and not hasUnsyncedRun(parked) then drop[#drop + 1] = otherKey end
    end
  end
  for _, otherKey in ipairs(drop) do db.otherGuilds[otherKey] = nil end
end

local function resolveGuildData()
  if not db then return nil end
  local key, ownRealmKey, rawOwnKey, homeKnown = currentGuildKey()
  if not key then return nil end
  local edition = ns.util.gameEdition()
  local oldEdition = db.guildEdition or edition
  -- Saved before the realm was written without spaces: the same key, spelled the old way. (9.4.6) Not when data is
  -- already parked under the compact spelling: renaming would hide it behind the loaded key; the alias repair below folds it.
  if edition == "forever" and oldEdition == edition and db.guildKey and db.guildKey ~= key
    and compactGuildKey(db.guildKey) == key and not (type(db.otherGuilds) == "table" and db.otherGuilds[key]) then
    db.guildKey = key
  end
  -- Forever: the guild's home realm may not have arrived with the guild name. Until it does (or
  -- a short wait is over), do not file anything under this character's own realm, which would
  -- strand the data for characters on the guild's own segment. Nothing is lost meanwhile: the
  -- data sits at the root of the saved file and only gets its guild label once settled.
  if edition == "forever" and not homeKnown and db.guildKey ~= key and not homeWaitOver then
    homeWaitStart = homeWaitStart or homeNow()
    if homeNow() - homeWaitStart < HOME_WAIT_SECONDS then return nil end
    homeWaitOver = true
  end
  -- Settled on this guild for the session. A later guild or realm change
  -- (common on launch day, and not always followed by /reload) still swaps.
  if guildResolved and db.guildKey == key and oldEdition == edition then return nil end
  local function storageKey(guildKey, gameEdition)
    return gameEdition == "forever" and guildKey or gameEdition .. "@" .. guildKey
  end
  guildResolved = true
  if not db.guildKey then
    -- First time: the data already saved belongs to this guild.
    db.guildKey = key
    db.guildEdition = edition
    return "recorded"
  end
  if db.guildKey == key and oldEdition == edition then
    db.guildEdition = edition
    if edition == "forever" then dropMergedAliases(key) end
    return "same"
  end
  local old = db.guildKey
  db.otherGuilds = db.otherGuilds or {}
  -- Saved before the guild's home realm was used: the key was built from this character's own
  -- realm, which is the same guild name, so only the realm part moves. Nothing is parked.
  if edition == "forever" and oldEdition == edition and (old == ownRealmKey or old == rawOwnKey) and key ~= ownRealmKey and not db.otherGuilds[key] then
    db.guildKey = key
    db.guildEdition = edition
    return "rekeyed"
  end
  -- Only an explicitly recorded Forever realm alias can rename a scope.
  -- Matching guild names alone never establish identity across realms.
  local aliases = db.settings and db.settings.guildRealmAliases
  if edition == "forever" and oldEdition == edition and type(aliases) == "table" and aliases[old] == key
    and guildPart(old) == guildPart(key) and not db.otherGuilds[key] then
    db.guildKey = key
    db.guildEdition = edition
    message(string.format(L("Guild realm changed from \"%s\" to \"%s\": your saved data was kept (same guild name)."), old, key))
    return "rekeyed"
  end
  local parked = {}
  for field, value in pairs(db) do
    if not KEEP_AT_ROOT[field] then parked[field] = value end
  end
  for field in pairs(parked) do db[field] = nil end
  parked.parkedAt = homeNow()
  db.otherGuilds[storageKey(old, oldEdition)] = parked
  local incoming = db.otherGuilds[storageKey(key, edition)]
  db.otherGuilds[storageKey(key, edition)] = nil
  -- The data saved under this character's own realm (a first load before the home realm was
  -- known) belongs to the same guild: copy what the home data does not already have into it,
  -- once. Points are never merged; they stay under the old key.
  local mergedFields
  -- (9.4.6) Repair: the loaded data sat under another spelling of this same guild's key while the real data was parked
  -- under this key. 9.4.4 did that when Forever 1.60.1 blanked the realm ("Guild-" took over and parked "Guild-<realm>"),
  -- and an alt's guild switch could restore the old spaced spelling. The real data comes back and what the other
  -- spelling recorded meanwhile is folded into it (runs by id, sections it lacks; points never). The rest stays parked,
  -- marked merged, so it is never chosen again; the half-year trim forgets it.
  local blankKey = guildPart(key) .. "-"
  if incoming and edition == "forever" and oldEdition == edition and old ~= key and guildPart(old) == guildPart(key)
    and key ~= blankKey and (old == blankKey or compactGuildKey(old) == key) then
    local sections, runs = foldGuildData(incoming, parked)
    parked.mergedIntoHome = key
    for field, value in pairs(incoming) do db[field] = value end
    db.parkedAt = nil
    db.mergedIntoHome = nil
    db.guildKey = key
    db.guildEdition = edition
    ensureDb()
    dropMergedAliases(key)
    message(string.format(L("Guild data repaired: %s is loaded again and what was saved under %s meanwhile was added to it (%d sections, %d dungeon runs). EP/GP is never merged. /reload is recommended."),
      key, old, sections, runs))
    return "repaired"
  end
  if incoming and edition == "forever" and oldEdition == edition and guildPart(old) == guildPart(key)
    and (old == ownRealmKey or old == rawOwnKey) and not parked.mergedIntoHome then
    mergedFields = 0
    for field, value in pairs(parked) do
      local have = incoming[field]
      local empty = have == nil or (type(have) == "table" and next(have) == nil)
      if field ~= "settings" and field ~= "mergedIntoHome" and field ~= "parkedAt" and not isLedgerField(field) and empty
        and not (type(value) == "table" and next(value) == nil) then
        incoming[field] = value
        mergedFields = mergedFields + 1
      end
    end
    parked.mergedIntoHome = key
  end
  local restored = false
  if incoming then
    for field, value in pairs(incoming) do db[field] = value end
    db.parkedAt = nil
    restored = true
  end
  db.guildKey = key
  db.guildEdition = edition
  ensureDb()
  if edition == "forever" and restored then dropMergedAliases(key) end
  if mergedFields then
    message(string.format(L("Saved data under %s was merged into %s (%d sections). EP/GP stays under the old name. /reload is recommended."), old, key, mergedFields))
    return "merged"
  end
  message(string.format(L("Guild changed: now using the saved data for %s (%s). Data for %s is kept and comes back if you play there. /reload is recommended."),
    key, restored and L("restored") or L("new"), old))
  return "switched"
end

-- Every character that logs in on this PC, per guild: a paired companion links them all to the
-- same Discord member, so alts need no /character link. Written only once the character's
-- guild is known and is the guild the loaded data belongs to: at login the data of the guild
-- played last is still loaded, and a character of another guild must not land in its list.
local function noteMyCharacter(info)
  if type(info) ~= "table" or not info.name or info.name == "Unknown" then return end
  local key = currentGuildKey()
  if not key or (db.guildKey and db.guildKey ~= key) then return end
  db.myCharacters = db.myCharacters or {}
  local key = ns.util.characterKey(info.name, info.realm)
  db.myCharacters[key] = info
  local count, oldestName, oldestAt = 0, nil, nil
  for name, entry in pairs(db.myCharacters) do
    count = count + 1
    if not oldestAt or (entry.capturedAt or "") < oldestAt then oldestName, oldestAt = name, entry.capturedAt or "" end
  end
  if count > 50 and oldestName and oldestName ~= key then db.myCharacters[oldestName] = nil end
end

-- (9.4.8) Every module that keeps a copy in the guild's saved data hears when that data was switched, re-keyed or repaired.
do
  local resolveRaw = resolveGuildData
  resolveGuildData = function()
    local result = resolveRaw()
    if result and result ~= "same" and ns.onGuildDataSwitched then pcall(ns.onGuildDataSwitched, result) end
    return result
  end
end

-- Joining a guild mid-session: GetGuildInfo stays empty for a few seconds after
-- PLAYER_GUILD_UPDATE, and no roster update may follow until the guild window is opened, so
-- the guild was only picked up after a /reload. Try again now and a few times after.
local GUILD_RETRY_SECONDS = { 2, 5, 15, 25 }
local function resolveGuildSoon()
  local function try()
    if not db then return end
    local resolved = resolveGuildData()
    -- (9.3.7) The character block was captured before the guild was known (no rank, old time): take a fresh one now, so
    -- the saved file shows this character with its new guild, rank and time and the companion exports it on the next upload.
    local stale = type(db.character) == "table" and db.character.guildRankName == nil and currentGuildKey() ~= nil
    if resolved or stale then
      local ok, captured = pcall(collectCharacter)
      if ok and type(captured) == "table" then db.character = captured end
      noteMyCharacter(db.character)
    end
  end
  try()
  if C_Timer and C_Timer.After then
    for _, delay in ipairs(GUILD_RETRY_SECONDS) do C_Timer.After(delay, try) end
  end
end

local function onEvent(_, event, ...)
  if event == "PLAYER_LOGIN" then
    ensureDb()
    -- Keep the character block fresh for the companion export.
    local capturedOk, captured = pcall(collectCharacter)
    if capturedOk then
      db.character = captured
      noteMyCharacter(captured)
    end
    snapshotModules()
    registerPrefix()
    -- A map or auction probe stays for one more login so the companion can upload it, then goes.
    if type(db.probes) == "table" then
      -- Kept through one more login (the companion exports the saved file in between), then dropped: the file does not grow.
      for _, kind in ipairs({ "maps", "auctions" }) do
        local probe = db.probes[kind]
        if type(probe) == "table" then
          probe.logins = (tonumber(probe.logins) or 0) + 1
          if probe.logins >= 2 then db.probes[kind] = nil end
        else
          db.probes[kind] = nil
        end
      end
      if db.probes.commAuto then
        db.probes.commAuto = nil
        if C_Timer and C_Timer.After then C_Timer.After(10, function() pcall(ns.runCommProbe) end) end
      end
    end
    ns.loginAt = GetTime and GetTime() or 0
    ns.infoMessage(activeRaid
      and string.format(L("Loaded. /guilded help for commands - raid '%s' is still active."), activeRaid.title)
      or L("Loaded. /guilded help for commands."))
    for _, pending in ipairs(pendingDiagnostics) do
      logDiagnostic(pending.kind, pending.detail, pending.foreign)
    end
    pendingDiagnostics = {}
    if validVerifyCode(db.verifyCode) then scheduleVerifyResend() end
    return
  end
  if not db then return end
  if event == "PLAYER_ENTERING_WORLD" then
    -- On Forever the home realm can arrive after the guild name: retry for a bit.
    if ns.util.isForever() then resolveGuildSoon() else resolveGuildData() end
    db.character = collectCharacter()
    noteMyCharacter(db.character)
    maybeAutoSync(AUTO_SYNC_DEBOUNCE_SECONDS)
  elseif event == "SKILL_LINES_CHANGED" then
    -- Fires on every skill-up (skinning, weapon skills): one check per burst is enough.
    if skillCheckPending then return end
    if C_Timer and C_Timer.After then skillCheckPending = true; C_Timer.After(1, function()
      skillCheckPending = false
      db.character = collectCharacter()
      noteMyCharacter(db.character)
      inspectReadiness(true, "GUILD", 0)
      if ns.recipes and ns.recipes.pruneMine then ns.recipes.pruneMine() end
    end) end
  elseif event == "UNIT_INVENTORY_CHANGED" then
    local unit = ...
    if unit == "player" then deferWork("inventory-sync", 3, function() maybeAutoSync(AUTO_SYNC_DEBOUNCE_SECONDS) end) end
  elseif event == "PLAYER_TALENT_UPDATE" or event == "CHARACTER_POINTS_CHANGED" or event == "ACTIVE_TALENT_GROUP_CHANGED" then
    local ok, captured = pcall(collectCharacter)
    if ok then
      db.character = captured
      noteMyCharacter(captured)
      maybeAutoSync(AUTO_SYNC_DEBOUNCE_SECONDS)
    end
  elseif event == "GROUP_ROSTER_UPDATE" then
    if activeRaid then recordPresence() end
    if inRaidGroup() then maybeAutoSync(AUTO_SYNC_RAID_INTERVAL_SECONDS) end
  elseif event == "PLAYER_GUILD_UPDATE" then
    ledgerRoster = nil
    resolveGuildSoon()
  elseif event == "GUILD_ROSTER_UPDATE" then
    ledgerRoster = nil
    -- (9.1.7) The full scan below walks the whole roster; a burst of updates runs it once (owner log: 95 ms).
    deferWork("roster-scan", 2, function()
    -- Before anything is added to the roster: make sure it is the right guild's data.
    if resolveGuildData() then noteMyCharacter(db.character) end
    local count = GetNumGuildMembers and GetNumGuildMembers() or 0
    db.lastRosterUpdate = now()
    local inRoster = {}
    for i = 1, count do
      local rawName, rosterRankName, rosterRankIndex = GetGuildRosterInfo(i)
      ns.util.rememberDisplayName(rawName)
      local name = normalizeName(rawName)
      if name then
        inRoster[name] = true
        local entry = db.roster[name]
        if not entry then
          entry = { firstSeen = now(), inGuild = true, joinedAt = now() }
          db.roster[name] = entry
        elseif entry.inGuild == false then
          entry.inGuild, entry.joinedAt, entry.leftAt = true, now(), nil
        end
        -- The roster is this guild's own, so the rank belongs to this guild (exported per character).
        if type(rosterRankName) == "string" and not isSecret(rosterRankName) and rosterRankName ~= ""
          and type(rosterRankIndex) == "number" and rosterRankIndex >= 0 and rosterRankIndex < 20 then
          entry.rankName, entry.rankIndex = string.sub(rosterRankName, 1, 60), rosterRankIndex
        end
      end
    end
    -- Forever (8.5): first-name keys from older saved data move to the full name the roster
    -- just listed, before anyone is marked as having left (Util.lua, util.migrateForeverNames).
    if count > 0 and ns.util.migrateForeverNames then
      local okMigrate, result = pcall(ns.util.migrateForeverNames, db)
      if okMigrate and result.flagged > 0 and isOfficer() then
        ns.infoMessage(string.format(L("%d saved entries use a first name shared by several characters. /guilded names lists them."), result.flagged))
      end
    end
    -- A full roster that no longer lists someone means they left. Nothing is concluded from
    -- an empty roster (not loaded yet) or one that hides offline members.
    local showsOffline = true
    if GetGuildRosterShowOffline then
      local ok, value = pcall(GetGuildRosterShowOffline)
      if ok and value == false then showsOffline = false end
    end
    if next(inRoster) and showsOffline then
      for name, entry in pairs(db.roster) do
        if not inRoster[name] and entry.inGuild ~= false then entry.inGuild, entry.leftAt = false, now() end
      end
    end
    end, true)
  elseif event == "CHAT_MSG_LOOT" and db.settings.captureLoot then
    local text = ...
    if not isSecret(text) then logEvent("LOOT_HINT", { text = text }) end
  elseif event == "CHAT_MSG_ADDON" then
    local prefix, text, channel, sender = ...
    if not comm.accept(prefix, text, channel, sender, PREFIX) then return end
    if isSecret(prefix) or isSecret(text) or isSecret(sender) then return end
    if prefix ~= PREFIX or normalizeName(sender) == playerName() then return end
    if string.sub(text, 1, 10) == "READINESS|" then
      -- Every online guildmate sends these; keep them out of the journal.
      handlePeerReadiness(text, sender, channel)
    elseif string.sub(text, 1, 8) == "PROFREQ|" and channel == "GUILD" then
      local epoch = (GetServerTime and GetServerTime()) or time()
      if epoch - lastProfessionAnswerAt >= 20 then
        lastProfessionAnswerAt = epoch
        -- (9.2.1) Not inside the receive handler: the full readiness check was the slow CHAT_MSG_ADDON entry.
        deferWork("profession-answer", 1, function() inspectReadiness(true, "GUILD") end)
      end
    elseif string.sub(text, 1, 9) == "READYREQ|" then
      handleReadyRequest(channel, sender)
    elseif string.sub(text, 1, 11) == "ATTUNEMENT|" then
      -- Other players' own attunements (Modules/Attunements.lua keeps only self-reports).
      if ns.attunements and ns.attunements.handleMessage then pcall(ns.attunements.handleMessage, text, channel, sender) end
    elseif string.sub(text, 1, 7) == "LEDGER|" or string.sub(text, 1, 11) == "LEDGERVOID|" then
      handlePeerLedger(text, channel, sender)
    elseif string.sub(text, 1, 8) == "CONSUME|" then
      -- What a groupmate carries, sent by their own addon (Modules/Ready.lua checks who and where).
      if ns.ready and ns.ready.handleReport then pcall(ns.ready.handleReport, text, channel, sender) end
    else
      -- Everything else on this prefix is informational (other officers' raid, loot and
      -- EP lines). It is not saved: a chatty or broken client would push real history out
      -- of the journal and keep marking the data as changed. /guilded diag shows the count.
      ns.ignoredMessages = (ns.ignoredMessages or 0) + 1
    end
  elseif event == "ADDON_ACTION_BLOCKED" or event == "ADDON_ACTION_FORBIDDEN" then
    -- Fires with the exact addon and function name WoW refused to let run --
    -- this is the precise diagnostic the "blocked from an action only
    -- available to the Blizzard UI" popup itself doesn't show you.
    local blockedAddon, blockedFunction = ...
    local detail = string.format("%s tried to call %s", tostring(blockedAddon), tostring(blockedFunction))
    -- (9.1.7) The event's own arguments are kept whole (every value the game passed), plus a hint: the guarded
    -- read that was running when it was raised (the marker exists only during the call) or else the last event
    -- Guilded handled. A hint never switches anything off; only an exact function name from the game does.
    if blockedAddon == addonName then
      local extra = {}
      for i = 3, select("#", ...) do
        local value = select(i, ...)
        if not isSecret(value) then extra[#extra + 1] = tostring(value) end
      end
      if #extra > 0 then detail = detail .. " [" .. table.concat(extra, ", ") .. "]" end
      local call = ns.guardedCall
      if call then
        detail = detail .. " (raised while calling " .. tostring(call.name) .. ")"
      elseif ns.lastEvent then
        detail = detail .. " (after " .. tostring(ns.lastEvent) .. ")"
      end
      -- (9.2.1) A tooltip line added just before is the usual way a tainted game routine ends up refused.
      if ns.lastTooltipAt and GetTime and (GetTime() - ns.lastTooltipAt) < 2 then detail = detail .. " (Guilded tooltip line added <2 s before)" end
      -- (9.3.1) What was going on: combat, the Guilded window (shown, which page), and how long ago the last event was handled.
      -- "UNKNOWN()" gives no name, so these narrow down which frame the game refused to touch.
      local context = {}
      if InCombatLockdown and InCombatLockdown() then context[#context + 1] = "in combat" end
      local win = ns.windowState and ns.windowState()
      local panel = _G.GuildedPanel
      if panel and panel.IsShown and panel:IsShown() then
        local tab = win and win.tabs and win.tabs[win.currentTab or 0]
        context[#context + 1] = "window open on " .. tostring(tab and tab.name or "?")
      end
      if ns.lastEventAt and GetTime then
        -- Coarse on purpose: the same refusal then folds into one counted entry instead of one per second.
        local age = GetTime() - ns.lastEventAt
        context[#context + 1] = "last event " .. (age < 1 and "<1 s" or age < 5 and "<5 s" or "5+ s") .. " ago"
      end
      if #context > 0 then detail = detail .. " {" .. table.concat(context, ", ") .. "}" end
      -- (9.5.1) The game raises this event inside the refused call, so Guilded's own frames on the call stack name the code
      -- that made it (file:line, at most four), which "UNKNOWN()" and the last-event hint cannot. Read-only, never refuses.
      if type(debugstack) == "function" then
        local okStack, stack = pcall(debugstack, 2, 14, 0)
        if okStack and type(stack) == "string" and not isSecret(stack) then
          local frames = {}
          for path, line in string.gmatch(stack, "AddOns/Guilded/([%w_/%.]+%.lua):(%d+)") do
            frames[#frames + 1] = path .. ":" .. line
            if #frames >= 4 then break end
          end
          if #frames > 0 then detail = detail .. " <" .. table.concat(frames, " < ") .. ">" end
        end
      end
      local named = type(blockedFunction) == "string" and string.gsub(blockedFunction, "%(%)$", "") or nil
      if named and ns.guildSnapshot and ns.guildSnapshot.onBlocked then pcall(ns.guildSnapshot.onBlocked, named) end
      -- (9.4) A direct invite test that the game refused is remembered for this client build (Util.lua).
      if ns.util and ns.util.noteInviteBlocked then pcall(ns.util.noteInviteBlocked, named) end
    end
    logDiagnostic(event, detail, blockedAddon ~= addonName)
    -- A refused guild action is never retried on this client build (see RosterTools).
    if blockedAddon == addonName and ns.rosterTools and ns.rosterTools.onBlocked then pcall(ns.rosterTools.onBlocked) end
  elseif event == "UI_ERROR_MESSAGE" then
    -- Fallback net in case the blocked-action popup surfaces as a generic UI
    -- error toast instead of ADDON_ACTION_BLOCKED/FORBIDDEN -- log it only
    -- when it looks relevant, since this event also fires constantly for
    -- ordinary gameplay ("not enough mana", etc.).
    local errorType, errorText = ...
    if isSecret(errorText) then return end
    local text = string.lower(tostring(errorText or errorType or ""))
    if string.find(text, "block") or string.find(text, "forbidden") or string.find(text, "addon") then
      logDiagnostic("UI_ERROR_MESSAGE", tostring(errorText or errorType))
    end
  end
end

local frame = CreateFrame("Frame")
frame:RegisterEvent("PLAYER_LOGIN")
if ns.compat and ns.compat.registerEvent then ns.compat.registerEvent(frame, "SKILL_LINES_CHANGED") else pcall(frame.RegisterEvent, frame, "SKILL_LINES_CHANGED") end
frame:RegisterEvent("PLAYER_ENTERING_WORLD")
frame:RegisterEvent("UNIT_INVENTORY_CHANGED")
for _, event in ipairs({ "PLAYER_TALENT_UPDATE", "CHARACTER_POINTS_CHANGED", "ACTIVE_TALENT_GROUP_CHANGED" }) do
  pcall(frame.RegisterEvent, frame, event)
end
frame:RegisterEvent("GROUP_ROSTER_UPDATE")
frame:RegisterEvent("GUILD_ROSTER_UPDATE")
frame:RegisterEvent("PLAYER_GUILD_UPDATE")
frame:RegisterEvent("CHAT_MSG_LOOT")
-- Deliberately NOT registering COMBAT_LOG_EVENT_UNFILTERED: since patch 12.0.0
-- addons cannot register it, and WoW Forever inherits that restriction.
-- Trying to is what produced the "blocked from an action only available to
-- the Blizzard UI" popup at load. Boss kills and attendance are manual anyway.
frame:RegisterEvent("CHAT_MSG_ADDON")
frame:RegisterEvent("ADDON_ACTION_BLOCKED")
frame:RegisterEvent("ADDON_ACTION_FORBIDDEN")
frame:RegisterEvent("UI_ERROR_MESSAGE")
-- One bad event must not stop the handler for every later event.
local SLOW_HANDLER_MS = 50
frame:SetScript("OnEvent", function(_, event, ...)
  local started = debugprofilestop and debugprofilestop()
  if event ~= "ADDON_ACTION_BLOCKED" and event ~= "ADDON_ACTION_FORBIDDEN" and event ~= "CHAT_MSG_ADDON" then ns.lastEvent = event; ns.lastEventAt = GetTime and GetTime() or nil end
  local ok, err = pcall(onEvent, _, event, ...)
  if not ok then logDiagnostic("LUA_ERROR", "Guilded event handler: " .. tostring(err)) end
  if started then
    local elapsed = debugprofilestop() - started
    if elapsed >= SLOW_HANDLER_MS then
      -- (9.2.1) Which kind of addon message it was (the part before the first "|"), so a slow one can be found.
      local what = tostring(event)
      if event == "CHAT_MSG_ADDON" then
        local text = select(2, ...)
        if type(text) == "string" and not isSecret(text) then what = what .. " " .. string.sub(string.match(text, "^[^|]*") or "", 1, 14) end
      end
      logDiagnostic("SLOW", string.format("%s took %.0f ms", what, elapsed))
    end
    -- The opt-in speed recorder (Modules/Perf.lua) keeps every timing while it is on.
    if ns.perf and ns.perf.active then ns.perf.record("event:" .. tostring(event), elapsed) end
  end
end)

SLASH_GUILDED1 = "/guilded"
SLASH_GUILDED2 = "/gd"
SlashCmdList["GUILDED"] = function(text)
  if not (ns.perf and ns.perf.active and debugprofilestop) then return command(text) end
  local started = debugprofilestop()
  command(text)
  ns.perf.record("command:" .. string.lower(string.match(text or "", "^%s*(%S+)") or "menu"), debugprofilestop() - started)
end

-- Shared namespace API for modules (see Modules/Casino.lua).
ns.ensureDb = ensureDb
ns.playerName = playerName
ns.normalizeName = normalizeName
ns.parseRoll = parseRoll
ns.isSecret = isSecret
ns.now = now
ns.message = message
-- Quiet login (9.3.6): one switch (/guilded quiet on|off, Settings > General) for Guilded's informational
-- lines. infoMessage is for lines Guilded prints by itself around login (loaded, digest, reminders, hints):
-- dropped during the first 60 seconds after login. helloMessage is for notices that other Guilded users'
-- hello and sync messages cause (newer version, guild module list, ledger received): dropped at any time.
-- Errors, warnings the member must act on and the answers to commands never use these.
local QUIET_LOGIN_SECONDS = 60
function ns.quietLoginOn()
  local s = db and db.settings
  return s ~= nil and s.quietLogin == true
end
function ns.quietLoginActive()
  if not ns.quietLoginOn() then return false end
  local at, clock = ns.loginAt, GetTime and GetTime() or 0
  return at ~= nil and clock - at < QUIET_LOGIN_SECONDS
end
function ns.infoMessage(text)
  if ns.quietLoginActive() then return false end
  ns.message(text)
  return true
end
function ns.helloMessage(text)
  if ns.quietLoginOn() then return false end
  ns.message(text)
  return true
end
ns.send = send
ns.inspectReadiness = inspectReadiness
ns.isOfficer = isOfficer
ns.isOfficerName = isOfficerName
ns.isGuildMember = isGuildMember
-- Ledger whispers carry balances. Verify the full character address against the live
-- roster; two characters on connected realms can share the same short name.
ns.ledgerPeerRole = function(address)
  if not db or not GetNumGuildMembers or not GetGuildRosterInfo then return nil end
  local realm = (GetNormalizedRealmName and GetNormalizedRealmName()) or GetRealmName()
  local function qualified(name)
    if type(name) ~= "string" or isSecret(name) then return nil end
    return string.find(name, "-", 1, true) and name or ((type(realm) == "string" and realm ~= "" and not isSecret(realm)) and name .. "-" .. realm:gsub("%s+", "") or name)
  end
  local wanted, short = qualified(address), normalizeName(address)
  if not wanted or not short then return nil end
  local count = GetNumGuildMembers()
  if not ledgerRoster or ledgerRoster.count ~= count then
    ledgerRoster = { count = count, rows = {}, shortCounts = {} }
    for i = 1, count do
      local name = GetGuildRosterInfo(i)
      local full, key = qualified(name), normalizeName(name)
      if full and key then
        ledgerRoster.rows[full] = i
        ledgerRoster.shortCounts[key] = (ledgerRoster.shortCounts[key] or 0) + 1
      end
    end
  end
  local row = ledgerRoster.rows[wanted]
  if not row then return nil end
  local name, _, rank = GetGuildRosterInfo(row)
  if qualified(name) ~= wanted or rank == nil or isSecret(rank) then return nil end
  if db.settings.officerRanks[rank] or (ledgerRoster.shortCounts[short] == 1 and db.settings.officers[short]) then return "officer" end
  return "member"
end
ns.runCommand = command
ns.getSettings = function() return db and db.settings end
-- A setup preference, not a permission or a replacement for existing guild data.
ns.isInGameOnly = function() return db and db.settings and db.settings.setupMode == "local" end
-- Read-only views for the tools panel (Modules/Minimap.lua).
ns.getDb = function() return db end
ns.logDiagnostic = logDiagnostic
ns.getActiveRaid = function() return activeRaid end
ns.groupMembers = groupMembers
ns.getPresenceCount = function()
  local count = 0
  if activeRaid and db and db.presence[activeRaid.id] then
    for _ in pairs(db.presence[activeRaid.id]) do count = count + 1 end
  end
  return count
end
