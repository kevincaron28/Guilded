-- World PvP stats (9.0): kills, deaths, defends and calls answered, kept per player and per week.
--
--   /guilded worldpvp     my numbers this week and in total (also /guilded wpvp)
--
-- Only what the game and Guilded already tell us, with no combat log (restricted on Forever):
--   kills     the game's own honorable-kill line (CHAT_MSG_COMBAT_HONOR_GAIN), outside instances and
--             battlegrounds, read from the client's global string so every language works
--   deaths    I died within a minute of an attack by an enemy player that Call for help confirmed (never in an instance,
--             battleground, arena or duel; the zone and time are kept, never the enemy's name or class)
--   places    each kill and death also keeps the map id and my position on it (0..1, 4 decimals), read with plain map calls;
--             where the game refuses it (combat, instances) the last position seen before is used and marked approximate
--   defends   an honorable kill within 5 minutes of pressing On my way on a guildmate's call, in the zone the call named
--   calls     calls for help I made, how many a guildmate answered, and how many I answered
-- Stored in the saved variables as worldPvp (totals, the current week, the week before, the last 30 kills and the newest
-- events with their places) so the companion can carry it to the Discord PvP ladder and the public pages of guilds that
-- publish. Nothing is sent from here. With the module off nothing is recorded and the stored events are dropped.
local _, ns = ...
local wp = {}
ns.worldPvp = wp

local DEFEND_SECONDS = 300
local DEATH_WINDOW_SECONDS = 60
local DEDUPE_SECONDS = 5
local RECENT = 30
local MAX_ZONES = 25
local EVENTS_KEEP = 500
local EVENTS_MAX_AGE = 30 * 86400
local SAMPLE_SECONDS = 5
local STALE_SECONDS = 60
local WEEK = 7 * 86400
local WEEK_OFFSET = 5 * 86400 + 15 * 3600 -- Tuesday 15:00 UTC, counted from the epoch (a Thursday)

local function L(text) return ns.L and ns.L(text) or text end
local function active() return not ns.moduleActive or ns.moduleActive("worldpvp") end
local function epoch() local ok, v = pcall(GetServerTime); return ok and tonumber(v) or time() end
local function clock()
  local ok, v = pcall(GetTime)
  return ok and type(v) == "number" and v or time()
end
local function inInstance()
  if not IsInInstance then return false end
  local ok, inside = pcall(IsInInstance)
  return ok and inside == true
end
local function clean(text, limit)
  text = tostring(text or ""):gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""):gsub("[|;~%c]", ""):gsub("^%s+", ""):gsub("%s+$", "")
  return string.sub(text, 1, limit or 40)
end

local FIELDS = { "kills", "deaths", "defends", "calls", "answered", "responded" }
local function blank()
  local t = {}
  for _, field in ipairs(FIELDS) do t[field] = 0 end
  return t
end

-- The saved table, with the week rolled over when a new one has begun.
local function store()
  local db = ns.getDb and ns.getDb()
  if type(db) ~= "table" then return nil end
  local s = type(db.worldPvp) == "table" and db.worldPvp or {}
  db.worldPvp = s
  s.total = type(s.total) == "table" and s.total or blank()
  s.recent = type(s.recent) == "table" and s.recent or {}
  local key = math.floor((epoch() - WEEK_OFFSET) / WEEK)
  if type(s.week) ~= "table" or s.weekKey ~= key then
    -- The week just ended is kept (db.worldPvp.prev) so a session that crossed the Tuesday reset still uploads it.
    if type(s.week) == "table" and tonumber(s.weekKey) == key - 1 then s.prev = { weekKey = s.weekKey, week = s.week } end
    s.week, s.weekKey = blank(), key
  end
  if type(s.prev) == "table" and tonumber(s.prev.weekKey) ~= key - 1 then s.prev = nil end
  s.since = s.since or epoch()
  return s
end

function wp.weekKey(t) return math.floor(((t or epoch()) - WEEK_OFFSET) / WEEK) end

local function bump(field, amount)
  local s = store()
  if not s then return false end
  amount = amount or 1
  s.total[field] = (tonumber(s.total[field]) or 0) + amount
  s.week[field] = (tonumber(s.week[field]) or 0) + amount
  return true
end

-- ---------------------------------------------------------------------
-- Reading the honorable-kill line
-- ---------------------------------------------------------------------

local function esc(text) return (text:gsub("[%^%$%(%)%%%.%[%]%*%+%-%?]", "%%%0")) end
-- "%s dies, honorable kill Rank: %s (%d Honor Points)" -> a pattern whose first capture is the victim.
local function compile(format)
  if type(format) ~= "string" or format == "" then return nil end
  local parts, pos, count = { "^" }, 1, 0
  while true do
    local s, e = format:find("%%%d*%$?[%d%.]*[sdf]", pos)
    if not s then parts[#parts + 1] = esc(format:sub(pos)); break end
    parts[#parts + 1] = esc(format:sub(pos, s - 1))
    count = count + 1
    parts[#parts + 1] = count == 1 and "(.-)" or ".-"
    pos = e + 1
  end
  parts[#parts + 1] = "$"
  return count >= 1 and table.concat(parts) or nil
end

local pattern
function wp.victim(text)
  if type(text) ~= "string" or (ns.isSecret and ns.isSecret(text)) then return nil end
  pattern = pattern or compile(_G.COMBATLOG_HONORGAIN) or "^(.-) dies, honorable kill"
  local name = text:match(pattern) or text:match("^(.-) dies, honorable kill")
  name = name and clean(name, 40)
  return name ~= "" and name or nil
end

-- ---------------------------------------------------------------------
-- Recording
-- ---------------------------------------------------------------------

local lastKill, lastDeathAt
local defendingUntil, defendingZone, defendingMap

local function inCombat()
  if ns.compat and ns.compat.inCombat then return ns.compat.inCombat() == true end
  if not InCombatLockdown then return false end
  local ok, value = pcall(InCombatLockdown)
  return ok and value == true
end
local function round4(value) return math.floor(value * 10000 + 0.5) / 10000 end

-- My map id and position on it with plain map calls (never a protected function); the position is nil where the game does not give
-- one (instances, a refusal, secret values), the map id alone may still be known.
-- The map is whatever GetBestMapForUnit returns: in a capital city that is the city map with city-local coordinates (the website
-- has the cities' rectangles), and in a cave or micro-dungeon the game may return another map type; the id is kept as it comes and
-- the website places it with the rectangles from /guilded probe maps.
local function readPosition()
  if inInstance() then return nil end
  if not (C_Map and C_Map.GetBestMapForUnit and C_Map.GetPlayerMapPosition) then return nil end
  local ok, mapId = pcall(C_Map.GetBestMapForUnit, "player")
  if not ok or type(mapId) ~= "number" or mapId <= 0 or (ns.isSecret and ns.isSecret(mapId)) then return nil end
  local okPos, position = pcall(C_Map.GetPlayerMapPosition, mapId, "player")
  if not okPos or not position then return mapId end
  local okXY, x, y = pcall(function() return position:GetXY() end)
  if not okXY or type(x) ~= "number" or type(y) ~= "number" or (ns.isSecret and (ns.isSecret(x) or ns.isSecret(y))) then return mapId end
  if x < 0 or x > 1 or y < 0 or y > 1 or (x == 0 and y == 0) then return mapId end
  return mapId, round4(x), round4(y)
end

-- The last position seen out of combat (sampled on a zone change and every few seconds), for the moments the game refuses it.
local lastPlace
function wp.sample()
  if not active() or inCombat() then return false end
  local mapId, x, y = readPosition()
  if mapId and x then lastPlace = { m = mapId, x = x, y = y, at = clock() } end
  return mapId ~= nil
end

-- Where a kill or death happened: { m, x, y, a } with a = true when the position is the last one seen before (approximate).
function wp.where()
  local mapId, x, y = readPosition()
  if mapId and x then return { m = mapId, x = x, y = y } end
  if lastPlace and clock() - lastPlace.at <= STALE_SECONDS and (not mapId or mapId == lastPlace.m) then
    return { m = lastPlace.m, x = lastPlace.x, y = lastPlace.y, a = true }
  end
  return mapId and { m = mapId } or {}
end

-- One kill or death in the newest-events list: kind, time, zone text and place. Bounded by count and by age.
local function addEvent(s, kind, zone, at, place)
  s.events = type(s.events) == "table" and s.events or {}
  local list = s.events
  -- s: an id kept with the event, so every upload of the same event carries the same number (a counter, kept below 2^30).
  s.seq = ((tonumber(s.seq) or 0) % 1073741823) + 1
  list[#list + 1] = { k = kind, t = at, z = zone, m = place.m, x = place.x, y = place.y, a = place.a and 1 or nil, s = s.seq }
  local kept = {}
  for _, e in ipairs(list) do
    if type(e) == "table" and tonumber(e.t) and at - e.t <= EVENTS_MAX_AGE then kept[#kept + 1] = e end
  end
  while #kept > EVENTS_KEEP do table.remove(kept, 1) end
  s.events = kept
end

local function currentZone()
  local zone = GetRealZoneText and GetRealZoneText() or ""
  if type(zone) ~= "string" or (ns.isSecret and ns.isSecret(zone)) then return "" end
  return zone
end

local function currentMap()
  if not (ns.guildMap and ns.guildMap.myPosition) then return nil end
  local ok, mapId = pcall(ns.guildMap.myPosition)
  return ok and tonumber(mapId) or nil
end

-- Inside the 5 minutes after On my way, and where the call was. The map id decides when both sides know it (the zone name
-- is the caller's language: a French helper and an English caller never share one); otherwise the name, cut like the call
-- cuts it (28 characters). A call without a place counts anywhere.
function wp.defending()
  if defendingUntil == nil or clock() > defendingUntil then return false end
  if defendingMap then
    local mine = currentMap()
    if mine then return mine == defendingMap end
  end
  if defendingZone == nil then return defendingMap == nil end
  return clean(currentZone(), 28) == defendingZone
end

-- An honorable kill line from the game. Returns true when it was counted.
function wp.noteKill(text)
  if not active() or inInstance() then return false end
  local victim = wp.victim(text)
  if not victim then return false end
  local t = clock()
  if lastKill and lastKill.name == victim and t - lastKill.at < DEDUPE_SECONDS then return false end
  lastKill = { name = victim, at = t }
  if not bump("kills") then return false end
  local s = store()
  local zone = GetRealZoneText and GetRealZoneText() or ""
  if ns.isSecret and ns.isSecret(zone) then zone = "" end
  local place, at = wp.where(), epoch()
  s.recent[#s.recent + 1] = { n = victim, z = clean(zone, 40), at = at, d = wp.defending() and 1 or nil, m = place.m, x = place.x, y = place.y, a = place.a and 1 or nil }
  while #s.recent > RECENT do table.remove(s.recent, 1) end
  addEvent(s, "kill", clean(zone, 40), at, place)
  if wp.defending() then bump("defends") end
  return true
end

-- I died. Counts when Call for help confirmed an attack by an enemy player in the last minute.
function wp.noteDeath()
  if not active() or inInstance() then return false end
  local help = ns.callForHelp
  if not (help and help.attacked and help.attacked()) then return false end
  local t = clock()
  if lastDeathAt and t - lastDeathAt < DEATH_WINDOW_SECONDS then return false end
  lastDeathAt = t
  if not bump("deaths") then return false end
  -- Where and when, like a kill, but never who: no killer name or class is kept (an enemy player's name is theirs).
  local st = store()
  local zone = clean(currentZone(), 40)
  st.deathsRecent = type(st.deathsRecent) == "table" and st.deathsRecent or {}
  local place, at = wp.where(), epoch()
  st.deathsRecent[#st.deathsRecent + 1] = { z = zone, at = at, m = place.m, x = place.x, y = place.y, a = place.a and 1 or nil }
  while #st.deathsRecent > RECENT do table.remove(st.deathsRecent, 1) end
  addEvent(st, "death", zone, at, place)
  if zone ~= "" then
    st.zones = type(st.zones) == "table" and st.zones or {}
    if not st.zones[zone] then
      local n, lowest, lowestCount = 0, nil, nil
      for name, count in pairs(st.zones) do
        n = n + 1
        if not lowestCount or count < lowestCount then lowest, lowestCount = name, count end
      end
      if n >= MAX_ZONES and lowest then st.zones[lowest] = nil end
    end
    st.zones[zone] = (tonumber(st.zones[zone]) or 0) + 1
  end
  return true
end

-- From Call for help: "call" (I called), "answered" (a guildmate said On my way to my call),
-- "responded" (I pressed On my way; `zone` and `mapId` are where the call named).
function wp.note(kind, zone, mapId)
  if not active() then return false end
  if kind == "call" then return bump("calls") end
  if kind == "answered" then return bump("answered") end
  if kind == "responded" then
    defendingUntil = clock() + DEFEND_SECONDS
    defendingZone = type(zone) == "string" and zone ~= "" and clean(zone, 28) or nil
    defendingMap = tonumber(mapId) and tonumber(mapId) > 0 and tonumber(mapId) or nil
    return bump("responded")
  end
  return false
end

-- ---------------------------------------------------------------------
-- Reading
-- ---------------------------------------------------------------------

function wp.stats()
  local s = store()
  if not s then return blank(), blank() end
  return s.week, s.total
end

-- Kills per death (a death-free week shows the kills), one decimal.
function wp.kd(t)
  local kills, deaths = tonumber(t and t.kills) or 0, tonumber(t and t.deaths) or 0
  return string.format("%.1f", deaths > 0 and kills / deaths or kills)
end

-- The zones I died in most (open world only), most first: { { zone = "Hillsbrad Foothills", deaths = 4 }, ... }.
function wp.deadliestZones(limit)
  local s = store()
  local list = {}
  for zone, count in pairs(s and s.zones or {}) do list[#list + 1] = { zone = zone, deaths = tonumber(count) or 0 } end
  table.sort(list, function(a, b) return a.deaths > b.deaths or (a.deaths == b.deaths and a.zone < b.zone) end)
  while #list > (limit or 3) do table.remove(list) end
  return list
end

-- The K/D and deadliest-zones lines under the counters; none until a death was counted.
function wp.details()
  local week, total = wp.stats()
  if (tonumber(total.deaths) or 0) == 0 then return {} end
  local lines = { string.format(L("K/D: %s this week, %s in total."), wp.kd(week), wp.kd(total)) }
  local zones = {}
  for _, z in ipairs(wp.deadliestZones(3)) do zones[#zones + 1] = string.format("%s (%d)", z.zone, z.deaths) end
  if #zones > 0 then lines[#lines + 1] = string.format(L("Deadliest zones: %s."), table.concat(zones, ", ")) end
  return lines
end

local function line(prefix, t)
  return string.format(L("%s: %d kills, %d deaths, %d defends. Calls for help: %d made (%d answered), %d answered by me."),
    prefix, t.kills or 0, t.deaths or 0, t.defends or 0, t.calls or 0, t.answered or 0, t.responded or 0)
end

function wp.summary()
  local week, total = wp.stats()
  return line(L("World PvP this week"), week), line(L("World PvP in total"), total)
end

ns.commandHandlers = ns.commandHandlers or {}
ns.commandHandlers["worldpvp"] = function()
  local a, b = wp.summary()
  ns.message(a)
  ns.message(b)
  for _, extra in ipairs(wp.details()) do ns.message(extra) end
  ns.message(L("Kills and deaths are shown by zone and position on the public pages of guilds that publish."))
end
ns.commandHandlers["wpvp"] = ns.commandHandlers["worldpvp"]
ns.commandHelp = ns.commandHelp or {}
table.insert(ns.commandHelp, "/guilded worldpvp - my open-world kills, deaths, defends and calls for help, this week and in total; kills and deaths are shown by zone and position on the public pages of guilds that publish")

local frame = CreateFrame("Frame")
local function register(event)
  if ns.compat and ns.compat.registerEvent then ns.compat.registerEvent(frame, event, true)
  else pcall(frame.RegisterEvent, frame, event) end
end
register("CHAT_MSG_COMBAT_HONOR_GAIN")
register("PLAYER_DEAD")
register("PLAYER_ENTERING_WORLD")
register("ZONE_CHANGED_NEW_AREA")
local sampleTimer = 0
function wp.tick(elapsed)
  sampleTimer = sampleTimer + (tonumber(elapsed) or 0)
  if sampleTimer < SAMPLE_SECONDS then return end
  sampleTimer = 0
  pcall(function()
    if active() then wp.sample()
    else
      -- Module off: nothing is recorded, and what was kept of kills' and deaths' places is dropped.
      local db = ns.getDb and ns.getDb()
      local s = type(db) == "table" and db.worldPvp
      if type(s) == "table" then
        s.events = nil
        for _, list in ipairs({ s.recent or {}, s.deathsRecent or {} }) do
          for _, row in ipairs(list) do
            if type(row) == "table" then row.m, row.x, row.y, row.a = nil, nil, nil, nil end
          end
        end
      end
      lastPlace = nil
    end
  end)
end
frame:SetScript("OnUpdate", function(_, elapsed) wp.tick(elapsed) end)
frame:SetScript("OnEvent", function(_, event, text)
  local ok, err = pcall(function()
    if event == "CHAT_MSG_COMBAT_HONOR_GAIN" then wp.noteKill(text)
    elseif event == "PLAYER_DEAD" then wp.noteDeath()
    else wp.sample() end
  end)
  if not ok and ns.logDiagnostic then ns.logDiagnostic("LUA_ERROR", "world pvp: " .. tostring(err)) end
end)
