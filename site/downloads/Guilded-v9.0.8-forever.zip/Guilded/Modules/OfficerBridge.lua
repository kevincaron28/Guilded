-- Optional officer bridge: companion files -> online guildmates, never executable Lua.
local _, ns = ...
local PREFIX, CHUNK, MAX_BYTES, MAX_PARTS = "GuildedBridge", 180, 46080, 256
-- Wire versions. DATA|1 sends every byte as two hex digits. DATA|2 keeps printable ASCII as is
-- and writes only other bytes, "%" and "|" as %XX: the data is mostly plain text, so it takes
-- about half the messages. A client that reads DATA|2 says so with CAP|2 before its REQ|1
-- (older officers keep answering REQ|1 as before); a REQ|1 without CAP|2 means an older addon
-- is online, and then this officer sends DATA|1 for a while so it is not left out.
local CHUNK2, LEGACY_SECONDS, REPLY_JITTER = 200, 1800, 4
local pending, lastShare, started, lastGuild = nil, nil, false, nil
local capable, legacyUntil = {}, 0
-- Another officer already sending the same (or newer) data: answering too would only repeat it.
local othersStamp, othersAt, replyScheduled, replyLegacy = nil, 0, false, false
local function db() return ns.getDb and ns.getDb() end
local function guildKey()
  -- Forever: the same home-realm key the saved data is filed under (Core.lua currentGuildKey).
  if ns.currentGuildKey and ns.util and ns.util.isForever and ns.util.isForever() then return (ns.currentGuildKey()) end
  if not (IsInGuild and IsInGuild()) then return nil end
  local name = GetGuildInfo and GetGuildInfo("player")
  if type(name) ~= "string" or name == "" or (ns.isSecret and ns.isSecret(name)) then return nil end
  return name .. "-" .. ((GetRealmName and GetRealmName()) or "")
end
-- GetRealmName can be a different Forever server segment on each PC. The
-- fourth GetGuildInfo result identifies the guild's home when it differs.
local function guildHome()
  if not (IsInGuild and IsInGuild()) or not GetGuildInfo then return nil end
  local name, _, _, home = GetGuildInfo("player")
  if type(name) ~= "string" or name == "" or (ns.isSecret and ns.isSecret(name)) then return nil end
  if type(home) ~= "string" or (ns.isSecret and ns.isSecret(home)) or home == "" then
    home = (GetRealmName and GetRealmName()) or ""
  end
  if type(home) ~= "string" or (ns.isSecret and ns.isSecret(home)) then return nil end
  return name .. "-" .. string.gsub(home, "%s+", ""), name .. "-"
end
local function sameGuild(snapshot)
  if type(snapshot) ~= "table" then return false end
  local home, prefix = guildHome()
  if not home then return false end
  if snapshot.guildHome ~= nil then return snapshot.guildHome == home end
  -- Accept older senders without changing their packet format or saved keys.
  local key = snapshot.guild
  if type(key) ~= "string" or string.sub(key, 1, #prefix) ~= prefix then return false end
  return prefix .. string.gsub(string.sub(key, #prefix + 1), "%s+", "") == home
end
local function clock() return ns.util.serverTime() end
local function after(seconds, fn) if C_Timer and C_Timer.After then C_Timer.After(seconds, fn) end end

-- Length-prefixed values; no load/loadstring, and explicit resource bounds in both directions.
local function encode(value, depth, budget)
  depth = depth or 0; budget = budget or { nodes = 0 }
  budget.nodes = budget.nodes + 1
  if depth > 9 or budget.nodes > 6000 then error("bridge data is too large") end
  local kind = type(value)
  if kind == "string" then
    if #value > 4096 then error("bridge string is too long") end
    return "s" .. #value .. ":" .. value
  elseif kind == "number" then
    if value ~= value or math.abs(value) > 1000000000000 then error("invalid bridge number") end
    return "n" .. tostring(value) .. ";"
  elseif kind == "boolean" then return value and "b1" or "b0"
  elseif kind == "table" then
    local keys = {}
    for key in pairs(value) do
      if type(key) ~= "string" and (type(key) ~= "number" or key < 1 or key ~= math.floor(key)) then error("invalid bridge key") end
      table.insert(keys, key)
    end
    table.sort(keys, function(a, b) return type(a) == type(b) and a < b or type(a) < type(b) end)
    local parts = { "t" .. #keys .. ":" }
    for _, key in ipairs(keys) do
      table.insert(parts, encode(key, depth + 1, budget)); table.insert(parts, encode(value[key], depth + 1, budget))
    end
    return table.concat(parts)
  end
  error("unsupported bridge value")
end
local function decode(text)
  if #text > MAX_BYTES then error("bridge data is too large") end
  local at, nodes = 1, 0
  local read
  local function size(delimiter)
    local stop = string.find(text, delimiter, at, true)
    if not stop or stop - at > 20 then error("invalid bridge length") end
    local raw = string.sub(text, at, stop - 1)
    at = stop + 1
    local n = tonumber(raw)
    if not n or n < 0 or n ~= math.floor(n) then error("invalid bridge length") end
    return n
  end
  read = function(depth)
    nodes = nodes + 1
    if depth > 9 or nodes > 6000 then error("bridge data is too large") end
    local tag = string.sub(text, at, at); at = at + 1
    if tag == "s" then
      local n = size(":")
      if n > 4096 or at + n - 1 > #text then error("invalid bridge string") end
      local value = string.sub(text, at, at + n - 1); at = at + n; return value
    elseif tag == "n" then
      local stop = string.find(text, ";", at, true)
      if not stop or stop - at > 24 then error("invalid bridge number") end
      local n = tonumber(string.sub(text, at, stop - 1)); at = stop + 1
      if not n or n ~= n or math.abs(n) > 1000000000000 then error("invalid bridge number") end
      return n
    elseif tag == "b" then
      local flag = string.sub(text, at, at); at = at + 1
      if flag ~= "0" and flag ~= "1" then error("invalid bridge boolean") end
      return flag == "1"
    elseif tag == "t" then
      local n, value = size(":"), {}
      if n > 3000 then error("bridge table is too large") end
      for _ = 1, n do
        local key = read(depth + 1)
        if type(key) ~= "string" and (type(key) ~= "number" or key < 1 or key ~= math.floor(key)) then error("invalid bridge key") end
        if value[key] ~= nil then error("duplicate bridge key") end
        value[key] = read(depth + 1)
      end
      return value
    end
    error("invalid bridge value")
  end
  local value = read(0)
  if at ~= #text + 1 then error("trailing bridge data") end
  return value
end

local function validRaid(raid)
  if raid == false then return true end
  if type(raid) ~= "table" or type(raid.id) ~= "string" or type(raid.title) ~= "string" or type(raid.at) ~= "string" then return false end
  if raid.players ~= nil then
    if type(raid.players) ~= "table" then return false end
    for _, player in pairs(raid.players) do
      if type(player) ~= "table" or type(player.name) ~= "string" or type(player.role) ~= "string" then return false end
    end
  end
  return true
end
local function apply(snapshot, stamp, sender)
  local d, key = db(), guildKey()
  if not d or not key or not sameGuild(snapshot) or (d.guildKey and d.guildKey ~= key) then return false end
  if type(snapshot.raids) ~= "table" or not validRaid(snapshot.nextRaid) then return false end
  for _, raid in pairs(snapshot.raids) do if not validRaid(raid) or raid == false then return false end end
  local rules
  if snapshot.loot ~= false then
    if type(snapshot.loot) ~= "table" or not ns.adoptOfficerLootRules then return false end
    local okay
    okay, rules = pcall(ns.adoptOfficerLootRules, snapshot.loot, stamp)
    if not okay then return false end
  end
  d.officerBridge = { updatedAt = stamp, from = sender, snapshot = snapshot }
  -- Never replace a newer companion file's core data with an older broadcast.
  if not d.lootRules or not d.lootRules.updatedAt or d.lootRules.updatedAt < stamp then d.lootRules = rules end
  if not GuildedStandings or not GuildedStandings.updatedAt or GuildedStandings.updatedAt < stamp then
    GuildedNextRaid = snapshot.nextRaid ~= false and snapshot.nextRaid or nil
    GuildedRaids = snapshot.raids
  end
  if ns.onLootChange then pcall(ns.onLootChange) end
  if ns.onCalendarChange then pcall(ns.onCalendarChange) end
  return true
end
local function publicLoot(value, depth)
  if type(value) ~= "table" then return value end
  if (depth or 0) > 9 then error("bridge data is too deep") end
  local copy = {}
  for key, child in pairs(value) do
    -- Discord ownership IDs need not travel in game with core prices and points.
    if key ~= "account" then copy[key] = publicLoot(child, (depth or 0) + 1) end
  end
  return copy
end
local function bridgeSettings()
  local d, key = db(), guildKey()
  if not d or not key or d.guildKey ~= key or not ns.isOfficer() then return nil end
  if d.bridgeCompanionGuild and d.bridgeCompanionGuild ~= key then return nil end
  d.settings = d.settings or {}
  local settings = d.settings.officerBridge
  if not settings then
    -- Keep the companion source bound across the Core.lua guild-data switch.
    -- A deliberate /bridge on can rebind it after the companion is changed.
    if type(GuildedStandings) ~= "table" or type(GuildedStandings.updatedAt) ~= "string" then return nil end
    d.bridgeCompanionGuild = key
    settings = { enabled = true, guild = key }
    d.settings.officerBridge = settings
  end
  settings.enabled = true -- always on (8.5); an old saved off is ignored
  if settings.guild == key then d.bridgeCompanionGuild = key end
  return settings
end
local function capture()
  local d, key = db(), guildKey()
  local settings = bridgeSettings()
  if not key or not settings or settings.guild ~= key or not settings.enabled or not ns.isOfficer() then return end
  local file = GuildedStandings
  if type(file) ~= "table" or type(file.updatedAt) ~= "string" then return end
  if d.officerBridge and sameGuild(d.officerBridge.snapshot) and d.officerBridge.updatedAt >= file.updatedAt then return end
  if type(GuildedLoot) == "table" and (not d.lootRules or not d.lootRules.updatedAt or d.lootRules.updatedAt < file.updatedAt) then
    d.lootRules = ns.adoptOfficerLootRules(GuildedLoot, file.updatedAt)
  end
  local raids = {}
  for _, raid in ipairs(type(GuildedRaids) == "table" and GuildedRaids or {}) do
    -- Native Discord events are filtered for the officer's permissions, not
    -- every guildmate's. Never relay those potentially private events.
    if type(raid.id) == "string" and not string.match(raid.id, "^discord:") then table.insert(raids, raid) end
  end
  -- The companion is bound to the officer's guild; explicit off stays off.
  apply({ guild = key, guildHome = guildHome(), loot = type(GuildedLoot) == "table" and publicLoot(GuildedLoot) or false,
    nextRaid = type(GuildedNextRaid) == "table" and type(GuildedNextRaid.id) == "string" and not string.match(GuildedNextRaid.id, "^discord:") and GuildedNextRaid or false,
    raids = raids }, file.updatedAt, ns.playerName())
end
-- DATA|2 wire text: printable ASCII except "%" and "|" stays; every other byte becomes %XX.
local function escape2(text)
  return (string.gsub(text, "[^\32-\36\38-\123\125\126]", function(c) return string.format("%%%02X", string.byte(c)) end))
end
local function unescape2(text)
  return (string.gsub(text, "%%(%x%x)", function(pair) return string.char(tonumber(pair, 16)) end))
end
-- Guildmates who announced an older Guilded this session may not read DATA|2.
local function legacyOnline()
  if legacyUntil > clock() then return true end
  local versions = ns.peerVersions and ns.peerVersions()
  local mine = ns.addonVersion and ns.addonVersion()
  if type(versions) == "table" and mine and ns.versionNewer then
    for _, theirs in pairs(versions) do if ns.versionNewer(mine, theirs) then return true end end
  end
  return false
end
local function share(forceV1)
  capture()
  local d, key = db(), guildKey()
  local settings = bridgeSettings()
  local data = d and d.officerBridge
  if not key or not settings or not settings.enabled or settings.guild ~= key or not ns.isOfficer() or not data or not sameGuild(data.snapshot) then return end
  if lastShare and clock() - lastShare < 90 then return end
  -- Another officer is already sending this data (or newer): the guild has it coming.
  if othersStamp and othersStamp >= data.updatedAt and clock() - othersAt < 60 then return end
  local okay, payload = pcall(encode, data.snapshot)
  local v1 = forceV1 or legacyOnline()
  local wire, size, kind
  if okay and v1 and #payload * 2 <= MAX_BYTES then
    -- ASCII wire data preserves accents/newlines without splitting UTF-8 or sending NUL bytes.
    wire, size, kind = string.gsub(payload, ".", function(byte) return string.format("%02x", string.byte(byte)) end), CHUNK, "DATA|1|"
  elseif okay and not v1 and #payload <= MAX_BYTES then
    wire, size, kind = escape2(payload), CHUNK2, "DATA|2|"
  end
  if not wire or math.ceil(#wire / size) > MAX_PARTS then ns.message("Officer bridge data is too large to share. Use the Windows companion for now."); return end
  lastShare = clock()
  local total = math.ceil(#wire / size)
  for index = 1, total do
    ns.comm.send(PREFIX, kind .. data.updatedAt .. "|" .. index .. "|" .. total .. "|" .. string.sub(wire, (index - 1) * size + 1, index * size), "GUILD")
  end
end
-- Answers a request a few seconds later: several officers asked at once answer once between
-- them (each one hears the first one's DATA and stays quiet).
local function scheduleReply(legacy)
  replyLegacy = replyLegacy or legacy
  if replyScheduled then return end
  replyScheduled = true
  local function fire()
    replyScheduled = false
    local v1 = replyLegacy
    replyLegacy = false
    share(v1)
  end
  if C_Timer and C_Timer.After then C_Timer.After(1 + math.random() * REPLY_JITTER, fire) else fire() end
end
local function request()
  local d, key = db(), guildKey()
  if not d or not key then return end
  ns.comm.send(PREFIX, "CAP|2", "GUILD")
  ns.comm.send(PREFIX, "REQ|1|" .. (d.officerBridge and sameGuild(d.officerBridge.snapshot) and d.officerBridge.updatedAt or "0"), "GUILD")
end
ns.requestGuildBridge = request
local function receive(text, sender)
  if not ns.isOfficerName(sender) then return end
  local version, stamp, index, total, payload = string.match(text, "^DATA|([12])|([^|]+)|(%d+)|(%d+)|(.*)$")
  index, total = tonumber(index), tonumber(total)
  if not stamp or #stamp > 32 or not string.match(stamp, "^%d%d%d%d%-%d%d%-%d%dT") or ns.util.tooFarAhead(stamp) then return end
  if not index or not total or total < 1 or total > MAX_PARTS or index < 1 or index > total then return end
  if version == "1" and (#payload > CHUNK or #payload % 2 ~= 0 or not string.match(payload, "^%x+$")) then return end
  if version == "2" and (#payload > CHUNK2 or #payload == 0 or string.find(payload, "[^\32-\126]") or string.find(payload, "|", 1, true)) then return end
  if not othersStamp or stamp >= othersStamp then othersStamp = stamp end
  othersAt = clock()
  local d, key = db(), guildKey()
  if not d or not key or (d.officerBridge and sameGuild(d.officerBridge.snapshot) and d.officerBridge.updatedAt >= stamp) then return end
  if pending and clock() - pending.at > 600 then pending = nil end
  -- Keep one bounded assembly. Never combine chunks from competing officers or wire versions.
  if pending and (pending.sender ~= sender or pending.stamp ~= stamp or pending.version ~= version) then return end
  if not pending then pending = { sender = sender, stamp = stamp, version = version, total = total, parts = {}, at = clock() } end
  if pending.total ~= total or (pending.parts[index] and pending.parts[index] ~= payload) then pending = nil; return end
  pending.parts[index] = payload
  for part = 1, total do if not pending.parts[part] then return end end
  local assembled = table.concat(pending.parts); pending = nil
  if version == "1" then
    assembled = string.gsub(assembled, "%x%x", function(pair) return string.char(tonumber(pair, 16)) end)
  else
    assembled = unescape2(assembled)
  end
  local okay, snapshot = pcall(decode, assembled)
  if okay and type(snapshot) == "table" then apply(snapshot, stamp, sender) end
end
ns.commandHandlers["bridge"] = function(args)
  local mode, d, key = string.lower(args[1] or "status"), db(), guildKey()
  if mode == "off" then mode = "on" end -- there is no off any more
  if mode == "on" then
    if not ns.isOfficer() then ns.message("Only an officer can enable the guild's Discord bridge."); return end
    if not d or not key then ns.message("Join your in-game guild before enabling the officer bridge."); return end
    d.settings = d.settings or {}; d.settings.officerBridge = { enabled = true, guild = key }
    if mode == "on" then d.bridgeCompanionGuild = key end
    if mode == "on" then capture(); share() end
  elseif mode == "refresh" then request()
  elseif mode ~= "status" then ns.message("/guilded bridge on | off | refresh | status"); return end
  capture()
  local settings = d and d.settings and d.settings.officerBridge
  local data = d and d.officerBridge
  if ns.isOfficer() and key then
    if d and d.bridgeCompanionGuild and d.bridgeCompanionGuild ~= key then
      ns.message("Companion data is bound to another guild. Check the companion guild, save standings, /reload, then /guilded bridge on."); return
    end
    if (not data or not sameGuild(data.snapshot)) and (type(GuildedStandings) ~= "table" or type(GuildedStandings.updatedAt) ~= "string") then
      ns.message("Officer bridge needs companion data. Sync and save standings on this PC, then /reload."); return
    end
  end
  ns.message(data and sameGuild(data.snapshot) and ("Guild data from " .. tostring(data.from) .. " (" .. data.updatedAt .. ").") or "Waiting for an online officer to share Discord guild data. The Windows companion is optional.")
end
table.insert(ns.commandHelp, "/guilded bridge status | refresh - request core and raid data from an online officer")
table.insert(ns.commandHelp, { officer = true, text = "/guilded bridge on - bridge your companion's data to this WoW guild" })
local frame = CreateFrame("Frame")
frame:RegisterEvent("PLAYER_ENTERING_WORLD"); frame:RegisterEvent("PLAYER_GUILD_UPDATE"); frame:RegisterEvent("CHAT_MSG_ADDON")
frame:SetScript("OnEvent", function(_, event, ...)
  local eventArgs = { ... }
  local okay, err = pcall(function()
    if event == "PLAYER_ENTERING_WORLD" then
      if started then return end; started = true; ns.comm.register(PREFIX)
      lastGuild = guildKey()
      local d = db()
      if d and d.officerBridge and sameGuild(d.officerBridge.snapshot) then
        apply(d.officerBridge.snapshot, d.officerBridge.updatedAt, d.officerBridge.from)
      end
      capture()
      after(10, function() request(); share() end)
      after(130, request); after(310, request) -- Late guild roster / lost chunks / officer login.
    elseif event == "PLAYER_GUILD_UPDATE" then
      local key, d = guildKey(), db()
      if lastGuild ~= key then pending, lastShare, othersStamp = nil, nil, nil end
      if lastGuild and lastGuild ~= key then GuildedNextRaid, GuildedRaids = nil, nil end
      lastGuild = key
      if d and d.officerBridge and sameGuild(d.officerBridge.snapshot) then
        apply(d.officerBridge.snapshot, d.officerBridge.updatedAt, d.officerBridge.from)
      end
      capture()
      after(10, request)
    elseif event == "CHAT_MSG_ADDON" then
      local prefix, text, channel, sender = unpack(eventArgs)
      if not ns.comm.accept(prefix, text, channel, sender, PREFIX) then return end
      if prefix ~= PREFIX or channel ~= "GUILD" or not guildKey() then return end
      if ns.isSecret(prefix) or ns.isSecret(text) or ns.isSecret(sender) then return end
      sender = ns.normalizeName(sender)
      if not sender or sender == ns.playerName() or #text > 255 then return end
      if text == "CAP|2" then
        capable[sender] = clock()
      elseif string.match(text, "^REQ|1|") then
        local d = db(); capture()
        local their = string.match(text, "^REQ|1|([^|]+)$")
        -- A REQ without a CAP|2 just before it comes from an addon that only reads DATA|1.
        local legacy = not capable[sender] or clock() - capable[sender] > 60
        if legacy then legacyUntil = clock() + LEGACY_SECONDS end
        if their and d and d.officerBridge and d.officerBridge.updatedAt > their then scheduleReply(legacy) end
      elseif string.match(text, "^DATA|") then receive(text, sender) end
    end
  end)
  if not okay and ns.logDiagnostic then ns.logDiagnostic("LUA_ERROR", "Officer bridge: " .. tostring(err)) end
end)
