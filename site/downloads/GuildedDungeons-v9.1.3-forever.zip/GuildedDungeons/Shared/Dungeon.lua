-- Copied from addon/Guilded/Modules/Dungeon.lua by scripts/build-dungeons-addon.mjs. Edit the original, then run npm run dungeons:sync.
-- Dungeon Challenge run tracker (roadmap D2).
--
-- Turns a guild group's dungeon run into one permanent record:
--   DETECTED  entered a 5-player dungeon (type "party")
--   STARTING  waiting for the first pull
--   ACTIVE    timer running (first combat, or /guilded dungeon start)
--   COMPLETED final boss killed (Encounter Journal) or /guilded dungeon complete
--   ABANDONED left for 15 minutes, group disbanded, or /guilded dungeon abandon
--   INVALID   marked unusable (e.g. zero duration)
--
-- Every addon user in the group tracks the run; one "recorder" (lowest
-- character name among addon users, so everyone agrees without talking)
-- announces the shared run id. Each player's own addon counts their own
-- deaths and shares the count after combat (addon messages can be blocked
-- mid-fight). Finished runs are shared with online officers in the guild so
-- the run reaches the bot even if no officer was in the group. Points are
-- NOT computed here: the bot applies its own rules to validated runs.
--
-- All WoW API access goes through ns.compat (Compat.lua). Everything is
-- saved in GuildedDB.dungeon on every change, so /reload, a disconnect,
-- or a crash resumes the run.
local addonName, ns = ...
ns = ns or {}

local PREFIX = "GuildedDgn"
local PROTOCOL_VERSION = 1
local SCHEMA_VERSION = 1
local ABANDON_AFTER_SECONDS = 15 * 60
local TICK_SECONDS = 30
local CHUNK_BYTES = 200
local KEEP_SYNCED_DAYS = 30

local compat = ns.compat
local dungeon = { addonUsers = {}, outbox = {}, incoming = {}, lastHello = 0, acked = {},
  stats = { acksSent = 0, acksHeard = 0, pruned = 0 } }
ns.dungeon = dungeon

local TERMINAL = { COMPLETED = true, ABANDONED = true, INVALID = true, ERROR = true }
-- (9.0) Guildmates' runs nobody's bot confirmed are dropped after this long (the bot takes
-- relayed runs up to 30 days old, so older copies can never reach it).
local KEEP_PEER_DAYS = 45

local function db()
  local root = ns.getDb and ns.getDb()
  if not root then return nil end
  root.dungeon = root.dungeon or {}
  local d = root.dungeon
  d.schema = d.schema or SCHEMA_VERSION
  d.runs = d.runs or {}
  return d
end

local function now() return compat.serverTime() end
local function me() return ns.playerName() end

-- ---------------------------------------------------------------------
-- Messaging (queued while in combat, spaced out)
-- ---------------------------------------------------------------------

local function groupChannel()
  return ns.util.groupChannel()
end

-- Held back while in combat (messages can be blocked mid-fight), then handed to the paced
-- queue in Util.lua.
local function flush()
  if compat.inCombat() then return end
  local queued = dungeon.outbox
  dungeon.outbox = {}
  for _, message in ipairs(queued) do
    local channel = message.channel == "GROUP" and groupChannel() or message.channel
    -- (9.0) Guild summaries wait until the player is outside: guild messages from inside an
    -- instance are unreliable, and nobody in the guild needs them before the group leaves.
    if channel then ns.comm.send(PREFIX, message.text, channel, nil, nil, channel == "GUILD" and "hold-in-instance" or nil) end
  end
end

-- channel "GROUP" = party/raid at send time, or "GUILD".
local function send(text, channel)
  table.insert(dungeon.outbox, { text = text, channel = channel or "GROUP" })
  flush()
end

-- ---------------------------------------------------------------------
-- Group, recorder, players
-- ---------------------------------------------------------------------

-- Lowest name among addon users in the group (including you).
local function electRecorder()
  local recorder = me()
  for _, member in ipairs(compat.groupMembers()) do
    if dungeon.addonUsers[member.name] and member.name < recorder then recorder = member.name end
  end
  return recorder
end

local function sayHello(force)
  if not compat.inGroup() then return end
  if not force and now() - dungeon.lastHello < 10 then return end
  dungeon.lastHello = now()
  send("HELLO|" .. compat.addonVersion())
end

-- Updates who is in the run and how long they've been present.
local function updatePlayers(run)
  local stamp = now()
  local elapsed = run.lastTick and math.max(0, math.min(stamp - run.lastTick, TICK_SECONDS * 4)) or 0
  local observedElapsed = run.lastTick and math.max(0, stamp - run.lastTick) or 0
  local observationGap = observedElapsed > TICK_SECONDS * 2
  run.lastTick = stamp
  local inside = run.inside and run.state == "ACTIVE"
  local observations = {}
  for _, member in ipairs(compat.groupMembers()) do
    local player = run.players[member.name]
    if not player then
      player = { firstSeen = stamp, presentSec = 0 }
      run.players[member.name] = player
    end
    if member.level then
      player.level = math.max(player.level or member.level, member.level)
      player.minLevel = math.min(player.minLevel or member.level, member.level)
    end
    player.lastSeen = stamp
    player.class = member.class or player.class
    player.role = ns.util.dungeonRole(member.role) or ns.util.dungeonRole(player.role)
    if run.integrity then
      local seen = player.integrity or { knownSec = 0, unknownSec = 0, mixedRole = false, knownIntervals = {} }
      player.integrity = seen
      if run.state == "ACTIVE" then
        local role = ns.util.dungeonRole(member.role)
        if role and seen.lockedRole and role ~= seen.lockedRole then seen.mixedRole = true end
        if role and not seen.lockedRole then seen.lockedRole = role end
      end
      observations[member.name] = inside and compat.dungeonPresence(member.unit) == true
    end
    player.guid = member.guid or player.guid
    player.inGuild = member.inGuild or player.inGuild
    if member.name == me() then
      local identity = ns.getDb().character
      if identity and type(identity.spec) == "string" and identity.spec ~= "" then player.spec = identity.spec end
    end
    if dungeon.addonUsers[member.name] or member.name == me() then
      player.addon = true
      player.deaths = player.deaths or 0
    end
    if inside and member.online then player.presentSec = player.presentSec + elapsed end
  end
  if run.integrity then
    for name, player in pairs(run.players) do
      local seen = player.integrity
      if seen and run.state == "ACTIVE" then
        if not observationGap and observations[name] and player.knownInside then
          seen.knownIntervals = seen.knownIntervals or {}
          local intervals, began = seen.knownIntervals, stamp - observedElapsed
          local last = intervals[#intervals]
          if last and last[2] == began then
            last[2] = stamp; seen.knownSec = seen.knownSec + observedElapsed
          elseif observedElapsed > 0 and #intervals < 64 then
            intervals[#intervals + 1] = { began, stamp }; seen.knownSec = seen.knownSec + observedElapsed
          else seen.unknownSec = seen.unknownSec + observedElapsed end
        else seen.unknownSec = seen.unknownSec + observedElapsed end
      end
      player.knownInside = observations[name] == true
    end
  end
end

-- ---------------------------------------------------------------------
-- Run lifecycle
-- ---------------------------------------------------------------------

local function makeId(recorder, stamp)
  return string.format("QG-%s-%s", date("!%Y%m%d-%H%M%S", stamp), recorder)
end

local function newRun(instance)
  local stamp = now()
  local recorder = electRecorder()
  local run = {
    id = makeId(recorder, stamp),
    protocolVersion = PROTOCOL_VERSION,
    addonVersion = compat.addonVersion(),
    gameBuild = GetBuildInfo and tostring(select(2, GetBuildInfo())) or nil,
    interface = compat.interfaceVersion(),
    gameEdition = ns.util.gameEdition(),
    state = "DETECTED",
    recorder = recorder,
    instanceId = instance.id,
    name = instance.name,
    difficultyId = instance.difficultyId,
    difficultyName = instance.difficultyName,
    detectedAt = stamp,
    encounters = {},
    players = {},
    reporters = { [me()] = true },
    -- Map identity and zero boss kills do not prove a fresh instance copy.
    integrity = { version = 2, startWitness = "unknown", startTrigger = "unknown", continuous = true, observer = me(), detectedAt = stamp },
    inside = true
  }
  local bosses = compat.dungeonBosses(instance.id)
  if bosses and #bosses > 0 then
    run.bossCount = #bosses
    run.finalEncounterId = bosses[#bosses].id
  end
  updatePlayers(run)
  run.state = "STARTING"
  return run
end

-- Death positions (9.1): where in the dungeon the group fell, for the death map on the run card.
-- Each client records its OWN death (position of the player unit) and tells the group with a separate
-- DPOS message, so older clients that do not know it simply ignore it. Positions are thousandths (0..1000)
-- of the map, per uiMapID; at most MAX_DEATH_POINTS per run. Unknown positions (indoor maps that return
-- nothing or 0,0) are never recorded.
local MAX_DEATH_POINTS = 60
local function playerPosition()
  if not (C_Map and C_Map.GetBestMapForUnit and C_Map.GetPlayerMapPosition) then return nil end
  local okMap, mapId = pcall(C_Map.GetBestMapForUnit, "player")
  if not okMap or type(mapId) ~= "number" or ns.isSecret(mapId) or mapId <= 0 then return nil end
  local okPos, position = pcall(C_Map.GetPlayerMapPosition, mapId, "player")
  if not okPos or type(position) ~= "table" or not position.GetXY then return nil end
  local okXY, x, y = pcall(position.GetXY, position)
  if not okXY or type(x) ~= "number" or type(y) ~= "number" or ns.isSecret(x) or ns.isSecret(y) then return nil end
  if x < 0 or x > 1 or y < 0 or y > 1 or (x == 0 and y == 0) then return nil end
  return math.floor(x * 1000 + 0.5), math.floor(y * 1000 + 0.5), mapId
end
local function addDeathPoint(run, name, x, y, mapId)
  if type(run) ~= "table" or type(name) ~= "string" then return false end
  x, y, mapId = tonumber(x), tonumber(y), tonumber(mapId)
  if not x or not y or not mapId or x < 0 or x > 1000 or y < 0 or y > 1000 or mapId <= 0 or mapId > 100000 then return false end
  run.deathPoints = run.deathPoints or {}
  if #run.deathPoints >= MAX_DEATH_POINTS then return false end
  table.insert(run.deathPoints, { name = name, x = math.floor(x) / 1000, y = math.floor(y) / 1000, map = math.floor(mapId) })
  return true
end

-- Traced dungeon maps (9.2): while a run is active inside an instance, a light breadcrumb of where the player walked, so the
-- bot can draw an accurate outline of each dungeon floor in the same coordinates as the death positions. Positions are snapped
-- to a TRACE_GRID x TRACE_GRID grid of the floor's map (uiMapID) and kept only as a set of cells per floor: no timestamps, no
-- order. Short steps between two samples are filled in a straight line (a long jump, a teleport or a floor change never draws a
-- corridor). At most MAX_TRACE_CELLS per run. Stored as run.trace = { { map = id, cells = "key,key,..." } } (key = cx * grid + cy)
-- so SavedVariables and the companion read it simply. Only the recorder's own export uploads it; nothing is sent to the group.
-- On by default; members turn it off with /guilded maptrace off.
local TRACE_GRID, MAX_TRACE_CELLS, TRACE_SECONDS, TRACE_MAX_STEP = 200, 600, 1.5, 12
local traceSets, lastTrace = {}, nil
local function traceOn()
  local s = ns.getSettings and ns.getSettings()
  return not (s and (s.dungeonTrace == false or s.mapShare == false))
end
local function traceEntry(run, mapId)
  run.trace = run.trace or {}
  for _, entry in ipairs(run.trace) do if entry.map == mapId then return entry end end
  local entry = { map = mapId, cells = "" }
  table.insert(run.trace, entry)
  return entry
end
local function traceCount(run)
  local count = 0
  for _, entry in ipairs(run.trace or {}) do for _ in string.gmatch(entry.cells or "", "%d+") do count = count + 1 end end
  return count
end
local function addTraceCell(run, mapId, cx, cy)
  if cx < 0 or cy < 0 or cx >= TRACE_GRID or cy >= TRACE_GRID then return false end
  local id = tostring(run.id) .. ":" .. mapId
  local set = traceSets[id]
  local entry = traceEntry(run, mapId)
  if not set then
    set = {}
    for key in string.gmatch(entry.cells or "", "%d+") do set[tonumber(key)] = true end
    traceSets[id] = set
  end
  local key = cx * TRACE_GRID + cy
  if set[key] then return true end
  run.traceCount = run.traceCount or traceCount(run)
  if run.traceCount >= MAX_TRACE_CELLS then return false end
  set[key] = true
  entry.cells = entry.cells == "" and tostring(key) or (entry.cells .. "," .. key)
  run.traceCount = run.traceCount + 1
  return true
end
-- One breadcrumb sample (called by a ticker every TRACE_SECONDS; tests call it directly).
local function traceSample()
  local d = db()
  local run = d and d.current
  if not run or run.state == "INVALID" or not traceOn() or not (ns.util and ns.util.inInstance and ns.util.inInstance()) then lastTrace = nil; return false end
  local x, y, mapId = playerPosition()
  if not x then return false end
  local cx = math.min(TRACE_GRID - 1, math.floor(x * TRACE_GRID / 1000))
  local cy = math.min(TRACE_GRID - 1, math.floor(y * TRACE_GRID / 1000))
  local last = lastTrace
  if last and last.run == run.id and last.map == mapId then
    local dx, dy = cx - last.cx, cy - last.cy
    local steps = math.max(math.abs(dx), math.abs(dy))
    if steps > 1 and steps <= TRACE_MAX_STEP then
      for i = 1, steps - 1 do addTraceCell(run, mapId, last.cx + math.floor(dx * i / steps + 0.5), last.cy + math.floor(dy * i / steps + 0.5)) end
    end
  end
  addTraceCell(run, mapId, cx, cy)
  lastTrace = { run = run.id, map = mapId, cx = cx, cy = cy }
  return true
end
ns.dungeonTrace = { sample = traceSample, grid = TRACE_GRID, maxCells = MAX_TRACE_CELLS, enabled = traceOn }

local function save(run)
  local d = db()
  if d then d.current = run end
end

local serialize

-- Stores a finished run for export, tells the group, and shares it with
-- officers who are online.
local function finalize(run)
  local d = db()
  if not d then return end
  updatePlayers(run)
  if run.startedAt and run.endedAt then run.durationSec = run.endedAt - run.startedAt end
  if run.state == "COMPLETED" and (not run.durationSec or run.durationSec <= 0) then
    run.state = "INVALID"
    run.endReason = "zero duration"
  end
  run.inside = nil
  run.lastTick = nil
  d.runs[run.id] = run
  d.current = nil
  -- Stay finished across zone notifications and /reload inside the same clear.
  if run.state == "COMPLETED" then d.completedInstanceId = run.instanceId end
  local summary = serialize(run)
  local chunks = {}
  for index = 1, #summary, CHUNK_BYTES do table.insert(chunks, string.sub(summary, index, index + CHUNK_BYTES - 1)) end
  for index, chunk in ipairs(chunks) do send(string.format("SUM|%s|%d|%d|%s", run.id, index, #chunks, chunk), "GUILD") end
  -- Dungeon scores (Scores.lua) learn from every finished run.
  if ns.onDungeonRunFinished then pcall(ns.onDungeonRunFinished, run) end
  -- Automatic results wait for a safe exit. The summary hook remains the manual reopen action.
  if ns.onDungeonResultReady then pcall(ns.onDungeonResultReady, run) end
  ns.message(string.format("Dungeon run %s: %s%s.", run.state, run.name or "?",
    run.durationSec and run.state == "COMPLETED" and string.format(" in %d:%02d", math.floor(run.durationSec / 60), run.durationSec % 60) or ""))
  if ns.onDungeonChange then pcall(ns.onDungeonChange) end
end

local function finish(state, reason)
  local d = db()
  local run = d and d.current
  if not run or TERMINAL[run.state] then return end
  if state == "COMPLETED" and run.state ~= "ACTIVE" then
    ns.message("The run hasn't started yet (no pull). Use /guilded dungeon start first, or abandon it.")
    return
  end
  run.state = state
  run.endedAt = now()
  if state == "COMPLETED" then run.completedBy = reason else run.endReason = reason end
  -- Kills were recorded but none was recognised as the final boss: leave a trace (game ids and
  -- boss names only) so an unknown Forever dungeon id or name can be added to Compat.lua.
  if state == "ABANDONED" and ns.logDiagnostic then
    local last
    for _, encounter in ipairs(run.encounters or {}) do if encounter.success and not encounter.kind then last = encounter end end
    if last then
      pcall(ns.logDiagnostic, "DUNGEON_FINAL_UNMATCHED", string.format("instance %s (%s) last kill %s %s; abandoned: %s",
        tostring(run.instanceId), tostring(run.gameEdition), tostring(last.id), tostring(last.name), tostring(reason)))
    end
  end
  send(string.format("END|%s|%s|%d|%s", run.id, state, run.endedAt, reason or ""))
  finalize(run)
end

local function activate(stamp, trigger)
  local d = db()
  local run = d and d.current
  if not run or run.state ~= "STARTING" then return end
  run.state = "ACTIVE"
  run.startedAt = stamp or now()
  run.startTrigger = trigger or "first combat"
  if run.integrity then
    run.integrity.startTrigger = run.startTrigger
    if run.startTrigger == "first combat" then run.integrity.combatAt = now() end
  end
  run.lastTick = run.startedAt
  updatePlayers(run)
  send(string.format("ACTIVE|%s|%d", run.id, run.startedAt))
  save(run)
  ns.message("Dungeon run started: " .. (run.name or "?") .. ". Good luck!")
  if ns.onDungeonChange then pcall(ns.onDungeonChange) end
end

-- Called on zone changes, login, and every tick.
local function evaluate()
  local d = db()
  if not d then return end
  local instance = compat.instance()
  local run = d.current
  local inDungeon = instance and instance.type == "party" and instance.id
  if not inDungeon or instance.id ~= d.completedInstanceId then d.completedInstanceId = nil end

  if run and not TERMINAL[run.state] then
    if inDungeon and instance.id == run.instanceId then
      run.inside = true
      run.leftAt = nil
    else
      run.inside = false
      run.leftAt = run.leftAt or now()
      if run.state == "STARTING" or run.state == "DETECTED" then
        -- Never pulled anything: not a run.
        d.current = nil
        return
      end
      if now() - run.leftAt >= ABANDON_AFTER_SECONDS then
        finish("ABANDONED", "left the dungeon")
        return
      end
    end
    updatePlayers(run)
    save(run)
    return
  end

  if inDungeon and instance.id ~= d.completedInstanceId then
    local fresh = newRun(instance)
    save(fresh)
    if fresh.recorder == me() then send(string.format("START|%s|%d", fresh.id, fresh.instanceId)) end
    ns.message(string.format("Dungeon detected: %s. The timer starts on the first pull (or /guilded dungeon start).", instance.name))
    if ns.onDungeonChange then pcall(ns.onDungeonChange) end
  end
end

-- ---------------------------------------------------------------------
-- Summary format for sharing with officers (and what the export carries)
-- ---------------------------------------------------------------------

local function clean(text)
  return (string.gsub(tostring(text or ""), "[|;:,=]", " "))
end

serialize = function(run)
  local players = {}
  for name, player in pairs(run.players) do
    table.insert(players, table.concat({
      clean(name), clean(player.class or ""), clean(player.role or ""),
      player.deaths ~= nil and tostring(player.deaths) or "?",
      tostring(math.floor(player.presentSec or 0)), player.inGuild and "1" or "0"
    }, ":"))
  end
  local encounters = {}
  for _, encounter in ipairs(run.encounters) do
    if encounter.success and encounter.id and encounter.kind ~= "npc" then table.insert(encounters, tostring(encounter.id)) end
  end
  local summary = table.concat({
    "v=" .. PROTOCOL_VERSION, "av=" .. clean(run.addonVersion), "st=" .. run.state,
    "gb=" .. clean(run.gameBuild or ""), "tr=" .. clean(run.startTrigger or ""),
    "api=" .. tostring(run.interface or ""), "ed=" .. clean(run.gameEdition or ""),
    "i=" .. tostring(run.instanceId or 0), "n=" .. clean(run.name), "d=" .. tostring(run.difficultyId or 0),
    "s=" .. tostring(run.startedAt or 0), "e=" .. tostring(run.endedAt or 0),
    "cb=" .. clean(run.completedBy or run.endReason or ""), "r=" .. clean(run.recorder),
    "enc=" .. table.concat(encounters, ","), "p=" .. table.concat(players, ",")
  }, ";")
  -- Optional fields keep older peers compatible and respect the 20-chunk limit.
  local specs, timeline = {}, {}
  for name, player in pairs(run.players) do
    if player.spec then specs[#specs + 1] = clean(name) .. ":" .. clean(player.spec) end
  end
  local levels = {}
  for name, player in pairs(run.players or {}) do
    if player.level and player.minLevel then levels[#levels + 1] = clean(name) .. ":" .. player.minLevel .. ":" .. player.level end
  end
  local levelData = ";lv=" .. table.concat(levels, ",")
  if #summary + #levelData <= CHUNK_BYTES * 20 then summary = summary .. levelData end
  local extra = ";sp=" .. table.concat(specs, ",")
  if #summary + #extra <= CHUNK_BYTES * 20 then summary = summary .. extra end
  for _, encounter in ipairs(run.encounters or {}) do
    if encounter.id and encounter.at then
      local row = table.concat({ encounter.id, clean(string.sub(encounter.name or "", 1, 100)), encounter.success and "1" or "0",
        encounter.at, encounter.startedAt or "" }, ":")
      if encounter.kind == "npc" then row = row .. ":npc" end
      local candidate = table.concat(timeline, ",") .. (#timeline > 0 and "," or "") .. row
      if #summary + #candidate + 4 > CHUNK_BYTES * 20 then break end
      timeline[#timeline + 1] = row
    end
  end
  if #timeline > 0 then summary = summary .. ";tl=" .. table.concat(timeline, ",") end
  if run.integrity then
    local observed, intervals, native = {}, {}, {}
    for name, player in pairs(run.players) do
      local p = player.integrity
      if p then observed[#observed + 1] = table.concat({ clean(name), p.knownSec, p.unknownSec, p.lockedRole or "", p.mixedRole and "1" or "0" }, ":") end
      if p and p.knownIntervals then
        local spans = {}
        for _, span in ipairs(p.knownIntervals) do spans[#spans + 1] = span[1] .. "." .. span[2] end
        intervals[#intervals + 1] = clean(name) .. ":" .. table.concat(spans, "/")
      end
    end
    for _, e in ipairs(run.encounters or {}) do if e.source == "native" and e.at then native[#native + 1] = e.id .. ":" .. e.at end end
    local extra = ";iv=2;iw=" .. clean(run.integrity.startWitness) .. ";ic=" .. (run.integrity.continuous and "1" or "0")
      .. ";io=" .. clean(run.integrity.observer) .. ";ie=" .. (run.integrity.detectedAt or "") .. ";ia=" .. (run.integrity.combatAt or "")
      .. ";it=" .. clean(run.integrity.startTrigger) .. ";ip=" .. table.concat(observed, ",")
      .. ";ix=" .. table.concat(intervals, ",") .. ";ns=" .. table.concat(native, ",") .. ";wa=" .. (run.integrity.witnessAt or "")
    if #summary + #extra <= CHUNK_BYTES * 20 then summary = summary .. extra end
  end
  return summary
end

local function deserialize(id, text)
  local fields = {}
  for key, value in string.gmatch(text, "([%a]+)=([^;]*)") do fields[key] = value end
  if tonumber(fields.v) ~= PROTOCOL_VERSION or not fields.st then return nil end
  local run = {
    id = id, protocolVersion = PROTOCOL_VERSION, addonVersion = fields.av, state = fields.st,
    gameBuild = fields.gb ~= "" and fields.gb or nil, startTrigger = fields.tr ~= "" and fields.tr or nil,
    interface = tonumber(fields.api), gameEdition = fields.ed ~= "" and fields.ed or nil,
    instanceId = tonumber(fields.i), name = fields.n, difficultyId = tonumber(fields.d),
    startedAt = tonumber(fields.s) ~= 0 and tonumber(fields.s) or nil,
    endedAt = tonumber(fields.e) ~= 0 and tonumber(fields.e) or nil,
    recorder = fields.r, encounters = {}, players = {}, reporters = {}
  }
  if fields.st == "COMPLETED" then run.completedBy = fields.cb else run.endReason = fields.cb end
  if run.startedAt and run.endedAt then run.durationSec = run.endedAt - run.startedAt end
  for encounterId in string.gmatch(fields.enc or "", "[^,]+") do
    table.insert(run.encounters, { id = tonumber(encounterId), success = true })
  end
  for entry in string.gmatch(fields.p or "", "[^,]+") do
    local name, class, role, deaths, present, inGuild = string.match(entry, "^([^:]*):([^:]*):([^:]*):([^:]*):([^:]*):([^:]*)$")
    name = name and ns.normalizeName(name)
    if name then
      run.players[name] = {
        class = class ~= "" and class or nil, role = ns.util.dungeonRole(role),
        deaths = tonumber(deaths), addon = deaths ~= "?", presentSec = tonumber(present) or 0, inGuild = inGuild == "1"
      }
    end
  end
  if fields.tl and fields.tl ~= "" then
    local timeline = {}
    for entry in string.gmatch(fields.tl, "[^,]+") do
      local kind = string.sub(entry, -4) == ":npc" and "npc" or nil
      if kind then entry = string.sub(entry, 1, -5) end
      local bossId, name, success, at, startedAt = string.match(entry, "^(%d+):([^:]*):([01]):(%d+):(%d*)$")
      if bossId and #timeline < 100 then
        timeline[#timeline + 1] = { id = tonumber(bossId), kind = kind, name = name ~= "" and name or nil,
          success = success == "1", at = tonumber(at), startedAt = tonumber(startedAt) }
      end
    end
    if #timeline > 0 then run.encounters = timeline end
  end
  for entry in string.gmatch(fields.lv or "", "[^,]+") do
    local name, low, high = string.match(entry, "^([^:]+):(%d+):(%d+)$")
    name, low, high = name and ns.normalizeName(name), tonumber(low), tonumber(high)
    if name and run.players[name] and low and high and low >= 1 and high <= 100 and low <= high then
      run.players[name].minLevel, run.players[name].level = low, high
    end
  end
  for entry in string.gmatch(fields.sp or "", "[^,]+") do
    local name, spec = string.match(entry, "^([^:]+):([^:]+)$")
    name = name and ns.normalizeName(name)
    if name and run.players[name] then run.players[name].spec = string.sub(spec, 1, 40) end
  end
  if fields.iv == "2" and (fields.iw == "unknown" or fields.iw == "native-reset" and tonumber(fields.wa)) and (fields.ic == "1" or fields.ic == "0") then
    run.integrity = { version = 2, startWitness = fields.iw, witnessAt = tonumber(fields.wa), startTrigger = fields.it or "unknown", continuous = fields.ic == "1",
      observer = fields.io and ns.normalizeName(fields.io), detectedAt = tonumber(fields.ie), combatAt = tonumber(fields.ia) }
    for entry in string.gmatch(fields.ip or "", "[^,]+") do
      local name, known, unknown, role, mixed = string.match(entry, "^([^:]+):(%d+):(%d+):([^:]*):([01])$")
      name = name and ns.normalizeName(name)
      if name and run.players[name] then run.players[name].integrity = { knownSec = tonumber(known), unknownSec = tonumber(unknown), lockedRole = ns.util.dungeonRole(role), mixedRole = mixed == "1" } end
    end
    for entry in string.gmatch(fields.ix or "", "[^,]+") do
      local name, spans = string.match(entry, "^([^:]+):(.*)$")
      name = name and ns.normalizeName(name)
      local player = name and run.players[name]
      if player and player.integrity then
        player.integrity.knownIntervals = {}
        for a, b in string.gmatch(spans, "(%d+)%.(%d+)") do
          if #player.integrity.knownIntervals < 64 then table.insert(player.integrity.knownIntervals, { tonumber(a), tonumber(b) }) end
        end
      end
    end
    for id, at in string.gmatch(fields.ns or "", "(%d+):(%d+)") do
      for _, e in ipairs(run.encounters) do if e.id == tonumber(id) and e.at == tonumber(at) and not e.kind then e.source = "native" end end
    end
  end
  return run
end
dungeon.serialize = serialize
dungeon.deserialize = deserialize

-- A run someone else reported: keep it, or merge into our copy (more
-- reporters = more trust; deaths take the highest count anyone saw).
local function storePeerRun(run, sender)
  local d = db()
  if not d or not run.id then return end
  local existing = d.runs[run.id]
  if not existing then
    run.reporters = { [sender] = true }
    d.runs[run.id] = run
    if ns.onDungeonRunFinished then pcall(ns.onDungeonRunFinished, run) end
    return
  end
  existing.reporters = existing.reporters or {}
  existing.reporters[sender] = true
  -- An officer may first receive an old client's summary with IDs only.
  local function coverage(encounters)
    local count = 0
    for _, boss in ipairs(encounters or {}) do if boss.at then count = count + 1 end end
    return count
  end
  -- Promote a complete source report, never attach a peer's native checkpoints
  -- to our own observer identity. Old clients/prototypes have no origin.
  local oldOrigin = existing.integrity and existing.integrity.observer
  local newOrigin = run.integrity and run.integrity.observer
  local compatible = existing.instanceId == run.instanceId and existing.difficultyId == run.difficultyId
    and existing.startedAt == run.startedAt and existing.endedAt == run.endedAt
  local contains = true
  for _, old in ipairs(existing.encounters or {}) do
    local found = false
    for _, incoming in ipairs(run.encounters or {}) do
      if incoming.id == old.id and incoming.kind == old.kind and incoming.success == old.success
        and (not old.at or incoming.at == old.at) and (old.source ~= "native" or incoming.source == "native") then found = true end
    end
    if not found then contains = false end
  end
  local nativeUpgrade = false
  for _, incoming in ipairs(run.encounters or {}) do
    if incoming.source == "native" then
      local known = false
      for _, old in ipairs(existing.encounters or {}) do if old.id == incoming.id and old.kind == incoming.kind and old.source == "native" then known = true end end
      if not known then nativeUpgrade = true end
    end
  end
  if compatible and contains and newOrigin and (not oldOrigin or oldOrigin == newOrigin)
    and (not oldOrigin or coverage(run.encounters) > coverage(existing.encounters) or nativeUpgrade) then
    run.reporters = existing.reporters
    -- Preserve the superseded raw copy locally for diagnosis, without recursively
    -- exporting it as another witness or resetting any run/season identifier.
    run.previousObservation = existing.previousObservation or { integrity = existing.integrity, encounters = existing.encounters, players = existing.players }
    d.runs[run.id] = run
    if ns.onDungeonRunFinished then pcall(ns.onDungeonRunFinished, run) end
    return
  end
  if not existing.integrity and coverage(run.encounters) > coverage(existing.encounters) then existing.encounters = run.encounters end
  for name, player in pairs(run.players) do
    local mine = existing.players[name]
    if mine and player.level then mine.level = math.max(mine.level or player.level, player.level) end
    if mine and player.minLevel then mine.minLevel = math.min(mine.minLevel or player.minLevel, player.minLevel) end
    if mine and not mine.spec and player.spec then mine.spec = player.spec end
    if not mine then
      local copied = {}
      for field, value in pairs(player) do if field ~= "integrity" then copied[field] = value end end
      -- A relayed player's intervals were not observed by this report's author.
      if existing.integrity then copied.integrity = { knownSec = 0, unknownSec = existing.durationSec or 0, knownIntervals = {}, mixedRole = false } end
      existing.players[name] = copied
    elseif player.deaths and (not mine.deaths or player.deaths > mine.deaths) then mine.deaths = player.deaths; mine.addon = true end
  end
  if ns.onDungeonRunFinished then pcall(ns.onDungeonRunFinished, existing) end
end

-- ---------------------------------------------------------------------
-- Events
-- ---------------------------------------------------------------------

local function run_recorder(run) return run and run.recorder end

-- Is `name` the leader of your party or raid?
local function leaderIs(name)
  if not UnitIsGroupLeader then return false end
  for _, member in ipairs(compat.groupMembers()) do
    if member.name == name then
      local ok, leader = pcall(UnitIsGroupLeader, member.unit)
      return ok and leader == true
    end
  end
  return false
end

local function onAddonMessage(text, sender)
  local d = db()
  local run = d and d.current
  local kind = string.match(text, "^(%u+)|")
  if kind == "HELLO" then
    if not dungeon.addonUsers[sender] then
      dungeon.addonUsers[sender] = true
      sayHello(true)
    end
    if run and run.players[sender] then run.players[sender].addon = true; run.players[sender].deaths = run.players[sender].deaths or 0 end
  elseif kind == "START" then
    local id, instanceId = string.match(text, "^START|([^|]+)|(%d+)$")
    dungeon.addonUsers[sender] = true
    -- Adopt the id of a recorder that sorts before ours, so the group ends
    -- up with a single run id.
    if run and not TERMINAL[run.state] and tonumber(instanceId) == run.instanceId and id ~= run.id and sender < (run.recorder or me()) then
      run.id = id
      run.recorder = sender
      save(run)
    end
  elseif kind == "ACTIVE" then
    local id, startedAt = string.match(text, "^ACTIVE|([^|]+)|(%d+)$")
    startedAt = tonumber(startedAt)
    -- A start time before this run was even detected (or in the future) is not believed.
    if run and run.players[sender] and run.id == id and startedAt and startedAt >= (run.detectedAt or 0) - 600 and startedAt <= now() + 60 then
      if run.state == "STARTING" then activate(startedAt, "peer")
      elseif run.state == "ACTIVE" and startedAt and startedAt < (run.startedAt or math.huge) then
        local gap = run.startedAt - startedAt
        run.startedAt = startedAt; run.startTrigger = "peer"
        if run.integrity then
          run.integrity.startTrigger = "peer"
          for _, p in pairs(run.players) do
            if p.integrity then p.integrity.unknownSec = p.integrity.unknownSec + gap end
          end
        end
        save(run)
      end
    end
  elseif kind == "DEATH" then
    local id, name, count = string.match(text, "^DEATH|([^|]+)|([^|]+)|(%d+)$")
    name = ns.normalizeName(name)
    local target = (run and run.id == id) and run or (d and d.runs[id or ""])
    if target and name == sender and target.players[name] then
      local player = target.players[name]
      player.addon = true
      player.deaths = math.max(player.deaths or 0, tonumber(count) or 0)
    end
  elseif kind == "DPOS" then
    local id, name, x, y, mapId = string.match(text, "^DPOS|([^|]+)|([^|]+)|(%d+)|(%d+)|(%d+)$")
    name = name and ns.normalizeName(name)
    local target = (run and run.id == id) and run or (d and d.runs[id or ""])
    -- Only the player's own death position, only for a player already in that run.
    if target and name == sender and target.players[name] then addDeathPoint(target, name, x, y, mapId) end
  elseif kind == "END" then
    local id, state, endedAt, reason = string.match(text, "^END|([^|]+)|(%u+)|(%d+)|(.*)$")
    -- Only the run's recorder or the group leader can end the run for everyone, and only
    -- with an end time that makes sense (after the start, not in the future). Anyone else's
    -- END is ignored; their own client still records the run the normal way.
    local trusted = sender == run_recorder(run) or leaderIs(sender)
    local stamp = tonumber(endedAt)
    local sane = stamp and stamp <= now() + 60 and stamp >= ((run and (run.startedAt or run.detectedAt)) or 0)
    if run and run.id == id and trusted and sane and not TERMINAL[run.state] and (state == "COMPLETED" or state == "ABANDONED") then
      run.state = state
      run.endedAt = tonumber(endedAt)
      if state == "COMPLETED" then run.completedBy = reason else run.endReason = reason end
      if state == "COMPLETED" and not run.startedAt then run.startedAt = run.detectedAt end
      if state == "COMPLETED" and run.integrity and run.integrity.observer then d.peerCompletedRunId = run.id end
      finalize(run)
    end
  elseif kind == "REQUEST" and ns.isOfficerName and ns.isOfficerName(sender) then
    dungeon.replayPending()
  elseif kind == "ACK" then
    -- (9.0) A guildmate whose companion's bot already stored this run: stop replaying it at
    -- every login. Only our own copy is marked; the bot still dedupes by run id.
    local id = string.match(text, "^ACK|([^|]+)$")
    local saved = id and d and d.runs[id]
    if saved and not saved.synced and not saved.syncedVia then
      saved.syncedVia = sender
      saved.syncedViaAt = now()
      dungeon.stats.acksHeard = dungeon.stats.acksHeard + 1
    end
  elseif kind == "SUM" then
    local id, index, total, payload = string.match(text, "^SUM|([^|]+)|(%d+)|(%d+)|(.*)$")
    index, total = tonumber(index), tonumber(total)
    if not id or not index or not total or total < 1 or total > 20 or index < 1 or index > total then return end
    if #id > 120 then return end
    local count, senderCount = 0, 0
    for bufferKey, buffer in pairs(dungeon.incoming) do
      if not buffer.at or now() - buffer.at > 60 then dungeon.incoming[bufferKey] = nil
      else
        count = count + 1
        if buffer.sender == sender then senderCount = senderCount + 1 end
      end
    end
    local key = sender .. "|" .. id
    local pending = dungeon.incoming[key]
    if pending and pending.total ~= total then dungeon.incoming[key] = nil; return end
    if not pending and (count >= 64 or senderCount >= 4) then return end
    pending = pending or { parts = {}, count = 0, total = total, at = now(), sender = sender }
    dungeon.incoming[key] = pending
    if not pending.parts[index] then pending.parts[index] = payload; pending.count = pending.count + 1 end
    if pending.count >= pending.total then
      dungeon.incoming[key] = nil
      local peer = deserialize(id, table.concat(pending.parts))
      -- Only someone who was in the run can report it, and not with times in the future.
      if peer and peer.players[sender] and not ns.util.tooFarAhead(peer.endedAt or 0)
        and not ns.util.tooFarAhead(peer.startedAt or 0) then
        local known = d and d.runs[id]
        -- (9.0) A replay of a run this PC's bot already stored: say so once, so the sender
        -- (a Guilded Dungeons-only player, or someone without the companion) stops replaying it.
        if known and known.synced and not dungeon.acked[id] then
          dungeon.acked[id] = true
          dungeon.stats.acksSent = dungeon.stats.acksSent + 1
          send("ACK|" .. id, "GUILD")
        end
        storePeerRun(peer, sender)
      end
    end
  end
end

local function recordEncounter(run, encounterId, name, success, kind)
  local stamp = now()
  local active = run.activeEncounter
  -- Clients can emit both END and BOSS_KILL for the same kill, in either order.
  for index = #run.encounters, 1, -1 do
    local previous = run.encounters[index]
    if success and previous.success and previous.at and math.abs(stamp - previous.at) <= 10
      and (previous.id == encounterId and previous.kind == kind
        or ns.dungeonRoutes and ns.dungeonRoutes.sameBoss(run.instanceId, run.difficultyId, previous, encounterId, kind)) then
      if previous.kind == "npc" and not kind then
        previous.id, previous.kind = encounterId, nil
        previous.source = "native"
        previous.name = name or previous.name
        save(run)
      end
      run.activeEncounter = nil
      return
    end
  end
  if #run.encounters < 100 then
    table.insert(run.encounters, { id = encounterId, kind = kind, source = kind == "npc" and "combat-log" or "native", name = name, success = success, at = stamp,
      startedAt = active and active.id == encounterId and active.startedAt or nil })
  end
  run.activeEncounter = nil
  save(run)
end

-- A peer END can arrive just before this client's native final-boss event.
-- Retain that real local event without reopening the run or announcing it twice.
local function lateNativeCompletion(encounterId, name)
  local d, instance = db(), compat.instance()
  local run = d and d.peerCompletedRunId and d.runs[d.peerCompletedRunId]
  if not run or not instance or instance.type ~= "party" or instance.id ~= run.instanceId
    or ns.isSecret(encounterId) or not tonumber(encounterId) or not run.endedAt or math.abs(now() - run.endedAt) > 5 then return end
  if not (run.finalEncounterId == tonumber(encounterId) or compat.isDungeonFinalBoss(run.instanceId, encounterId, name, run.difficultyId)) then return end
  local gap = math.max(0, now() - run.endedAt)
  run.endedAt = math.max(run.endedAt, now()); run.durationSec = run.endedAt - run.startedAt
  for _, p in pairs(run.players) do if p.integrity then p.integrity.unknownSec = p.integrity.unknownSec + gap end end
  recordEncounter(run, tonumber(encounterId), not ns.isSecret(name) and name or nil, true)
  d.current = nil; d.peerCompletedRunId = nil
  if ns.onDungeonRunFinished then pcall(ns.onDungeonRunFinished, run) end
end

local function onEvent(_, event, ...)
  local d = db()
  if event == "PLAYER_LOGIN" then
    if d and d.current and d.current.integrity and d.current.state == "ACTIVE" then
      -- Keep the original wall clock across reloads. The unobserved interval
      -- cannot earn presence, but a reload alone does not prove a reset.
      local gap = math.max(0, now() - (d.current.lastTick or now()))
      for _, p in pairs(d.current.players) do
        if p.integrity then p.integrity.unknownSec = p.integrity.unknownSec + gap end
      end
      d.current.lastTick = now()
      for _, p in pairs(d.current.players) do p.knownInside = false end
    end
    ns.comm.register(PREFIX)
    dungeon.loadedAt = now()
    if C_Timer then C_Timer.After(30, function()
      dungeon.markSynced()
      -- After markSynced: a recovered run is changed, so it must upload again.
      pcall(dungeon.recoverRuns)
      pcall(dungeon.remindWaiting)
      pcall(dungeon.noteOtherAddonVersion)
      dungeon.replayPending()
      if ns.isOfficer and ns.isOfficer() then send("REQUEST|1", "GUILD") end
    end) end
    return
  end
  if not d then return end
  if event == "PLAYER_LOGOUT" then
    -- Logout and /reload both write the saved file the companion reads (overdueRuns).
    d.saveBeforeAt, d.lastSaveAt = d.lastSaveAt, now()
    return
  end
  if event == "PLAYER_ENTERING_WORLD" or event == "ZONE_CHANGED_NEW_AREA" then
    dungeon.markSynced()
    sayHello(false)
    evaluate()
  elseif event == "GROUP_ROSTER_UPDATE" then
    sayHello(false)
    if not compat.inGroup() and d.current and d.current.state == "ACTIVE" and not d.current.inside then
      finish("ABANDONED", "group disbanded")
    elseif d.current then
      updatePlayers(d.current)
      save(d.current)
    end
  elseif event == "PLAYER_REGEN_DISABLED" then
    local run = d.current
    if run and run.state == "ACTIVE" and run.inside and run.integrity and not run.integrity.combatAt then run.integrity.combatAt = now() end
    if run and run.state == "STARTING" and run.inside then activate() end
  elseif event == "PLAYER_REGEN_ENABLED" then
    flush()
  elseif event == "ENCOUNTER_START" then
    local encounterId, name = ...
    local run, instance = d.current, compat.instance()
    if not run or TERMINAL[run.state] or not instance or instance.type ~= "party"
      or instance.id ~= run.instanceId or ns.isSecret(encounterId) or not tonumber(encounterId) then return end
    if run.state == "STARTING" then activate(nil, "encounter start") end
    if not run.activeEncounter or run.activeEncounter.id ~= tonumber(encounterId) then
      run.activeEncounter = { id = tonumber(encounterId), startedAt = now(), name = not ns.isSecret(name) and name or nil }
      save(run)
    end
  elseif event == "ENCOUNTER_END" then
    local encounterId, name, _, _, success = ...
    local run = d.current
    if not run and not ns.isSecret(success) and success == 1 then lateNativeCompletion(encounterId, name); return end
    local instance = compat.instance()
    if not run or TERMINAL[run.state] or not instance or instance.type ~= "party"
      or instance.id ~= run.instanceId or ns.isSecret(encounterId) or ns.isSecret(success) then return end
    if run.state == "STARTING" then activate(nil, "encounter end") end
    if not tonumber(encounterId) then return end
    recordEncounter(run, tonumber(encounterId), (not ns.isSecret(name)) and name or nil, success == 1)
    if success == 1 and ((run.finalEncounterId and tonumber(encounterId) == run.finalEncounterId)
      or compat.isDungeonFinalBoss(run.instanceId, encounterId, name, run.difficultyId)) then
      finish("COMPLETED", "final boss")
    end
  elseif event == "BOSS_KILL" then
    local run = d.current
    if not run then local encounterId, name = ...; lateNativeCompletion(encounterId, name); return end
    if not run or run.state ~= "ACTIVE" then return end
    local encounterId, name = ...
    if ns.isSecret(encounterId) or ns.isSecret(name) then return end
    local instance = compat.instance()
    if not instance or instance.type ~= "party" or instance.id ~= run.instanceId then return end
    if not tonumber(encounterId) then return end
    recordEncounter(run, tonumber(encounterId), name, true)
    if ((run.finalEncounterId and tonumber(encounterId) == run.finalEncounterId)
      or compat.isDungeonFinalBoss(run.instanceId, encounterId, name, run.difficultyId)) then
      finish("COMPLETED", "final boss")
    end
  elseif event == "PLAYER_DEAD" then
    local run = d.current
    if run and run.state == "ACTIVE" then
      local mine = run.players[me()] or { presentSec = 0 }
      run.players[me()] = mine
      mine.addon = true
      mine.deaths = (mine.deaths or 0) + 1
      local x, y, mapId = playerPosition()
      if x and addDeathPoint(run, me(), x, y, mapId) then
        send(string.format("DPOS|%s|%s|%d|%d|%d", run.id, me(), x, y, mapId))
      end
      save(run)
      send(string.format("DEATH|%s|%s|%d", run.id, me(), mine.deaths))
    end
  elseif event == "CHAT_MSG_ADDON" then
    local prefix, text, channel, sender = ...
    if not ns.comm.accept(prefix, text, channel, sender, PREFIX, function(author, delivery)
      local kind = string.match(text, "^(%u+)|")
      if kind == "SUM" or kind == "REQUEST" or kind == "ACK" then
        return delivery == "GUILD" and ns.comm.authorized(author, "guild")
      end
      return (delivery == "PARTY" or delivery == "RAID" or delivery == "INSTANCE_CHAT")
        and ns.comm.authorized(author, "group")
    end) then return end
    if ns.isSecret(prefix) or ns.isSecret(text) or ns.isSecret(sender) or prefix ~= PREFIX then return end
    sender = ns.normalizeName(sender)
    if not sender or sender == me() then return end
    onAddonMessage(text, sender)
  end
end

-- ---------------------------------------------------------------------
-- Sync acknowledgement: the companion writes the run ids the bot received
-- into Standings.lua (GuildedDungeonAccepted); mark those synced and
-- forget them after 30 days. Since 9.0.8 the bot lists every run it received,
-- including a guildmate's copy of a run it already had and runs it refused,
-- and GuildedDungeonNotes says in a few words why a run earned nothing.
-- ---------------------------------------------------------------------

function dungeon.markSynced()
  local d = db()
  if not d then return end
  local accepted = type(GuildedDungeonAccepted) == "table" and GuildedDungeonAccepted or {}
  local notes = type(GuildedDungeonNotes) == "table" and GuildedDungeonNotes or nil
  for _, id in ipairs(accepted) do
    local run = d.runs[id]
    if run then
      run.synced = true
      -- Only a companion that writes notes (9.0.8+) may clear one.
      if notes then
        local note = notes[id]
        run.syncNote = type(note) == "string" and note ~= "" and string.sub(string.gsub(note, "|", ""), 1, 80) or nil
      end
    end
  end
  local cutoff = now() - KEEP_SYNCED_DAYS * 86400
  local peerCutoff = now() - KEEP_PEER_DAYS * 86400
  local mine = me()
  for id, run in pairs(d.runs) do
    local at = run.endedAt or run.detectedAt or 0
    -- (9.0) A copy a guildmate's bot confirmed (ACK or catch-up) ages out like a synced one; a
    -- guildmate's run nobody confirmed goes after 45 days. Our own unconfirmed runs stay.
    local confirmed = run.synced or run.syncedVia
    local ours = mine and run.players and run.players[mine]
    if (confirmed and at < cutoff) or (not confirmed and not ours and at < peerCutoff) then
      d.runs[id] = nil
      dungeon.stats.pruned = dungeon.stats.pruned + 1
    end
  end
end

-- (9.0.8) Finished runs no bot has confirmed yet: neither ours (synced) nor a guildmate's (syncedVia).
function dungeon.waitingRuns()
  local d = db()
  local list = {}
  for _, run in pairs(d and d.runs or {}) do
    if not run.synced and not run.syncedVia and TERMINAL[run.state] then list[#list + 1] = run end
  end
  return list
end

-- (9.0.8) Runs the companion should already have delivered: saved to disk before the last save
-- (logout or /reload) with time for the companion to send them and bring the answer back before
-- this load. The companion answers within a minute, and Standings.lua is only read at load time.
local COMPANION_GRACE = 5 * 60
function dungeon.overdueRuns()
  local d = db()
  if not d then return {} end
  local last, before, loadedAt = tonumber(d.lastSaveAt), tonumber(d.saveBeforeAt), tonumber(dungeon.loadedAt) or now()
  local cutoff
  if last and loadedAt - last >= COMPANION_GRACE then cutoff = last
  elseif before and last and last - before >= COMPANION_GRACE then cutoff = before end
  local list = {}
  if not cutoff then return list end
  for _, run in ipairs(dungeon.waitingRuns()) do
    if (run.endedAt or 0) > 0 and run.endedAt < cutoff then list[#list + 1] = run end
  end
  return list
end

local function L(text) return ns.L and ns.L(text) or text end

-- (9.1) The three companion steps and the page link, one chat line each, for members who have no
-- companion running (also in the standalone Guilded Dungeons addon, which has no Home page).
local function sayCompanionSteps()
  local util = ns.util
  if not (util and util.companionSteps) then return end
  for _, line in ipairs(util.companionSteps()) do ns.message(line) end
  ns.message(util.COMPANION_PAGE)
end

-- (9.1.3) Guilded and Guilded Dungeons are one product with one version. Side by side at different
-- versions (an older Guilded Dungeons left behind by an update) Guilded alone records the runs, so
-- nothing breaks, but say so once per session: the companion updates both, or the member can remove
-- Guilded Dungeons, which Guilded replaces.
function dungeon.noteOtherAddonVersion(force)
  if ns.standalone then return false end
  local other
  if C_AddOns and C_AddOns.GetAddOnMetadata then other = select(2, pcall(C_AddOns.GetAddOnMetadata, "GuildedDungeons", "Version")) end
  if type(other) ~= "string" and GetAddOnMetadata then other = select(2, pcall(GetAddOnMetadata, "GuildedDungeons", "Version")) end
  local mine = compat.addonVersion()
  if type(other) ~= "string" or other == "" or other == mine then return false end
  if dungeon.otherVersionSaid and not force then return false end
  if dungeon.otherVersionSaid == other and force then return false end
  dungeon.otherVersionSaid = other
  ns.message(string.format(L("Guilded Dungeons %s is installed next to Guilded %s. Guilded records your runs; update Guilded Dungeons with the Guilded Companion (or remove it)."), other, tostring(mine)))
  return true
end

-- Once per session, after login or /reload: runs are waiting and the companion did not deliver them.
function dungeon.remindWaiting()
  if dungeon.waitingReminded then return false end
  local overdue = #dungeon.overdueRuns()
  if overdue == 0 then return false end
  dungeon.waitingReminded = true
  ns.message(string.format(L("%d dungeon run(s) have not reached Discord yet. Is the Guilded Companion app running on this PC? Start it from the Windows Start menu: it sends your runs when you /reload or log out."), overdue))
  sayCompanionSteps()
  return true
end

-- (9.0) Every saved run, for the catch-up module (Modules/CatchUp.lua).
function dungeon.savedRuns()
  local d = db()
  return d and d.runs or {}
end

-- (9.0) A run a guildmate forwarded during catch-up: stored exactly as if `reporter` (who was
-- in the run, checked by the caller) had sent it, plus who passed it on. Returns true when new.
function dungeon.storeForwarded(run, reporter, via)
  local d = db()
  if not d or not run or not run.id or not run.players or not run.players[reporter] then return false end
  local isNew = d.runs[run.id] == nil
  storePeerRun(run, reporter)
  if isNew and d.runs[run.id] then d.runs[run.id].forwardedBy = via end
  if isNew and ns.onDungeonChange then pcall(ns.onDungeonChange) end
  return isNew
end

-- Recovery for runs that ended ABANDONED although the client's own ENCOUNTER_END/BOSS_KILL
-- already recorded the final boss (8.4.4-8.4.6 did not know Forever's final-boss ids: a
-- Ragefire Chasm run with Bazzalan killed finished as ABANDONED). A run is completed only
-- from its own saved, timestamped, successful native kill of a boss that today's tables
-- call final, taken inside the run's own time span. Nothing else is invented: a run with
-- no such kill stays ABANDONED, and the end time becomes the kill, not the abandon time.
local RECOVERY_VERSION = 1
function dungeon.recoverRuns()
  local d = db()
  if not d then return 0 end
  local recovered = 0
  for _, run in pairs(d.runs) do
    if run.state == "ABANDONED" and run.startedAt and run.endedAt
      and run.gameEdition == ns.util.gameEdition() then
      local final
      for _, encounter in ipairs(run.encounters or {}) do
        if encounter.success and not encounter.kind and encounter.source == "native" and tonumber(encounter.id)
          and tonumber(encounter.at) and encounter.at > run.startedAt and encounter.at <= run.endedAt
          and ((run.finalEncounterId and tonumber(encounter.id) == run.finalEncounterId)
            or compat.isDungeonFinalBoss(run.instanceId, encounter.id, encounter.name, run.difficultyId)) then
          if not final or encounter.at > final.at then final = encounter end
        end
      end
      if final then
        local abandonedAt = run.endedAt
        run.state, run.endedAt, run.completedBy = "COMPLETED", final.at, "final boss"
        run.endReason, run.synced = nil, nil
        run.recoveredFrom = { state = "ABANDONED", endedAt = abandonedAt, version = RECOVERY_VERSION }
        run.durationSec = run.endedAt - run.startedAt
        -- Presence never exceeds the (shorter) run; observed intervals stop at the kill.
        for _, player in pairs(run.players or {}) do
          player.presentSec = math.min(player.presentSec or 0, run.durationSec)
          local seen = player.integrity
          if seen then
            local kept, known = {}, 0
            for _, span in ipairs(seen.knownIntervals or {}) do
              local from, to = span[1], math.min(span[2], run.endedAt)
              if from < to then kept[#kept + 1] = { from, to }; known = known + (to - from) end
            end
            seen.knownIntervals, seen.knownSec = kept, known
            seen.unknownSec = math.max(0, math.min(seen.unknownSec or 0, run.durationSec - known))
          end
        end
        if run.durationSec > 0 then
          recovered = recovered + 1
          if ns.onDungeonRunFinished then pcall(ns.onDungeonRunFinished, run) end
        else
          run.state, run.endedAt, run.completedBy, run.endReason, run.recoveredFrom = "ABANDONED", abandonedAt, nil, "left the dungeon", nil
          run.durationSec = run.endedAt - run.startedAt
        end
      end
    end
  end
  if recovered > 0 then
    ns.message(string.format("Guilded recovered %d dungeon run(s) whose final boss was killed; they upload with your next sync.", recovered))
    if ns.onDungeonChange then pcall(ns.onDungeonChange) end
  end
  return recovered
end

-- Retry only our own recent unsynced runs. An officer arriving later can request
-- them; the server's run id makes a repeated upload idempotent.
function dungeon.replayPending()
  if dungeon.lastReplay and now() - dungeon.lastReplay < 60 then return end
  dungeon.lastReplay = now()
  local d = db()
  local runs = {}
  for _, run in pairs(d and d.runs or {}) do
    if not run.synced and not run.syncedVia and run.players and run.players[me()] and TERMINAL[run.state]
      and (run.endedAt or 0) >= now() - 7 * 86400 then runs[#runs + 1] = run end
  end
  table.sort(runs, function(a, b) return (a.endedAt or 0) > (b.endedAt or 0) end)
  for index = 1, math.min(5, #runs) do
    local run = runs[index]
    local summary = serialize(run)
    local total = math.ceil(#summary / CHUNK_BYTES)
    if total <= 20 then
      for part = 1, total do
        send(string.format("SUM|%s|%d|%d|%s", run.id, part, total, string.sub(summary, (part - 1) * CHUNK_BYTES + 1, part * CHUNK_BYTES)), "GUILD")
      end
    end
  end
end

-- ---------------------------------------------------------------------
-- Commands
-- ---------------------------------------------------------------------

local function canControl()
  return compat.isLeader() or ns.isOfficer() or not compat.inGroup()
end

local function status()
  local d = db()
  local run = d and d.current
  if not run then
    local total = 0
    for _ in pairs(d and d.runs or {}) do total = total + 1 end
    local pending = #dungeon.waitingRuns()
    ns.message(string.format(L("No dungeon run in progress. Saved runs: %d (%d waiting to reach Discord)."), total, pending))
    if pending > 0 then
      local overdue = #dungeon.overdueRuns() > 0
      ns.message(overdue
        and L("Is the Guilded Companion app running on this PC? Start it from the Windows Start menu: it sends your runs when you /reload or log out.")
        or L("They go to Discord when you /reload or log out while the Guilded Companion app is running."))
      if overdue then sayCompanionSteps() end
    end
    return
  end
  local elapsed = run.startedAt and (now() - run.startedAt) or 0
  local kills = 0
  for _, encounter in ipairs(type(run.encounters) == "table" and run.encounters or {}) do if encounter.success then kills = kills + 1 end end
  local recorder = run.recorder or "?"
  if ns.displayName then recorder = ns.displayName(recorder) or recorder end
  ns.message(string.format("%s - %s%s - bosses %d%s - recorder %s", run.name or "?", tostring(run.state),
    run.state == "ACTIVE" and string.format(" %d:%02d", math.floor(elapsed / 60), elapsed % 60) or "",
    kills, run.bossCount and ("/" .. run.bossCount) or "", tostring(recorder)))
end

local function check()
  local features = compat.features()
  local lines = {}
  for name, ok in pairs(features) do table.insert(lines, (ok and "OK " or "NO ") .. name) end
  table.sort(lines)
  ns.message("Dungeon tracking on this client: " .. table.concat(lines, ", "))
  local instance = compat.instance()
  if instance then
    local bosses = compat.dungeonBosses(instance.id)
    ns.message(string.format("Here: %s (id %s, %s, difficulty %s). Final boss from journal: %s", instance.name, tostring(instance.id),
      instance.type, tostring(instance.difficultyId), bosses and bosses[#bosses].name or "not available (use Complete)"))
  end
end

ns.commandHandlers = ns.commandHandlers or {}
local function handleDungeonCommand(args)
  local action = string.lower(args[1] or "status")
  local d = db()
  -- (9.1.3) Never silent: a member who types /guilded dungeon always gets a line back.
  if not d then ns.message(L("Dungeon data is not loaded yet. Try again in a moment, or /reload.")) return end
  if action == "status" then status()
  elseif action == "results" then
    local latest
    for _, run in pairs(d.runs) do
      if run.players and run.players[me()] and (not latest or (run.endedAt or 0) > (latest.endedAt or 0)) then latest = run end
    end
    if latest and ns.onDungeonSummary then ns.onDungeonSummary(latest)
    else ns.message(ns.L and ns.L("No saved dungeon result yet.") or "No saved dungeon result yet.") end
  elseif action == "check" then check()
  elseif action == "start" then
    if not d.current then ns.message("Not in a tracked dungeon run.") return end
    if not canControl() then ns.message("Only the group leader or an officer can do that.") return end
    activate(nil, "manual")
  elseif action == "complete" then
    if not canControl() then ns.message("Only the group leader or an officer can do that.") return end
    finish("COMPLETED", "manual")
  elseif action == "abandon" then
    if not canControl() then ns.message("Only the group leader or an officer can do that.") return end
    finish("ABANDONED", "manual")
  else
    ns.message("/guilded dungeon status | results | start | complete | abandon | check")
  end
end
ns.commandHandlers["dungeon"] = function(args)
  local ok, err = pcall(handleDungeonCommand, args or {})
  if not ok then
    -- A failure is said, never swallowed: the member sees it and the diagnostics keep it.
    if ns.logDiagnostic then ns.logDiagnostic("LUA_ERROR", "dungeon command: " .. tostring(err)) end
    ns.message(L("The dungeon command failed. /guilded diag shows the details."))
  end
  pcall(dungeon.noteOtherAddonVersion, true)
end
ns.commandHelp = ns.commandHelp or {}
table.insert(ns.commandHelp, "/guilded dungeon status | results | start | complete | abandon | check - dungeon runs")

local frame = CreateFrame("Frame")
for _, event in ipairs({ "PLAYER_LOGIN", "PLAYER_LOGOUT", "PLAYER_ENTERING_WORLD", "ZONE_CHANGED_NEW_AREA", "GROUP_ROSTER_UPDATE",
  "PLAYER_REGEN_DISABLED", "PLAYER_REGEN_ENABLED", "ENCOUNTER_END", "PLAYER_DEAD", "CHAT_MSG_ADDON" }) do
  compat.registerEvent(frame, event)
end
compat.registerEvent(frame, "BOSS_KILL", true)
compat.registerEvent(frame, "ENCOUNTER_START", true)
frame:SetScript("OnEvent", function(...)
  if ns.moduleActive and not ns.moduleActive("dungeon") then return end -- /guilded modules
  local ok, err = pcall(onEvent, ...)
  if not ok and ns.logDiagnostic then ns.logDiagnostic("LUA_ERROR", "Guilded dungeon: " .. tostring(err)) end
end)

-- Presence time and the abandon check, every 30 seconds while a run exists.
if C_Timer and C_Timer.NewTicker then
  C_Timer.NewTicker(TICK_SECONDS, function()
    if ns.moduleActive and not ns.moduleActive("dungeon") then return end
    local d = db()
    if d and d.current then pcall(evaluate) end
  end)
  -- Traced dungeon maps: one breadcrumb sample every TRACE_SECONDS while a run is active.
  C_Timer.NewTicker(TRACE_SECONDS, function()
    if ns.moduleActive and not ns.moduleActive("dungeon") then return end
    local d = db()
    if d and d.current then pcall(traceSample) end
  end)
end

-- /guilded maptrace on | off: the member's own switch for traced dungeon maps (on by default).
ns.commandHandlers = ns.commandHandlers or {}
ns.commandHandlers["maptrace"] = function(args)
  local s = ns.getSettings and ns.getSettings()
  local word = string.lower(type(args) == "table" and tostring(args[1] or "") or "")
  if s and (word == "on" or word == "off") then s.dungeonTrace = word == "on" end
  ns.message(traceOn() and L("Dungeon map tracing is on: in dungeons, Guilded notes the map squares you walk through (no times) to draw the dungeon's map. /guilded maptrace off stops it.")
    or L("Dungeon map tracing is off. /guilded maptrace on turns it back on."))
end
ns.commandHelp = ns.commandHelp or {}
table.insert(ns.commandHelp, "/guilded maptrace on | off - help draw accurate dungeon maps from the squares you walk through in dungeons (no times); ON by default")
