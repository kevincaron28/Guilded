-- Guild map: guildmates who run Guilded show as class-coloured dots on the world map and the
-- minimap, with their name, level and zone on hover.
--
--   /guilded map                  who is where (and your settings)
--   (your position is always sent to the guild: there is no sharing switch)
--   /guilded map show on|off      show guildmates' dots (default on)
--
-- Each client sends its own map position to the guild channel (prefix GuildedMap) every few
-- seconds while it moves, and every 30 s while it stands still. Nothing is sent inside an
-- instance or in combat (the game hides positions there and limits addon messages); a "gone"
-- message then clears your dot for everyone. Dots fade after 90 s without news.
--
-- All map APIs are optional: a client without one of them just shows fewer dots.
--
-- Phone map (Track M): the player's own last outdoor position per character (db.mapSeen, every
-- 30 s) and a short trail (db.mapTrail, one point per 10 minutes, 7 days, at most 40) are saved
-- for this member's companion to upload. Only signed-in members of the same guild see them in the
-- phone app; a member who turns sharing off there has them deleted on the bot.
local addonName, ns = ...
ns = ns or {}

local PREFIX = "GuildedMap"
local SEND_MOVING_SECONDS = 5
local SAVE_SECONDS = 30
local TRAIL_SECONDS = 600
local TRAIL_MAX = 40
local TRAIL_KEEP_SECONDS = 7 * 86400
local CONTINENT_MAP_TYPE = 2 -- Enum.UIMapType.Continent
local SEND_IDLE_SECONDS = 30
local EXPIRE_SECONDS = 90
-- Moving less than this share of the map is "standing still".
local MOVE_THRESHOLD = 0.002
local TICK_SECONDS = 1
local MINIMAP_REFRESH_SECONDS = 0.2
-- Minimap diameter in yards per zoom level (0 = most zoomed out), outdoors and indoors.
local MINIMAP_OUTDOOR = { [0] = 466 + 2 / 3, 400, 333 + 1 / 3, 266 + 2 / 3, 200, 133 + 1 / 3 }
local MINIMAP_INDOOR = { [0] = 300, 240, 180, 120, 80, 50 }
local PIN_TEXTURE = "Interface\\WorldMap\\WorldMapPartyIcon"

local map = { members = {}, worldPins = {}, minimapPins = {} }
ns.guildMap = map
-- Session-only counters: diagnose a one-way connection without saving chat or coordinates.
local received = { messages = 0, positions = 0, ignored = 0, last = "none" }
local lastTickAt, lastPositionQueuedAt
local lastSavedAt, lastTrailAt = -1000, -1000

local function active() return not ns.moduleActive or ns.moduleActive("guildmap") end
local function secret(value) return ns.isSecret and ns.isSecret(value) end
local function clock()
  local ok, value = pcall(GetTime)
  if ok and type(value) == "number" then return value end
  return time()
end
local function L(text) return ns.L and ns.L(text) or text end

local function settings()
  local s = ns.getSettings and ns.getSettings()
  if not s then return nil end
  s.mapShare = true -- always on: there is no sharing option any more
  if s.mapShow == nil then s.mapShow = true end
  return s
end

-- ---------------------------------------------------------------------
-- Positions
-- ---------------------------------------------------------------------

-- Your map and position (0..1), or nil where the game does not give one (instances, some
-- clients, secret values).
function map.myPosition()
  if IsInInstance then
    local ok, inside = pcall(IsInInstance)
    if ok and inside then return nil end
  end
  if not (C_Map and C_Map.GetBestMapForUnit and C_Map.GetPlayerMapPosition) then return nil end
  local ok, mapId = pcall(C_Map.GetBestMapForUnit, "player")
  if not ok or type(mapId) ~= "number" or secret(mapId) then return nil end
  local okPos, position = pcall(C_Map.GetPlayerMapPosition, mapId, "player")
  if not okPos or not position then return nil end
  local okXY, x, y = pcall(function() return position:GetXY() end)
  if not okXY or type(x) ~= "number" or type(y) ~= "number" or secret(x) or secret(y) then return nil end
  if x <= 0 and y <= 0 then return nil end
  return mapId, x, y
end

-- A point on one map as a point on another (a zone on its continent map, say), or nil when the
-- viewed map does not contain it.
function map.translate(fromMap, x, y, toMap)
  if fromMap == toMap then return x, y end
  -- Parent-map rectangles also work when world conversion cannot represent the world map.
  if C_Map and C_Map.GetMapRectOnMap then
    local ok, left, right, top, bottom = pcall(C_Map.GetMapRectOnMap, fromMap, toMap)
    if ok and type(left) == "number" and type(right) == "number" and type(top) == "number" and type(bottom) == "number"
      and right > left and bottom > top then
      local tx, ty = left + x * (right - left), top + y * (bottom - top)
      if tx >= 0 and tx <= 1 and ty >= 0 and ty <= 1 then return tx, ty end
    end
  end
  if not (C_Map and C_Map.GetWorldPosFromMapPos and C_Map.GetMapPosFromWorldPos and CreateVector2D) then return nil end
  local ok, continent, world = pcall(C_Map.GetWorldPosFromMapPos, fromMap, CreateVector2D(x, y))
  if not ok or not continent or not world then return nil end
  local okMap, uiMap, position = pcall(C_Map.GetMapPosFromWorldPos, continent, world, toMap)
  if not okMap or not position or (uiMap and uiMap ~= toMap) then return nil end
  local okXY, tx, ty = pcall(function() return position:GetXY() end)
  if not okXY or type(tx) ~= "number" or type(ty) ~= "number" then return nil end
  if tx < 0 or tx > 1 or ty < 0 or ty > 1 then return nil end
  return tx, ty
end

-- Where a guildmate is on the minimap, as a share of its radius (east, north; 1 = the edge), or
-- nil when off the minimap or not on your map.
function map.minimapOffset(mine, other, facing, zoom, indoors)
  local ox, oy = map.translate(other.mapId, other.x, other.y, mine.mapId)
  if not ox then return nil end
  if not C_Map then return nil end
  local width, height
  if C_Map.GetMapWorldSize then
    local ok, w, h = pcall(C_Map.GetMapWorldSize, mine.mapId)
    if ok and type(w) == "number" and type(h) == "number" and w > 0 and h > 0 then width, height = w, h end
  end
  if not width and C_Map.GetWorldPosFromMapPos and CreateVector2D then
    local function worldPosition(x, y)
      local ok, continent, position = pcall(C_Map.GetWorldPosFromMapPos, mine.mapId, CreateVector2D(x, y))
      if not ok or not continent or not position then return nil end
      local okXY, worldX, worldY = pcall(function() return position:GetXY() end)
      if not okXY or type(worldX) ~= "number" or type(worldY) ~= "number" then return nil end
      return continent, worldX, worldY
    end
    -- World axes are not map east/north (Classic swaps and reverses them).
    -- Measure the map's horizontal and vertical edges, then use map deltas.
    local c0, x0, y0 = worldPosition(0, 0)
    local cx, xx, yx = worldPosition(1, 0)
    local cy, xy, yy = worldPosition(0, 1)
    if c0 and c0 == cx and c0 == cy then
      width = math.sqrt((xx - x0)^2 + (yx - y0)^2)
      height = math.sqrt((xy - x0)^2 + (yy - y0)^2)
    end
  end
  if not width or not height or width <= 0 or height <= 0 then return nil end
  local east, north = (ox - mine.x) * width, -(oy - mine.y) * height
  if facing then
    -- Rotating minimap: the way you face is up.
    local c, s = math.cos(facing), math.sin(facing)
    east, north = east * c + north * s, -east * s + north * c
  end
  local radius = ((indoors and MINIMAP_INDOOR or MINIMAP_OUTDOOR)[zoom or 0] or MINIMAP_OUTDOOR[0]) / 2
  east, north = east / radius, north / radius
  if east * east + north * north > 1 then return nil end
  return east, north
end

-- ---------------------------------------------------------------------
-- Messages: P|mapId|x|y|class|level (x and y in 1/10000) and G (gone)
-- ---------------------------------------------------------------------

local lastSent = { at = -1000 }
local lastRequest, lastReply = -1000, -1000

local function send(text)
  if not (IsInGuild and IsInGuild()) then return false end
  return ns.comm.send(PREFIX, text, "GUILD")
end

local function sayGone()
  if lastSent.mapId then send("G") end
  lastSent = { at = clock() }
end

-- Called every second: send when you moved (at most every 5 s) or every 30 s.
function map.tick()
  lastTickAt = clock()
  if not active() then return end
  local s = settings()
  if not s or not s.mapShare or (ns.compat and ns.compat.inCombat()) then return end
  local mapId, x, y = map.myPosition()
  if not mapId then sayGone(); return end
  pcall(map.remember, mapId, x, y)
  local now = clock()
  local moved = lastSent.mapId ~= mapId or math.abs(x - (lastSent.x or 0)) > MOVE_THRESHOLD or math.abs(y - (lastSent.y or 0)) > MOVE_THRESHOLD
  local wait = moved and SEND_MOVING_SECONDS or SEND_IDLE_SECONDS
  if now - lastSent.at < wait then return end
  local class
  if UnitClass then class = select(2, UnitClass("player")) end
  local level = UnitLevel and UnitLevel("player") or 0
  if send(string.format("P|%d|%d|%d|%s|%d", mapId, math.floor(x * 10000 + 0.5), math.floor(y * 10000 + 0.5), tostring(class or ""), tonumber(level) or 0)) then
    lastSent = { at = now, mapId = mapId, x = x, y = y }
    lastPositionQueuedAt = now
  end
end

function map.requestPositions()
  if not active() or clock() - lastRequest < 10 then return end
  lastRequest = clock()
  send("Q")
  lastSent.at = -1000
  map.tick()
end

function map.receive(text, sender)
  if not active() then return "module off" end
  local name = ns.normalizeName and ns.normalizeName(sender)
  if not name then return "sender unavailable" end
  if name == (ns.playerName and ns.playerName()) then return "self" end
  if type(text) ~= "string" then return "invalid payload" end
  if text == "Q" then
    if clock() - lastReply >= 10 then
      lastReply = clock()
      lastSent.at = -1000
      map.tick()
    end
    return "request"
  end
  if text == "G" then map.members[name] = nil; map.refresh(); return "gone" end
  local mapId, x, y, class, level = string.match(text, "^P|(%d+)|(%d+)|(%d+)|(%u*)|(%d+)")
  if not mapId then return "invalid payload" end
  x, y = tonumber(x) / 10000, tonumber(y) / 10000
  if x > 1 or y > 1 then return "invalid coordinates" end
  map.members[name] = { mapId = tonumber(mapId), x = x, y = y, class = class ~= "" and class or nil, level = tonumber(level), at = clock() }
  return "position"
end

local function forgetOld()
  local now = clock()
  for name, member in pairs(map.members) do
    if now - member.at > EXPIRE_SECONDS then map.members[name] = nil end
  end
end

-- ---------------------------------------------------------------------
-- Dots
-- ---------------------------------------------------------------------

local function zoneName(mapId)
  if C_Map and C_Map.GetMapInfo then
    local ok, info = pcall(C_Map.GetMapInfo, mapId)
    if ok and info and type(info.name) == "string" and not secret(info.name) then return info.name end
  end
  return "?"
end

-- The continent a zone map sits on (walking up its parent maps), and its name; nil when unknown.
function map.continentOf(mapId)
  if not (C_Map and C_Map.GetMapInfo) then return nil end
  local current, steps = mapId, 0
  local continentType = (Enum and Enum.UIMapType and Enum.UIMapType.Continent) or CONTINENT_MAP_TYPE
  while type(current) == "number" and current > 0 and steps < 8 do
    local ok, info = pcall(C_Map.GetMapInfo, current)
    if not ok or type(info) ~= "table" then return nil end
    if info.mapType == continentType then
      local name = type(info.name) == "string" and not secret(info.name) and info.name or nil
      return current, name
    end
    current, steps = info.parentMapID, steps + 1
  end
  return nil
end

local function round4(value) return math.floor(value * 10000 + 0.5) / 10000 end
local function serverTime()
  if GetServerTime then
    local ok, value = pcall(GetServerTime)
    if ok and type(value) == "number" then return value end
  end
  return time()
end

-- Saves where this character is (at most every 30 s) for the companion to upload; returns the row.
function map.remember(mapId, x, y, force)
  local db = ns.getDb and ns.getDb()
  local name = ns.playerName and ns.playerName()
  if type(db) ~= "table" or type(name) ~= "string" or name == "" or type(mapId) ~= "number" then return nil end
  local now = clock()
  if not force and now - lastSavedAt < SAVE_SECONDS then return nil end
  lastSavedAt = now
  local row = { m = mapId, z = zoneName(mapId), x = round4(x), y = round4(y), at = serverTime() }
  local continent, continentName = map.continentOf(mapId)
  if continent then
    local cx, cy = map.translate(mapId, x, y, continent)
    if cx and cy then row.c, row.cn, row.cx, row.cy = continent, continentName, round4(cx), round4(cy) end
  end
  db.mapSeen = type(db.mapSeen) == "table" and db.mapSeen or {}
  db.mapSeen[name] = row
  if force or now - lastTrailAt >= TRAIL_SECONDS then
    lastTrailAt = now
    local kept, oldest = {}, row.at - TRAIL_KEEP_SECONDS
    for _, point in ipairs(type(db.mapTrail) == "table" and db.mapTrail or {}) do
      if type(point) == "table" and (tonumber(point.at) or 0) >= oldest then kept[#kept + 1] = point end
    end
    kept[#kept + 1] = { n = name, m = row.m, z = row.z, x = row.x, y = row.y, c = row.c, cn = row.cn, cx = row.cx, cy = row.cy, at = row.at }
    while #kept > TRAIL_MAX do table.remove(kept, 1) end
    db.mapTrail = kept
  end
  return row
end

local function classColor(class)
  local colors = (CUSTOM_CLASS_COLORS or RAID_CLASS_COLORS)
  local c = class and colors and colors[class]
  if c then return c.r, c.g, c.b end
  return 0.2, 1, 0.2
end

local function newPin(parent, pool, index)
  local pin = pool[index]
  if pin then return pin end
  pin = CreateFrame("Frame", nil, parent)
  if pin.SetFrameLevel and parent.GetFrameLevel then
    local level = parent:GetFrameLevel()
    if type(level) == "number" then pin:SetFrameLevel(level + 20) end
  end
  pin:SetWidth(14)
  pin:SetHeight(14)
  pin.icon = pin:CreateTexture(nil, "OVERLAY")
  pin.icon:SetAllPoints(pin)
  pin.icon:SetTexture(PIN_TEXTURE)
  if pin.EnableMouse then pin:EnableMouse(true) end
  pin:SetScript("OnEnter", function(self)
    if not (GameTooltip and self.name) then return end
    GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
    local member = map.members[self.name]
    GameTooltip:AddLine(ns.displayName(self.name), classColor(member and member.class))
    if member then
      GameTooltip:AddLine(string.format(L("Level %d, %s"), member.level or 0, zoneName(member.mapId)), 1, 1, 1)
    end
    GameTooltip:Show()
  end)
  pin:SetScript("OnLeave", function() if GameTooltip then GameTooltip:Hide() end end)
  pool[index] = pin
  return pin
end

local function hideFrom(pool, index)
  for i = index, #pool do pool[i]:Hide() end
end

local function sortedNames()
  local names = {}
  for name in pairs(map.members) do table.insert(names, name) end
  table.sort(names)
  return names
end

-- Inside a dungeon, raid, battleground or arena the game hides positions: no dots at all there.
function map.inInstance()
  if not IsInInstance then return false end
  local ok, inside = pcall(IsInInstance)
  return ok and inside == true
end

local function showDots()
  local s = settings()
  return active() and s and s.mapShow and not map.inInstance()
end

-- World map: a dot for everyone on the map being viewed (a zone, or its continent).
--
-- Taint (9 November 2026, ADDON_ACTION_BLOCKED "Button:SetPassThroughButtons()" in bursts after
-- duels): the world map's own pins call that function, which the game refuses in combat once the
-- map's execution is tainted. Guilded used to open the map itself (/guilded map open, Alt-click,
-- the quick menu), hook WorldMapFrame.OnMapChanged and parent its dots to the map canvas; the
-- first two run Blizzard's map code from addon code, so the pin pools and map fields it creates
-- stay tainted for the session. Now Guilded never opens, hooks or calls into the world map: the
-- dots live on our own overlay (a child of UIParent, clipped to the map's scroll area) and are
-- anchored to the canvas; OnUpdate notices the map opening, changing or zooming by reading it.
local function number(object, method)
  if type(object) ~= "table" or type(object[method]) ~= "function" then return nil end
  local ok, value = pcall(object[method], object)
  if ok and type(value) == "number" and not secret(value) then return value end
  return nil
end

local STRATA_RANK = { BACKGROUND = 1, LOW = 2, MEDIUM = 3, HIGH = 4, DIALOG = 5, FULLSCREEN = 6, FULLSCREEN_DIALOG = 7, TOOLTIP = 8 }
local OVERLAY_FRAME_LEVEL = 9000

local function worldOverlay(container)
  if not map.worldOverlay then
    local overlay = CreateFrame("Frame", nil, UIParent)
    if overlay.SetClipsChildren then pcall(overlay.SetClipsChildren, overlay, true) end
    if overlay.EnableMouse then overlay:EnableMouse(false) end
    map.worldOverlay = overlay
  end
  local overlay = map.worldOverlay
  if container and overlay.anchoredTo ~= container then
    overlay:ClearAllPoints()
    overlay:SetAllPoints(container)
    overlay.anchoredTo = container
  end
  return overlay
end

local function worldMapShown()
  local frame = WorldMapFrame
  if type(frame) ~= "table" or type(frame.IsShown) ~= "function" then return false end
  local ok, shown = pcall(frame.IsShown, frame)
  return ok and shown == true
end

function map.refreshWorldMap()
  local frame = WorldMapFrame
  local container = type(frame) == "table" and frame.ScrollContainer
  local canvas = type(container) == "table" and container.Child
  local used = 0
  if canvas and worldMapShown() and showDots() then
    local overlay = worldOverlay(container)
    -- Above everything the map draws: its own pins and the explored-area art sit at frame levels in
    -- the thousands, so "map level + 1000" left the dots underneath (10 November 2026: dots on the
    -- minimap but not on the world map). At least HIGH, as the dots were before the overlay.
    if overlay.SetFrameStrata then
      local strata = "HIGH"
      if type(frame.GetFrameStrata) == "function" then
        local ok, value = pcall(frame.GetFrameStrata, frame)
        if ok and type(value) == "string" and (STRATA_RANK[value] or 0) > STRATA_RANK.HIGH then strata = value end
      end
      overlay:SetFrameStrata(strata)
    end
    if overlay.SetFrameLevel then overlay:SetFrameLevel(OVERLAY_FRAME_LEVEL) end
    local viewed = number(frame, "GetMapID")
    local width, height = number(canvas, "GetWidth") or 0, number(canvas, "GetHeight") or 0
    local names = viewed and width > 0 and height > 0 and sortedNames() or {}
    for _, name in ipairs(names) do
      local member = map.members[name]
      local x, y = map.translate(member.mapId, member.x, member.y, viewed)
      if x then
        used = used + 1
        local pin = newPin(overlay, map.worldPins, used)
        pin.name = name
        -- Offsets are in the dot's own units: canvas units times (canvas scale / dot scale).
        local ratio = (number(canvas, "GetEffectiveScale") or 1) / (number(pin, "GetEffectiveScale") or 1)
        pin.icon:SetVertexColor(classColor(member.class))
        pin:ClearAllPoints()
        pin:SetPoint("CENTER", canvas, "TOPLEFT", x * width * ratio, -y * height * ratio)
        pin:Show()
      end
    end
    overlay:Show()
  elseif map.worldOverlay then
    map.worldOverlay:Hide()
  end
  hideFrom(map.worldPins, used + 1)
end

-- What the world map shows right now (open, map, zoom); OnUpdate redraws the dots when it changes.
local lastWorldMap = {}
function map.worldMapChanged()
  local shown = worldMapShown()
  local frame, mapId, scale = WorldMapFrame, nil, nil
  if shown then
    mapId = number(frame, "GetMapID")
    local canvas = type(frame.ScrollContainer) == "table" and frame.ScrollContainer.Child
    scale = canvas and number(canvas, "GetEffectiveScale") or nil
  end
  if shown == lastWorldMap.shown and mapId == lastWorldMap.mapId and scale == lastWorldMap.scale then return false end
  lastWorldMap.shown, lastWorldMap.mapId, lastWorldMap.scale = shown, mapId, scale
  return true
end

-- Minimap: a dot for everyone close enough to fit on it.
function map.refreshMinimap()
  if not Minimap then return end
  local used = 0
  if showDots() and next(map.members) then
    local mapId, x, y = map.myPosition()
    if mapId then
      local facing
      if GetCVar and GetCVar("rotateMinimap") == "1" and GetPlayerFacing then
        local ok, value = pcall(GetPlayerFacing)
        if ok and type(value) == "number" and not secret(value) then facing = value end
      end
      local zoom = Minimap.GetZoom and Minimap:GetZoom() or 0
      local indoors = IsIndoors and IsIndoors() or false
      local halfWidth, halfHeight = Minimap:GetWidth() / 2, Minimap:GetHeight() / 2
      for _, name in ipairs(sortedNames()) do
        local east, north = map.minimapOffset({ mapId = mapId, x = x, y = y }, map.members[name], facing, zoom, indoors)
        if east then
          used = used + 1
          local pin = newPin(Minimap, map.minimapPins, used)
          pin.name = name
          pin.icon:SetVertexColor(classColor(map.members[name].class))
          pin:ClearAllPoints()
          pin:SetPoint("CENTER", Minimap, "CENTER", east * halfWidth, north * halfHeight)
          pin:Show()
        end
      end
    end
  end
  hideFrom(map.minimapPins, used + 1)
end

function map.refresh()
  pcall(map.refreshWorldMap)
  pcall(map.refreshMinimap)
end

-- ---------------------------------------------------------------------
-- Commands
-- ---------------------------------------------------------------------

function map.listText()
  forgetOld()
  local lines = {}
  for _, name in ipairs(sortedNames()) do
    local member = map.members[name]
    table.insert(lines, string.format("%s (%d): %s", ns.displayName(name), member.level or 0, zoneName(member.mapId)))
  end
  return #lines > 0 and table.concat(lines, "\n") or L("No guildmate is sharing a position right now.")
end

function map.statusText()
  local s = settings() or {}
  local mapId = map.myPosition()
  local count = 0
  forgetOld()
  for _ in pairs(map.members) do count = count + 1 end
  local prefixStatus = "unknown"
  local prefixCheck = C_ChatInfo and C_ChatInfo.IsAddonMessagePrefixRegistered or IsAddonMessagePrefixRegistered
  if type(prefixCheck) == "function" then
    local ok, registered = pcall(prefixCheck, PREFIX)
    if ok and not secret(registered) and type(registered) == "boolean" then prefixStatus = registered and "registered" or "not registered" end
  end
  local transport = ns.comm.status and ns.comm.status(PREFIX) or {}
  local function age(at)
    return at and string.format(L("%ds ago"), math.max(0, math.floor(clock() - at))) or L("never")
  end
  local inGuild = IsInGuild and IsInGuild()
  local combat = ns.compat and ns.compat.inCombat and ns.compat.inCombat()
  local lines = {
    string.format(L("Guild map: module %s, sharing %s, dots %s, peers %d."),
      active() and L("on") or L("off"), s.mapShare and L("on") or L("off"), s.mapShow and L("on") or L("off"), count),
    mapId and string.format(L("Your map: %s (%d)."), zoneName(mapId), mapId) or L("Your position is unavailable here (instances or unsupported map API)."),
    string.format(L("Map diagnostics 2: guild %s, combat %s, prefix %s."),
      inGuild and L("yes") or L("no"), combat and L("on") or L("off"), L(prefixStatus)),
    string.format(L("Position queued: %s; last tick: %s."), age(lastPositionQueuedAt), age(lastTickAt)),
    string.format(L("Client send results: accepted %d, refused %d, errors %d, throttled %d, queued %d; last %s, code %s."),
      transport.sent or 0, transport.refused or 0, transport.errors or 0, transport.throttled or 0, transport.queued or 0,
      L(transport.lastResult or "none"), tostring(transport.lastCode or "-")),
    string.format(L("Incoming map messages: %d, positions %d, ignored %d; last %s."),
      received.messages, received.positions, received.ignored, L(received.last)),
    L("Counts are since /reload. Client acceptance does not confirm delivery to another player."),
    L("Both players need Guilded and map sharing enabled. Minimap dots show nearby players only.")
  }
  if not active() or not s.mapShow then
    table.insert(lines, L("Use /guilded modules on guildmap and /guilded map show on."))
  end
  return table.concat(lines, "\n")
end

-- The key bound to the world map ("M" by default), for the hint above.
function map.mapKey()
  if GetBindingKey then
    local ok, key = pcall(GetBindingKey, "TOGGLEWORLDMAP")
    if ok and type(key) == "string" and key ~= "" and not secret(key) then return key end
  end
  return "M"
end

ns.commandHandlers = ns.commandHandlers or {}
ns.commandHandlers["map"] = function(args)
  local s = settings()
  if not s then return end
  local what, value = string.lower(args[1] or ""), string.lower(args[2] or "")
  if what == "check" then
    for line in string.gmatch(map.statusText(), "[^\n]+") do ns.message(line) end
    return
  end
  if what == "open" then
    -- Never open the world map from addon code: that runs the map's own code tainted, and its pins
    -- are then blocked in combat for the rest of the session (see refreshWorldMap). Say which key does.
    if not worldMapShown() then ns.message(string.format(L("Open your world map (%s) to see guildmates."), map.mapKey())) end
    map.requestPositions()
    map.refresh()
    return
  end
  if what == "show" and (value == "on" or value == "off") then
    do
      s.mapShow = value == "on"
      if s.mapShow then map.requestPositions() end
      map.refresh()
      ns.message(s.mapShow and L("Guildmates show on your maps.") or L("Guildmates are hidden from your maps."))
    end
    return
  end
  map.requestPositions()
  ns.message(string.format(L("Guild map: your position is always shared, dots %s. /guilded map show on|off"),
    s.mapShow and L("on") or L("off")))
  for line in string.gmatch(map.listText(), "[^\n]+") do ns.message("  " .. line) end
end
ns.commandHelp = ns.commandHelp or {}
table.insert(ns.commandHelp, "/guilded map - guildmates on your world map and minimap (show on|off; your position is always shared)")

-- ---------------------------------------------------------------------
-- Events and timers
-- ---------------------------------------------------------------------

local frame = CreateFrame("Frame")
local function register(event)
  if ns.compat and ns.compat.registerEvent then ns.compat.registerEvent(frame, event)
  else pcall(frame.RegisterEvent, frame, event) end
end
register("PLAYER_LOGIN")
register("CHAT_MSG_ADDON")
register("PLAYER_ENTERING_WORLD")

local sinceTick, sinceMinimap = 0, 0
local function onUpdate(_, elapsed)
  sinceTick = sinceTick + (elapsed or 0)
  sinceMinimap = sinceMinimap + (elapsed or 0)
  if sinceTick >= TICK_SECONDS then
    sinceTick = 0
    local ok, err = pcall(function()
      map.tick()
      forgetOld()
      map.refreshWorldMap()
    end)
    if not ok and ns.logDiagnostic then ns.logDiagnostic("LUA_ERROR", "guild map: " .. tostring(err)) end
  elseif map.worldMapChanged() then
    -- The map opened, closed, changed or zoomed: redraw at once (no hook into WorldMapFrame).
    pcall(map.refreshWorldMap)
  end
  if sinceMinimap >= MINIMAP_REFRESH_SECONDS then
    sinceMinimap = 0
    pcall(map.refreshMinimap)
  end
end

frame:SetScript("OnEvent", function(_, event, ...)
  local args = { ... }
  local ok, err = pcall(function()
    if event == "PLAYER_LOGIN" then
      ns.comm.register(PREFIX)
      -- No hooksecurefunc/HookScript on WorldMapFrame: OnUpdate notices map changes instead.
      frame:SetScript("OnUpdate", onUpdate)
    elseif event == "PLAYER_ENTERING_WORLD" then
      -- Zoning in or out of an instance: send (or clear) the position soon.
      lastSent.at = -1000
      -- Pins vanish at once inside an instance and come back when you leave it.
      map.refresh()
      map.requestPositions()
    elseif event == "CHAT_MSG_ADDON" then
      local prefix, text, channel, sender = args[1], args[2], args[3], args[4]
      if secret(prefix) or prefix ~= PREFIX then return end
      received.messages = received.messages + 1
      local result
      if secret(text) or secret(sender) or secret(channel) then result = "restricted message"
      elseif channel ~= "GUILD" then result = "other channel"
      elseif not ns.comm.accept(prefix, text, channel, sender, PREFIX) then result = "invalid payload"
      else result = map.receive(text, sender) end
      received.last = result or "invalid payload"
      if result == "position" then received.positions = received.positions + 1
      elseif result ~= "request" and result ~= "gone" then received.ignored = received.ignored + 1 end
    end
  end)
  if not ok and ns.logDiagnostic then ns.logDiagnostic("LUA_ERROR", "guild map: " .. tostring(err)) end
end)
