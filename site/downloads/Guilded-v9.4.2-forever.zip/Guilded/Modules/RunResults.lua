local addonName, ns = ...
local results = {}
ns.runResults = results
local window
local pending
local loading, settle, poll = false, 0, 0

local function active() return not ns.moduleActive or ns.moduleActive("dungeon") end
local function dungeonDb()
  local root = ns.getDb and ns.getDb()
  return root and root.dungeon
end

-- Where the member left the card, like the duel card (settings.runCardPos); `/guilded cards reset` puts both cards back.
local function settings() return ns.getSettings and ns.getSettings() or nil end
function results.savePosition(frame)
  local st = settings()
  if not (st and frame and frame.GetPoint) then return end
  local ok, point, relativeTo, relPoint, x, y = pcall(frame.GetPoint, frame)
  -- Only a place measured from the screen is saved (a drag always leaves the card anchored to UIParent).
  if relativeTo and relativeTo ~= UIParent then return end
  if ok and type(point) == "string" and tonumber(x) and tonumber(y) then st.runCardPos = { point = point, relPoint = relPoint or point, x = x, y = y } end
end
function results.restorePosition(frame)
  local st = settings()
  local pos = st and st.runCardPos
  frame:ClearAllPoints()
  if type(pos) == "table" and type(pos.point) == "string" and tonumber(pos.x) and tonumber(pos.y) then
    -- A hand-edited point name must not break showing the card: the usual place is the fallback.
    local ok = pcall(frame.SetPoint, frame, pos.point, UIParent, type(pos.relPoint) == "string" and pos.relPoint or pos.point, pos.x, pos.y)
    if ok then return end
    frame:ClearAllPoints()
  end
  frame:SetPoint("BOTTOMRIGHT", UIParent, "BOTTOMRIGHT", -110, 150) -- clear of the right action bars
end

local function inCombat()
  return (InCombatLockdown and InCombatLockdown()) or (UnitAffectingCombat and UnitAffectingCombat("player"))
end

local function L(text) return ns.L and ns.L(text) or text end
local function displayName(name) return ns.displayName and ns.displayName(name) or name end

function results.timerEnabled()
  local db = ns.getDb and ns.getDb()
  return db and db.settings and db.settings.hideBossTimer == false or false
end

function results.setTimerEnabled(enabled)
  local db = ns.getDb and ns.getDb()
  if not db then return end
  db.settings = db.settings or {}
  db.settings.hideBossTimer = not enabled
end

local function clock(seconds)
  seconds = math.max(0, math.floor(seconds))
  return string.format("%d:%02d", math.floor(seconds / 60), seconds % 60)
end

function results.liveText(run, stamp)
  local boss = run and run.activeEncounter
  if not run or run.state ~= "ACTIVE" or not run.inside or not boss
    or type(boss.startedAt) ~= "number" or stamp < boss.startedAt then return nil end
  return string.format(L("Boss fight: %s - %s"), boss.name or (L("Boss") .. " #" .. tostring(boss.id or "?")),
    clock(stamp - boss.startedAt))
end

function results.fightText(run)
  local lines = {}
  for _, boss in ipairs(run.encounters or {}) do
    local timed = type(boss.startedAt) == "number" and type(boss.at) == "number"
      and boss.at >= boss.startedAt and (not run.startedAt or boss.startedAt >= run.startedAt)
      and (not run.endedAt or boss.at <= run.endedAt)
    lines[#lines + 1] = string.format("%s - %s - %s",
      boss.name or (L("Boss") .. " #" .. tostring(boss.id or "?")),
      boss.success and L("Defeated") or L("Failed attempt"),
      timed and clock(boss.at - boss.startedAt) or L("Fight not timed"))
  end
  return #lines > 0 and (L("Boss fight times") .. "\n" .. table.concat(lines, "\n")) or ""
end

local function rosterText(run)
  local names, lines = {}, {}
  for name in pairs(run.players or {}) do names[#names + 1] = name end
  table.sort(names)
  local roles = { TANK = L("Tank"), HEALER = L("Healer"), DPS = "DPS", DAMAGER = "DPS" }
  for _, name in ipairs(names) do
    local player = run.players[name]
    local info = player.class or ""
    if roles[player.role] then info = info .. (info ~= "" and " / " or "") .. roles[player.role] end
    local deaths = type(player.deaths) == "number" and string.format(L("%d deaths"), player.deaths) or L("deaths unknown")
    lines[#lines + 1] = "|cffffd36a" .. displayName(name) .. "|r" .. (info ~= "" and ("  |cffb0b8c4" .. info .. "|r") or "") .. "\n  " .. deaths
  end
  return table.concat(lines, "\n\n"), #names
end

function results.syncText(run)
  -- 9.0.8: the bot says why a run it received earned nothing ("Not completed", a guildmate's copy, ...).
  if run.synced and type(run.syncNote) == "string" and run.syncNote ~= "" then
    return string.format(L("Received by Discord. Not scored: %s"), L(run.syncNote))
  end
  if not run.synced and run.groupSentAt then return L("Sent to a group member's companion, not confirmed yet.") end
  return run.synced and L("Companion receipt recorded. Check the website or guild Season for validation and visibility.")
    or L("Saved in game. Type /reload or log out, then let your paired companion sync. Upload and public listing are not confirmed here.")
end

-- Public provisional plan of 18 October 2026, NOT guild-season points or an acceptance receipt.
-- Tests compare every route and rounding boundary with publicRules()/scoreRun() on the server.
-- Fields: target seconds, minimum level, maximum level. Observed difficulty is 0.
local targets = {
  ["389"]={1200,15,18}, ["3065"]={1500,15,20}, ["43"]={2400,15,24},
  ["2999"]={2100,15,22}, ["36"]={2400,17,26}, ["33"]={1800,20,29},
  ["34"]={1200,24,29}, ["48"]={2400,24,29}, ["2998"]={2100,26,29},
  ["189:graveyard"]={900,26,29}, ["2959"]={2700,30,36}, ["90"]={2700,30,38},
  ["47"]={2100,30,38}, ["189:library"]={1500,30,36}, ["189:armory"]={1500,32,42},
  ["189:cathedral"]={1500,35,44}, ["129"]={2400,35,44}, ["70"]={3000,38,44}
}
local wings = {
  graveyard={"bloodmage thalnos","mage de sang thalnos"}, library={"arcanist doan","arcaniste doan"},
  armory={"herod","h\195\169rode"}, cathedral={"high inquisitor whitemane","grande inquisitrice blanchet\195\170te"}
}
function results.routeKey(run)
  if run.instanceId ~= 189 then return tostring(run.instanceId) end
  local found
  for wing, names in pairs(wings) do
    for _, boss in ipairs(run.encounters or {}) do
      if boss.success and type(boss.name) == "string" then
        for _, name in ipairs(names) do
          if string.lower(boss.name) == name then
            if found and found ~= wing then return nil end
            found = wing
          end
        end
      end
    end
  end
  return found and ("189:" .. found) or nil
end
-- Scarlet Monastery is one map for four wings: name the wing (from the last boss killed) so the card says which one was run.
function results.displayName(run)
  local name = run and run.name
  if type(name) ~= "string" or run.instanceId ~= 189 then return name end
  local lower = string.lower(name)
  if string.find(lower, "graveyard") or string.find(lower, "library") or string.find(lower, "armory") or string.find(lower, "cathedral")
    or string.find(lower, "biblioth") or string.find(lower, "armurerie") or string.find(lower, "cath") then return name end
  local key = results.routeKey(run)
  local wing = key and string.sub(key, 5)
  local label = wing == "graveyard" and L("Graveyard") or wing == "library" and L("Library") or wing == "armory" and L("Armory")
    or wing == "cathedral" and L("Cathedral") or nil
  return label and (name .. ": " .. label) or name
end
function results.estimate(run)
  local key = results.routeKey(run)
  local route = targets[key]
  local model = { key = key }
  if run.state ~= "COMPLETED" or type(run.durationSec) ~= "number" or run.durationSec <= 0 then
    model.reason = L("Run not completed")
  elseif (run.gameEdition and run.gameEdition ~= "forever") or (ns.util and not ns.util.isForever()) then model.reason = L("Only WoW Forever runs are scored")
  elseif run.completedBy ~= "final boss" then model.reason = L("Automatic final-boss evidence required")
  elseif not route then model.reason = L("No public target for this route")
  elseif run.difficultyId ~= 0 then model.reason = L("Different difficulty from the public rules")
  else
    local count, low, high = 0, 100, 0
    for _, player in pairs(run.players or {}) do
      local level = player.level
      if type(level) ~= "number" or level % 1 ~= 0 or level < 1 or level > 100 then
        model.reason = L("Party levels missing"); return model
      end
      count = count + 1; low = math.min(low, level); high = math.max(high, level)
    end
    model.target, model.minLevel, model.maxLevel = route[1], route[2], route[3]
    if count == 0 then model.reason = L("Party levels missing")
    elseif low < route[2] - 3 or high > route[3] + 6 then model.reason = L("Party levels outside the public range")
    else
      model.penalty = math.max(0, high - route[3]) * 10
      model.base = math.max(50, math.min(400, math.floor(200 * route[1] / run.durationSec + 0.5)))
      model.points = math.floor(model.base * (100 - model.penalty) / 100 + 0.5)
    end
  end
  return model
end

function results.breakdown(run)
  local score = results.estimate(run)
  if not score.points then return score.reason end
  return string.format(L("Target %s / time %s\nTime rating %d (50-400) / level penalty %d%%\nProvisional public estimate; guild rules may differ."),
    clock(score.target), clock(run.durationSec), score.base, score.penalty)
end

local function forgetPending(run)
  local d = dungeonDb()
  if d and run and d.pendingResult == run.id then d.pendingResult = nil end
end
function results.dismiss()
  local run = results.last
  if run then run.resultCardDismissed = true; forgetPending(run) end
  pending = nil
  if window then window:Hide() end
end

-- Test cleanup must clear queued and visible results, not just the saved run.
function results.remove(runId)
  if results.simCards then results.simCards[runId] = nil end
  if pending and pending.run and pending.run.id == runId then pending = nil end
  local d = dungeonDb()
  if d and d.pendingResult == runId then d.pendingResult = nil end
  if results.last and results.last.id == runId then
    results.last = nil
    if window then window:Hide() end
  end
end

function results.text(run)
  local seconds = math.max(0, math.floor(run.durationSec or 0))
  local lines = { (run.name or "Dungeon") .. " - " .. (run.state or "?"),
    string.format("Time: %d:%02d", math.floor(seconds / 60), seconds % 60) }
  local kills = 0
  for _, boss in ipairs(run.encounters or {}) do if boss.success then kills = kills + 1 end end
  lines[#lines + 1] = "Bosses defeated: " .. kills .. (run.bossCount and ("/" .. run.bossCount) or "")
  lines[#lines + 1] = results.fightText(run)
  local names = {}
  for name in pairs(run.players or {}) do names[#names + 1] = name end
  table.sort(names)
  lines[#lines + 1] = ""
  for _, name in ipairs(names) do
    local player = run.players[name]
    lines[#lines + 1] = displayName(name) .. ": " .. (type(player.deaths) == "number" and (player.deaths .. " deaths") or "deaths unknown")
  end
  lines[#lines + 1] = ""
  lines[#lines + 1] = results.syncText(run)
  return table.concat(lines, "\n")
end

-- Paints (or clears) the card backdrop for a dungeon name; returns the texture path used, or nil for the plain card.
function results.applyArt(name)
  local path = ns.dungeonArt and ns.dungeonArt.enabled() and ns.dungeonArt.path(name) or nil
  results.artPath = path
  if window and window.art then
    if path then window.art:SetTexture(path); window.art:Show() else window.art:Hide() end
  end
  return path
end

-- (9.3.5) The party table of the result card, the same columns as the Discord run card: level, guild, score gained by this run
-- and season total. The companion writes GuildedDungeonCards[runId] = { { n=, l=, g=, a=, t= }, ... } (at most five players) from the
-- bot's receipt; without that entry the card is exactly what it was before, and a field the bot did not know is left blank.
local CARD_PLAYERS, TABLE_HEIGHT, COLLAPSED, EXPANDED_EXTRA = 5, 96, 276, 174
results.simCards = {}
function results.cardRows(run)
  if type(run) ~= "table" or type(run.id) ~= "string" then return nil end
  local all = type(GuildedDungeonCards) == "table" and GuildedDungeonCards or nil
  local rows = all and all[run.id]
  if type(rows) ~= "table" and run.test then rows = results.simCards[run.id] end
  if type(rows) ~= "table" then return nil end
  local out = {}
  for _, row in ipairs(rows) do
    if type(row) == "table" and type(row.n) == "string" and row.n ~= "" then out[#out + 1] = row end
    if #out >= CARD_PLAYERS then break end
  end
  return #out > 0 and out or nil
end

local function plain(text) return (string.gsub(tostring(text), "|", "")) end
-- The five cells of one player's row (text only, so it can be checked without a frame).
function results.cardCells(row)
  local level, gain, total = tonumber(row.l), tonumber(row.a), tonumber(row.t)
  local gainText = ""
  if gain and total then
    gainText = gain > 0 and ("|cff66d98f+" .. math.floor(gain) .. "|r") or "|cff8a929e+0|r"
  end
  return {
    "|cffffd36a" .. plain(displayName(row.n)) .. "|r",
    level and tostring(math.floor(level)) or "",
    type(row.g) == "string" and plain(row.g) or "",
    gainText,
    (gain and total) and tostring(math.floor(total)) or ""
  }
end
function results.cardHeader()
  return { "", L("Lv"), L("Guild"), L("This run"), L("Season") }
end

local COLUMNS = { { 14, 104, "LEFT" }, { 118, 24, "RIGHT" }, { 150, 84, "LEFT" }, { 238, 46, "RIGHT" }, { 288, 52, "RIGHT" } }
local shownRows
local cellLabels = {} -- kept here, not on the frame: the labels belong to this module
local function drawTable(frame, rows)
  for line = 0, CARD_PLAYERS do
    cellLabels[line] = cellLabels[line] or {}
    local cells = rows and (line == 0 and results.cardHeader() or (rows[line] and results.cardCells(rows[line]))) or nil
    for column, spec in ipairs(COLUMNS) do
      local label = cellLabels[line][column]
      if cells and not label then
        label = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        label:SetPoint("TOPLEFT", spec[1], -166 - line * 14); label:SetWidth(spec[2]); label:SetJustifyH(spec[3])
        if label.SetWordWrap then label:SetWordWrap(false) end
        cellLabels[line][column] = label
      end
      if label then
        if cells then
          label:SetText(cells[column]); label:Show()
          if line == 0 then label:SetTextColor(0.65, 0.7, 0.76) end
        else
          label:SetText(""); label:Hide()
        end
      end
    end
  end
end
local function baseHeight(rows) return rows and (COLLAPSED + TABLE_HEIGHT) or COLLAPSED end

-- Test run for /guilded sim dungeon: sample rows (test names) so the table can be previewed with /gdg results. Never real data.
function results.simCard(runId)
  results.simCards[runId] = {
    { n = "Tester One", l = 24, g = "Sample Guild", a = 36, t = 412 }, { n = "Tester Two", l = 23, g = "Sample Guild", a = 0, t = 388 },
    { n = "Tester Three", l = 24, a = 12, t = 57 }, { n = "Tester Four", l = 22 }, { n = "Tester Five" }
  }
end

-- A card already on screen takes new data at once, or when combat ends (show() queues it then).
function results.refresh()
  if results.last and window and window.IsShown and window:IsShown() then results.show(results.last, true) end
end

-- Polled with the pending-result check: a card on screen without a table takes the companion's data once it is there. Never in combat
-- (the next poll tries again), and show() itself queues instead of drawing when combat starts.
function results.checkCards()
  if inCombat() or loading or not (window and window.IsShown and window:IsShown() and results.last) then return end
  if not shownRows and results.cardRows(results.last) then results.refresh() end
end

function results.show(run, resume)
  if not active() or type(run) ~= "table" then return end
  results.last = run
  if inCombat() or loading then pending = {run=run, resume=resume}; return end
  pending = nil
  if not UIParent or not CreateFrame then return end
  -- Saved with the run, so reloads and repeated zone/completion events cannot reopen it.
  run.resultCardShown = true
  forgetPending(run)
  if not window then
    window = CreateFrame("Frame", "GuildedRunResults", UIParent, BackdropTemplateMixin and "BackdropTemplate" or nil)
    window:SetSize(354, 276)
    window:SetPoint("BOTTOMRIGHT", UIParent, "BOTTOMRIGHT", -110, 150)
    window:SetClampedToScreen(true)
    window:SetMovable(true); window:EnableMouse(true); window:RegisterForDrag("LeftButton")
    window:SetScript("OnDragStart", function(self) self:StartMoving() end)
    window:SetScript("OnDragStop", function(self) self:StopMovingOrSizing(); results.savePosition(self) end)
    if window.SetBackdrop then
      window:SetBackdrop({ bgFile = "Interface\\Tooltips\\UI-Tooltip-Background", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize = 12 })
      window:SetBackdropColor(0.035, 0.045, 0.065, 0.97)
      window:SetBackdropBorderColor(0.72, 0.54, 0.2, 1)
    end
    -- An opaque body: the tooltip background texture is see-through, and the quest tracker text showed through the lower half.
    window.solid = window:CreateTexture(nil, "BACKGROUND", nil, -8)
    window.solid:SetPoint("TOPLEFT", 3, -3); window.solid:SetPoint("BOTTOMRIGHT", -3, 3)
    if window.solid.SetColorTexture then window.solid:SetColorTexture(0.035, 0.045, 0.065, 1) end
    -- The dungeon's painting behind the header text (Media\Dungeons, 256x128, darkened and faded into the card colour).
    -- A plain texture: no frame, no protected call. Hidden when the dungeon has no painting or the setting is off.
    window.art = window:CreateTexture(nil, "BACKGROUND", nil, 1)
    window.art:SetPoint("TOPLEFT", window, "TOPLEFT", 5, -5); window.art:SetPoint("TOPRIGHT", window, "TOPRIGHT", -5, -5)
    window.art:SetHeight(172)
    window.heading = window:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    window.heading:SetPoint("TOPLEFT", 14, -18); window.heading:SetWidth(304); window.heading:SetJustifyH("LEFT")
    window.status = window:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    window.status:SetPoint("TOPLEFT", 14, -42)
    window.metrics = window:CreateFontString(nil, "OVERLAY", "GameFontNormalHuge")
    window.metrics:SetPoint("TOPLEFT", 14, -64); window.metrics:SetWidth(326); window.metrics:SetJustifyH("LEFT")
    window.caption = window:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    window.caption:SetPoint("TOPLEFT", 14, -94); window.caption:SetWidth(326); window.caption:SetJustifyH("LEFT")
    window.breakdown = window:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    window.breakdown:SetPoint("TOPLEFT", 14, -114); window.breakdown:SetWidth(326); window.breakdown:SetJustifyH("LEFT")
    window.scroll = CreateFrame("ScrollFrame", nil, window, "UIPanelScrollFrameTemplate")
    window.scroll:SetPoint("TOPLEFT", 14, -174); window.scroll:SetPoint("BOTTOMRIGHT", -30, 118)
    window.content = CreateFrame("Frame", nil, window.scroll)
    window.content:SetWidth(306)
    window.scroll:SetScrollChild(window.content)
    window.text = window.content:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    window.text:SetPoint("TOPLEFT", 0, 0); window.text:SetWidth(306); window.text:SetJustifyH("LEFT")
    window.footer = window:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    window.footer:SetPoint("BOTTOMLEFT", 14, 52); window.footer:SetWidth(326); window.footer:SetJustifyH("LEFT")
    window.footer:SetTextColor(0.65, 0.7, 0.76)
    window.close = CreateFrame("Button", nil, window, "UIPanelCloseButton")
    window.close:SetPoint("TOPRIGHT", 0, 0)
    window.close:SetScript("OnClick", results.dismiss)
    window.details = CreateFrame("Button", nil, window, "UIPanelButtonTemplate")
    window.details:SetSize(90, 22); window.details:SetPoint("BOTTOMLEFT", 14, 16)
    window.details:SetScript("OnClick", function()
      window.expanded = not window.expanded
      window:SetHeight((window.expanded and EXPANDED_EXTRA or 0) + baseHeight(shownRows))
      window.details:SetText(window.expanded and L("Less detail") or L("Details"))
      if window.expanded then window.scroll:Show() else window.scroll:Hide() end
      window.age = 0; window:SetAlpha(1)
    end)
    window.hint = window:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    window.hint:SetPoint("BOTTOMLEFT", 114, 17); window.hint:SetWidth(226); window.hint:SetJustifyH("LEFT")
    window:SetScript("OnUpdate", function(self, elapsed)
      if inCombat() then
        pending = {run=results.last,resume=true}; self:Hide(); return
      end
      local hovered = self.IsMouseOver and self:IsMouseOver() == true
        or MouseIsOver and MouseIsOver(self) == true
      -- Keep details open for reading. Hover pauses the clock and restores full opacity.
      if self.expanded or hovered then self:SetAlpha(1); return end
      self.age = (self.age or 0) + elapsed
      self:SetAlpha(math.max(0, math.min(1, (15 - self.age) / 2)))
      if self.age >= 15 then results.dismiss() end
    end)
  end
  local roster = rosterText(run)
  shownRows = results.cardRows(run)
  local seconds = math.max(0, math.floor(run.durationSec or 0))
  local kills = 0
  for _, boss in ipairs(run.encounters or {}) do if boss.success then kills = kills + 1 end end
  local shownName = results.displayName(run)
  results.applyArt(shownName)
  window.heading:SetText(shownName or L("Dungeon"))
  window.status:SetText((run.state == "COMPLETED" and L("RUN COMPLETE") or L("Run not completed"))
    .. "  |cffb0b8c4" .. L("Bosses") .. " " .. kills .. (run.bossCount and ("/" .. run.bossCount) or "") .. "|r")
  if run.state == "COMPLETED" then window.status:SetTextColor(0.4, 0.85, 0.6)
  else window.status:SetTextColor(0.9, 0.7, 0.35) end
  local score = results.estimate(run)
  window.metrics:SetText((score.points and ("~" .. score.points) or L("Unrated")) .. "   |cffffffff" .. clock(seconds) .. "|r")
  window.caption:SetText(L("Estimated public score / recorded duration"))
  window.breakdown:SetText(results.breakdown(run))
  local fights = results.fightText(run)
  window.text:SetText(fights ~= "" and (fights .. "\n\n" .. roster) or roster)
  window.content:SetHeight(math.max(1, window.text:GetStringHeight() + 12))
  window.scroll:SetVerticalScroll(0)
  window.footer:SetText(results.syncText(run))
  window.hint:SetText(L("Reopen: /gdg results")) -- short enough for one line (the long form was cut off)
  if not resume then
    window.age = 0; window.expanded = false
    window.details:SetText(L("Details")); window.scroll:Hide()
  end
  window:SetHeight((window.expanded and EXPANDED_EXTRA or 0) + baseHeight(shownRows))
  drawTable(window, shownRows)
  window.scroll:ClearAllPoints()
  window.scroll:SetPoint("TOPLEFT", 14, -174 - (shownRows and TABLE_HEIGHT or 0)); window.scroll:SetPoint("BOTTOMRIGHT", -30, 118)
  window:SetAlpha(1)
  results.restorePosition(window)
  -- Stacked above the duel card when both are on screen.
  if ns.util and ns.util.keepApart then ns.util.keepApart(window, _G.GuildedDuelCard) end
  window:Show()
end

function results.queue(run)
  if not active() or not run or run.state ~= "COMPLETED" or not run.id
    or run.resultCardShown or run.resultCardDismissed then return end
  local d = dungeonDb()
  if d then d.pendingResult = run.id end
  if ns.syncNow and ns.syncNow.noteResult then pcall(ns.syncNow.noteResult, "run") end
  settle = 1
end

local function insideDungeon()
  local instance = ns.compat and ns.compat.instance and ns.compat.instance()
  -- Avoid interrupting a new dungeon/raid if the player zones straight into another instance.
  return instance and (instance.type == "party" or instance.type == "raid")
end
function results.tryPending()
  if not active() then return end
  local d = dungeonDb()
  if not pending and not (d and d.pendingResult) then return end
  if loading or settle > 0 or inCombat() or insideDungeon() then return end
  if pending then results.show(pending.run, pending.resume); return end
  local run = d and d.runs and d.runs[d.pendingResult]
  -- SavedVariables may be shared with alts. Do not pop up another character's run.
  if run and ns.playerName and not (run.players or {})[ns.playerName()] then return end
  if run and run.state == "COMPLETED" and not run.resultCardShown and not run.resultCardDismissed then
    results.show(run)
  elseif d then d.pendingResult = nil end
end

-- Recheck after loading finishes, never at the last boss or during a new pull.
-- Pending IDs and shown/dismissed flags survive /reload in either addon's own SavedVariables.
if CreateFrame then
  local events = CreateFrame("Frame")
  -- Encounter timing stays active in Dungeon.lua. Never create a floating
  -- boss overlay; optional live text belongs only inside the opened Run tab.
  events:RegisterEvent("PLAYER_REGEN_ENABLED")
  events:RegisterEvent("PLAYER_REGEN_DISABLED")
  events:RegisterEvent("PLAYER_LEAVING_WORLD")
  events:RegisterEvent("PLAYER_ENTERING_WORLD")
  events:RegisterEvent("ZONE_CHANGED_NEW_AREA")
  events:SetScript("OnEvent", function(_, event)
    if not active() then return end
    if event == "PLAYER_REGEN_DISABLED" then
      if window and window:IsShown() then pending = {run=results.last,resume=true}; window:Hide() end
    elseif event == "PLAYER_LEAVING_WORLD" then
      loading = true
      if window and window:IsShown() then pending = {run=results.last,resume=true}; window:Hide() end
    elseif event == "PLAYER_ENTERING_WORLD" or event == "ZONE_CHANGED_NEW_AREA" then
      loading = false; settle = 1
    elseif event == "PLAYER_REGEN_ENABLED" then
      results.tryPending()
    end
  end)
  events:SetScript("OnUpdate", function(_, elapsed)
    settle = math.max(0, settle - elapsed); poll = poll + elapsed
    if poll >= 0.5 then poll = 0; results.tryPending(); results.checkCards() end
  end)
end

ns.commandHandlers = ns.commandHandlers or {}
ns.commandHandlers["cards"] = function(args)
  if string.lower(args and args[1] or "") == "reset" then
    local st = settings()
    if st then st.runCardPos = nil; st.duelCardPos = nil end
    if window then results.restorePosition(window) end
    if _G.GuildedDuelCard and _G.GuildedDuelCard.ClearAllPoints then
      _G.GuildedDuelCard:ClearAllPoints(); _G.GuildedDuelCard:SetPoint("BOTTOMRIGHT", UIParent, "BOTTOMRIGHT", -110, 330)
    end
    ns.message(L("The result and duel cards are back in their usual place."))
  else
    ns.message(ns.standalone and "/gdg cards reset" or "/guilded cards reset")
  end
end
ns.commandHelp = ns.commandHelp or {}
table.insert(ns.commandHelp, ns.standalone and "/gdg cards reset - put the result and duel cards back where they start" or "/guilded cards reset - put the result and duel cards back where they start")

ns.onDungeonSummary = results.show
ns.onDungeonResultReady = results.queue
