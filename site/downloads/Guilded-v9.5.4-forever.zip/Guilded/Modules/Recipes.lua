-- Recipes and cooldowns: who in the guild can craft what, when cooldowns are ready, and
-- a shopping list of materials.
--
--   * When you open a profession window, Guilded reads every recipe you know (and what it
--     needs, and any cooldown) and remembers it. Open each of your professions once.
--   * It then tells the guild, in short low-rate messages, so every Guilded can answer
--     "who can craft this?" without asking anyone. The list reaches Discord with the
--     companion's export (/craft who, /profession cooldowns).
--   * Item tooltips say who can craft the item.
--
--   /guilded recipes who <item link or name>   who can craft it
--   /guilded recipes mine                      what your characters' professions hold
--   /guilded recipes mats <item link> [count]  shopping list for a recipe you know
--   /guilded recipes share                     send your recipes to the guild again
--   /guilded cooldowns [mine]                  profession cooldowns, ready or not
--
-- Recipes are stored by id (an item id, or minus a spell id for enchants) so they do not
-- depend on the game language. Names come from the game's item cache and fill in over time.
local addonName, ns = ...
ns = ns or {}

local PREFIX = "GuildedRcp"
local CHUNK = 200
local MAX_KEYS = 800
local MAX_CHUNKS = 40
local MAX_COOLDOWNS = 20
-- Windows that are not a profession (a hunter's pet training uses the same window as enchanting).
local NOT_PROFESSIONS = { ["Beast Training"] = true, UNKNOWN = true }

-- One name per profession in every game language (Util.lua): "Cuisine" and "Cooking" are the same row.
local function canon(name, skillLine)
  return ns.util and ns.util.professionName and ns.util.professionName(name, skillLine) or name
end
-- The profession as the player's own language writes it (Locale.lua).
local function label(name)
  return ns.util and ns.util.professionLabel and ns.util.professionLabel(name) or name
end

local recipes = {}
ns.recipes = recipes

local function L(text) return ns.L and ns.L(text) or text end
local function displayName(name)
  if ns.util and ns.util.isForever and ns.util.isForever() and ns.displayName then return ns.displayName(name) end
  return name -- preserve cross-realm disambiguation on Blizzard clients
end

-- ---------------------------------------------------------------------
-- Saved data (per guild)
-- ---------------------------------------------------------------------

local function book()
  local db = ns.getDb and ns.getDb()
  if not db then return nil end
  db.recipeBook = db.recipeBook or {}
  local b = db.recipeBook
  b.people = b.people or {}     -- [player] = { [profession] = { v = epoch, keys = { id, ... } } }
  b.names = b.names or {}       -- [key] = "Name"
  b.mats = b.mats or {}         -- [key] = { { id = itemId, count = n, name = "..." }, ... } (your own recipes)
  b.cooldowns = b.cooldowns or {} -- [player] = { { prof = "...", name = "...", readyAt = epoch }, ... }
  b.cooldownAt = b.cooldownAt or {} -- [player] = epoch the cooldowns above were last updated
  return b
end
recipes.book = book

local function serverTime()
  if GetServerTime then return GetServerTime() end
  return time()
end

-- item:19364 -> 19364; enchant:7418 or spell:7418 -> -7418
local function keyFromLink(link)
  if type(link) ~= "string" then return nil end
  local item = string.match(link, "item:(%d+)")
  if item then return tonumber(item) end
  local spell = string.match(link, "enchant:(%d+)") or string.match(link, "spell:(%d+)")
  if spell then return -tonumber(spell) end
  return nil
end
recipes.keyFromLink = keyFromLink

-- ---------------------------------------------------------------------
-- What a recipe needs: your own profession scan first, else the shipped list
-- ---------------------------------------------------------------------
-- (9.5.2) Data/Reagents.lua (generated from data/recipes/*.csv, docs/RECIPE_REAGENTS.md) lists the reagents of every recipe, so
-- the Crafting tab shows them before anyone opens a profession window. What the game's own window says wins (WoW Forever may
-- change a recipe), and a difference is noted in /guilded diag (kind RECIPES) so the CSV can be corrected.
local function reagentName(id, fallbackName)
  local name
  if GetItemInfo then
    local ok, value = pcall(GetItemInfo, id)
    if ok and type(value) == "string" and value ~= "" and not (ns.isSecret and ns.isSecret(value)) then name = value end
  end
  if name then return name end
  if type(fallbackName) == "string" and fallbackName ~= "" then return fallbackName end
  local data = ns.reagentData
  return data and data.names and data.names[id] or ("item " .. tostring(id))
end

-- The shipped reagents of a recipe key as { { id, count, name }, ... } plus how many one craft makes, or nil.
function recipes.shippedMats(key)
  local data = ns.reagentData
  local row = data and data.recipes and key and data.recipes[key]
  if type(row) ~= "table" then return nil end
  local mats = {}
  for i = 2, #row, 2 do mats[#mats + 1] = { id = row[i], count = row[i + 1], name = reagentName(row[i]) } end
  return mats, row[1] or 1
end

-- Reagents for a recipe key: { { id, count, name }, ... }, "scan" or "data", and the count one craft makes. Nil when unknown.
function recipes.matsFor(key)
  if not key then return nil end
  local b = book()
  local scanned = b and b.mats and b.mats[key]
  if type(scanned) == "table" and #scanned > 0 then
    local _, produced = recipes.shippedMats(key)
    return scanned, "scan", produced
  end
  local mats, produced = recipes.shippedMats(key)
  if mats then return mats, "data", produced end
  return nil
end

-- Notes, once per recipe and session (at most 8 of each), where the game's window disagrees with the shipped list or has a
-- recipe the list lacks. Quiet: only /guilded diag shows it.
local noted, notedCount = {}, { differ = 0, missing = 0 }
local function sameReagents(live, shipped)
  if #live ~= #shipped then return false end
  local want = {}
  for _, m in ipairs(shipped) do want[m.id] = m.count end
  for _, m in ipairs(live) do if want[m.id] ~= m.count then return false end end
  return true
end
local function describeMats(list)
  local parts = {}
  for _, m in ipairs(list) do parts[#parts + 1] = string.format("%dx%d", m.count or 0, m.id or 0) end
  return table.concat(parts, " ")
end
function recipes.compareWithShipped(key, mats, name)
  if not key or type(mats) ~= "table" or #mats == 0 or noted[key] then return end
  local shipped = recipes.shippedMats(key)
  local kind = shipped and (not sameReagents(mats, shipped)) and "differ" or (not shipped and "missing" or nil)
  if not kind or notedCount[kind] >= 8 then return end
  noted[key] = true
  notedCount[kind] = notedCount[kind] + 1
  if ns.logDiagnostic then
    ns.logDiagnostic("RECIPES", string.format(kind == "differ" and "%s (%d): the game lists %s, the shipped data %s" or "%s (%d): not in the shipped data, the game lists %s%s",
      tostring(name or key), key, describeMats(mats), kind == "differ" and describeMats(shipped) or ""))
  end
end

local function cleanText(text)
  return (string.gsub(tostring(text or ""), "[|;,~]", ""))
end

-- A name for a recipe key: what we saw, else the game's cache, else a placeholder.
local function nameFor(key)
  local b = book()
  local known = b and b.names[key]
  if known then return known end
  local name
  pcall(function()
    if key > 0 and GetItemInfo then name = GetItemInfo(key)
    elseif key < 0 and GetSpellInfo then name = GetSpellInfo(-key) end
  end)
  if name and b then b.names[key] = name end
  return name or ((key > 0 and "item " or "enchant ") .. tostring(math.abs(key)))
end
recipes.nameFor = nameFor

-- ---------------------------------------------------------------------
-- Sending to the guild (slowly)
-- ---------------------------------------------------------------------

-- Core's paced queue (Util.lua) spaces the messages out.
local function enqueue(text)
  if not (IsInGuild and IsInGuild()) then return end
  ns.comm.send(PREFIX, text, "GUILD")
end
recipes.queueLength = function() return ns.comm.pending(PREFIX) end

-- One profession's list, cut into chunks: R|profession|version|n|N|key,key,...
local function shareProfession(profession, entry)
  local chunks, buffer = {}, ""
  for _, key in ipairs(entry.keys) do
    local piece = tostring(key)
    if buffer ~= "" and string.len(buffer) + 1 + string.len(piece) > CHUNK then
      table.insert(chunks, buffer)
      buffer = ""
    end
    buffer = buffer == "" and piece or (buffer .. "," .. piece)
  end
  if buffer ~= "" then table.insert(chunks, buffer) end
  if #chunks == 0 then chunks[1] = "" end -- empty lists remove old recipes on receivers
  for n, chunk in ipairs(chunks) do
    enqueue(string.format("R|%s|%d|%d|%d|%s", cleanText(profession), entry.v, n, #chunks, chunk))
  end
  local b, names = book(), ""
  for _, key in ipairs(entry.keys) do
    local name = b and b.names[key]
    if name then
      local part = tostring(key) .. "~" .. string.sub(cleanText(name), 1, 180)
      if #names + #part + 1 > 220 then enqueue("N|" .. names); names = "" end
      names = names == "" and part or (names .. ";" .. part)
    end
  end
  if names ~= "" then enqueue("N|" .. names) end
end

local function shareCooldowns(profession, list)
  enqueue("CDC|" .. cleanText(profession))
  for _, cooldown in ipairs(list) do
    if cooldown.prof == profession then
      enqueue(string.format("CD|%s|%d|%s", cleanText(profession), cooldown.readyAt, cleanText(cooldown.name)))
    end
  end
end

-- Tell the guild about everything you know (or one profession).
function recipes.shareMine(onlyProfession)
  local b, me = book(), ns.playerName()
  if not (b and me and b.people[me]) then return 0 end
  local count = 0
  for profession, entry in pairs(b.people[me]) do
    if not onlyProfession or onlyProfession == profession then
      shareProfession(profession, entry)
      shareCooldowns(profession, b.cooldowns[me] or {})
      count = count + 1
    end
  end
  b.sharedAt = serverTime()
  return count
end

local sharePending = false
local function scheduleShare(profession)
  if not (C_Timer and C_Timer.After) then recipes.shareMine(profession) return end
  if sharePending then return end
  sharePending = true
  C_Timer.After(5, function() sharePending = false; recipes.shareMine() end)
end

function recipes.pruneMine()
  if not ns.collectProfessions then return end
  local current, complete = ns.collectProfessions()
  if not complete then return end
  local b, me = book(), ns.playerName()
  if not (b and me) then return end
  local keep = {}
  for _, profession in ipairs(current) do keep[profession.name] = true end
  for profession, entry in pairs(b.people[me] or {}) do
    if not keep[profession] and #entry.keys > 0 then
      local empty = { v = math.max(serverTime(), entry.v + 1), keys = {} }
      b.people[me][profession] = empty
      shareProfession(profession, empty)
      shareCooldowns(profession, {})
    end
  end
  local cooldowns = {}
  for _, cooldown in ipairs(b.cooldowns[me] or {}) do if keep[cooldown.prof] then cooldowns[#cooldowns + 1] = cooldown end end
  b.cooldowns[me] = cooldowns
  b.cooldownAt[me] = serverTime()
end

-- ---------------------------------------------------------------------
-- Reading a profession window
-- ---------------------------------------------------------------------

-- The two windows have the same shape and different function names.
local function apiFor(kind)
  if kind == "trade" then
    return {
      line = function() return GetTradeSkillLine and GetTradeSkillLine() end,
      count = GetNumTradeSkills, info = GetTradeSkillInfo, link = GetTradeSkillItemLink,
      cooldown = GetTradeSkillCooldown,
      reagents = GetTradeSkillNumReagents, reagent = GetTradeSkillReagentInfo, reagentLink = GetTradeSkillReagentItemLink,
      expand = ExpandTradeSkillSubClass, collapse = CollapseTradeSkillSubClass
    }
  end
  return {
    line = function() return GetCraftDisplaySkillLine and GetCraftDisplaySkillLine() end,
    count = GetNumCrafts, info = GetCraftInfo, link = GetCraftItemLink,
    reagents = GetCraftNumReagents, reagent = GetCraftReagentInfo, reagentLink = GetCraftReagentItemLink,
    expand = ExpandCraftSkillLine, collapse = CollapseCraftSkillLine
  }
end

-- Opens every collapsed group so all recipes are listed, and closes them again afterwards.
local function expandAll(api)
  local opened = {}
  if not (api.expand and api.count and api.info) then return opened end
  local i = 1
  while i <= api.count() and i < 2000 do
    local name, kind, _, isExpanded = api.info(i)
    if kind == "header" and not isExpanded then
      api.expand(i)
      table.insert(opened, name)
    end
    i = i + 1
  end
  return opened
end

local function collapseAgain(api, opened)
  if #opened == 0 or not api.collapse then return end
  local wanted = {}
  for _, name in ipairs(opened) do wanted[name] = true end
  for i = api.count(), 1, -1 do
    local name, kind = api.info(i)
    if kind == "header" and wanted[name] then api.collapse(i) end
  end
end

-- Returns { profession, keys, names, mats, cooldowns } or nil when there is nothing to read.
-- The classic trade/craft window and functions (GetTradeSkillInfo, GetCraftInfo, ...).
local function readLegacyWindow(kind)
  local api = apiFor(kind)
  if not (api.count and api.info and api.link) then return nil end
  local profession = api.line()
  if type(profession) ~= "string" or profession == "" or NOT_PROFESSIONS[profession] then return nil end
  profession = canon(profession)
  local total = api.count()
  if not total or total < 1 then return nil end
  local opened = expandAll(api)
  local result = { profession = profession, keys = {}, names = {}, mats = {}, cooldowns = {} }
  local seen = {}
  local now = serverTime()
  for i = 1, api.count() do
    local name, rowKind = api.info(i)
    if name and rowKind ~= "header" then
      local link = api.link(i)
      local key = keyFromLink(link)
      if key and not seen[key] then
        seen[key] = true
        table.insert(result.keys, key)
        result.names[key] = string.match(link or "", "%[(.-)%]") or name
        if api.reagents and api.reagent then
          local mats = {}
          for j = 1, (api.reagents(i) or 0) do
            local reagentName, _, count = api.reagent(i, j)
            local reagentKey = api.reagentLink and keyFromLink(api.reagentLink(i, j))
            if reagentName and reagentKey and reagentKey > 0 then
              table.insert(mats, { id = reagentKey, count = count or 1, name = reagentName })
            end
          end
          result.mats[key] = mats
        end
        local seconds = api.cooldown and api.cooldown(i)
        if type(seconds) == "number" and seconds > 0 then
          table.insert(result.cooldowns, { prof = profession, name = name, readyAt = now + math.floor(seconds) })
        end
      end
    end
  end
  collapseAgain(api, opened)
  table.sort(result.keys)
  return result
end

-- The revamped profession window (Legion and later; also the Classic clients that share that
-- code). GetTradeSkillInfo/GetCraftInfo and TRADE_SKILL_SHOW/CRAFT_SHOW do not exist here, so
-- the classic reader above finds nothing and this one runs instead. C_TradeSkillUI.GetAllRecipeIDs
-- ignores collapsed groups and filters by itself, so there is no expand/collapse to do.
local function readModernWindow()
  local ui = C_TradeSkillUI
  if not (ui and ui.GetAllRecipeIDs and ui.GetRecipeInfo) then return nil end
  local ok, recipeIDs = pcall(ui.GetAllRecipeIDs)
  if not ok or not recipeIDs or #recipeIDs == 0 then return nil end
  local profession
  if ui.GetBaseProfessionInfo then
    local infoOk, baseInfo = pcall(ui.GetBaseProfessionInfo)
    profession = infoOk and baseInfo and baseInfo.professionName or nil
    if type(profession) == "string" and profession ~= "" and not NOT_PROFESSIONS[profession] then
      profession = canon(profession, infoOk and baseInfo and (baseInfo.parentProfessionID or baseInfo.professionID))
    end
  end
  if type(profession) ~= "string" or profession == "" or NOT_PROFESSIONS[profession] then return nil end
  local result = { profession = profession, keys = {}, names = {}, mats = {}, cooldowns = {} }
  local seen = {}
  for _, recipeID in ipairs(recipeIDs) do
    local infoOk, info = pcall(ui.GetRecipeInfo, recipeID)
    if infoOk and info and info.learned and info.name then
      local key
      if info.isEnchantingRecipe then
        -- The recipe id is the enchant's spell id: the same key the classic window gives
        -- ("enchant:<spell id>"), so crafters are found whichever client read the recipe.
        key = -recipeID
      elseif info.hyperlink then
        key = keyFromLink(info.hyperlink)
      end
      local schematic
      if (not key or ui.GetRecipeSchematic) and ui.GetRecipeSchematic then
        local schemaOk, s = pcall(ui.GetRecipeSchematic, recipeID, false)
        if schemaOk then schematic = s end
      end
      if not key and schematic and schematic.outputItemID then key = schematic.outputItemID end
      if key and not seen[key] then
        seen[key] = true
        table.insert(result.keys, key)
        result.names[key] = info.name
        if schematic and schematic.reagentSlotSchematics then
          local mats = {}
          for _, slot in ipairs(schematic.reagentSlotSchematics) do
            local reagent = slot.reagents and slot.reagents[1]
            local itemId = reagent and reagent.itemID
            if itemId and slot.quantityRequired then
              local reagentName = GetItemInfo and GetItemInfo(itemId)
              table.insert(mats, { id = itemId, count = slot.quantityRequired, name = reagentName or ("item " .. itemId) })
            end
          end
          result.mats[key] = mats
        end
        -- No cooldown reading here yet: unlike the classic API there is no single call for it,
        -- and a recipe missing from the cooldown list is harmless (it just shows as not on cooldown).
      end
    end
  end
  table.sort(result.keys)
  return result
end

-- Whether the open window shows someone else's recipes, and whose. A profession link from chat
-- or a guildmate's profession opened from the guild window names its owner: those recipes are
-- saved under the owner's name (never as yours), so browsing the guild fills in who can craft
-- what, even for players without Guilded. The guild-wide recipe list and NPC / crafting-order
-- views belong to nobody in particular and are not saved. Returns viewingOthers, ownerName.
local function viewingOthers()
  local function secret(value) return ns.isSecret and ns.isSecret(value) end
  local function call(fn)
    if type(fn) ~= "function" then return nil end
    local ok, first, second = pcall(fn)
    if ok and not secret(first) then return first, second end
    return nil
  end
  local ui = C_TradeSkillUI
  for _, fn in ipairs({ ui and ui.IsTradeSkillLinked or false, IsTradeSkillLinked or false }) do
    local linked, owner = call(fn)
    if linked then
      if type(owner) == "string" and owner ~= "" and not secret(owner) then
        return true, ns.normalizeName and ns.normalizeName(owner) or owner
      end
      return true, nil
    end
  end
  for _, fn in ipairs({ ui and ui.IsTradeSkillGuild or false, ui and ui.IsNPCCrafting or false,
    ui and ui.IsTradeSkillGuildMember or false, IsTradeSkillGuild or false }) do
    if call(fn) then return true, nil end
  end
  return false, nil
end
recipes.viewingOthers = viewingOthers

local function readWindow(kind)
  local others, owner = viewingOthers()
  if others and not owner then return nil end
  local read = readLegacyWindow(kind) or (kind == "trade" and readModernWindow() or nil)
  if read and owner then
    -- Someone else's list: only which recipes they know. Materials and cooldowns are yours only.
    read.owner, read.mats, read.cooldowns = owner, {}, {}
  end
  return read
end

-- Recipes that share one cooldown (all transmutes) are shown as one line.
local function mergeCooldowns(list)
  local groups, order = {}, {}
  for _, cooldown in ipairs(list) do
    local slot = math.floor(cooldown.readyAt / 120)
    local id = cooldown.prof .. ":" .. slot
    local group = groups[id]
    if not group then
      group = { prof = cooldown.prof, readyAt = cooldown.readyAt, names = {} }
      groups[id] = group
      table.insert(order, id)
    end
    table.insert(group.names, cooldown.name)
  end
  local merged = {}
  for _, id in ipairs(order) do
    local group = groups[id]
    local name = group.names[1]
    if #group.names > 1 then
      local prefix = string.match(name, "^(.-):")
      local shared = prefix ~= nil
      for _, other in ipairs(group.names) do
        if not shared or string.match(other, "^(.-):") ~= prefix then shared = false break end
      end
      name = shared and prefix or (name .. " +" .. (#group.names - 1))
    end
    table.insert(merged, { prof = group.prof, name = name, readyAt = group.readyAt })
  end
  return merged
end

local function sameKeys(a, b)
  if not a or #a ~= #b then return false end
  for i = 1, #a do
    if a[i] ~= b[i] then return false end
  end
  return true
end

-- Keeps what was read. Returns true when the recipe list changed.
function recipes.store(read)
  local b, me = book(), ns.playerName()
  if not (b and me and read) then return false end
  if read.owner and read.owner ~= me then
    -- A guildmate's profession you looked at: kept under their name, marked "viewed", and never
    -- over what their own addon reported (that is fresher and complete).
    b.people[read.owner] = b.people[read.owner] or {}
    local before = b.people[read.owner][read.profession]
    if before and not before.viewed then return false end
    local changed = not (before and sameKeys(before.keys, read.keys))
    if changed then b.people[read.owner][read.profession] = { v = serverTime(), keys = read.keys, viewed = true } end
    for key, name in pairs(read.names) do b.names[key] = name end
    return changed
  end
  b.people[me] = b.people[me] or {}
  local before = b.people[me][read.profession]
  local changed = not (before and sameKeys(before.keys, read.keys))
  if changed then b.people[me][read.profession] = { v = serverTime(), keys = read.keys } end
  for key, name in pairs(read.names) do b.names[key] = name end
  for key, mats in pairs(read.mats) do
    -- An empty reading (the window gave no reagents) never replaces what is known; a real one wins over the shipped data.
    if #mats > 0 then
      b.mats[key] = mats
      pcall(recipes.compareWithShipped, key, mats, read.names and read.names[key])
    end
  end
  -- Cooldowns of this profession are replaced by what the window says now.
  local kept = {}
  for _, cooldown in ipairs(b.cooldowns[me] or {}) do
    if cooldown.prof ~= read.profession then table.insert(kept, cooldown) end
  end
  for _, cooldown in ipairs(mergeCooldowns(read.cooldowns)) do table.insert(kept, cooldown) end
  local cooldownChanged = #kept ~= #(b.cooldowns[me] or {})
  b.cooldowns[me] = kept
  b.cooldownAt[me] = serverTime()
  if changed or cooldownChanged or #read.cooldowns > 0 then
    b.dirty = true
  end
  return changed
end

local function scan(kind)
  local ok, read = pcall(readWindow, kind)
  if not ok then
    if ns.logDiagnostic then ns.logDiagnostic("LUA_ERROR", "recipes: " .. tostring(read)) end
    return
  end
  if not read then return end
  local changed = recipes.store(read)
  if read.owner and read.owner ~= ns.playerName() then
    if changed then
      ns.message(string.format(L("Guilded saved %s's %s recipes (%d) from the window you opened."), read.owner, read.profession, #read.keys))
    end
    if ns.onRecipesChange then pcall(ns.onRecipesChange) end
    return
  end
  local b = book()
  if b and (changed or b.dirty) then
    b.dirty = nil
    scheduleShare(read.profession)
  end
  if changed then
    ns.message(string.format(L("Guilded read your %s recipes (%d). Your guild can now see who can craft what."), read.profession, #read.keys))
  end
  if ns.onRecipesChange then pcall(ns.onRecipesChange) end
end
recipes.scan = scan

-- ---------------------------------------------------------------------
-- Receiving from other players
-- ---------------------------------------------------------------------

local pending = {}
local lastReply = 0

local function onMessage(text, sender)
  local b = book()
  local name = ns.normalizeName(sender)
  if not (b and name) then return end
  local kind = string.match(text, "^(%u+)|")
  if kind == "Q" then
    if serverTime() - lastReply >= 60 then lastReply = serverTime(); recipes.shareMine() end
  elseif kind == "R" then
    local profession, v, n, total, list = string.match(text, "^R|([^|]+)|(%d+)|(%d+)|(%d+)|(.*)$")
    profession = profession and canon(profession)
    n, total, v = tonumber(n), tonumber(total), tonumber(v)
    if not (profession and n and total and v) or total < 1 or total > MAX_CHUNKS or n < 1 or n > total then return end
    local id = name .. "|" .. profession
    local partial = pending[id]
    if not partial or partial.v ~= v or partial.total ~= total then
      partial = { v = v, total = total, chunks = {} }
      pending[id] = partial
    end
    partial.chunks[n] = list
    for i = 1, total do
      if not partial.chunks[i] then return end
    end
    local keys = {}
    for i = 1, total do
      for key in string.gmatch(partial.chunks[i], "-?%d+") do
        table.insert(keys, tonumber(key))
        if #keys >= MAX_KEYS then break end
      end
    end
    pending[id] = nil
    b.people[name] = b.people[name] or {}
    local current = b.people[name][profession]
    -- Their own report always beats a copy someone saved by looking at their window.
    if current and not current.viewed and current.v >= v then return end
    b.people[name][profession] = { v = v, keys = keys }
    for _, key in ipairs(keys) do nameFor(key) end
    if ns.onRecipesChange then pcall(ns.onRecipesChange) end
  elseif kind == "N" then
    for part in string.gmatch(string.sub(text, 3), "[^;]+") do
      local key, label = string.match(part, "^(%-?%d+)~(.+)$")
      key = tonumber(key)
      if key and #label <= 180 then
        for _, entry in pairs(b.people[name] or {}) do
          for _, known in ipairs(entry.keys) do
            if known == key then b.names[key] = label end
          end
        end
      end
    end
  elseif kind == "CDC" then
    local profession = string.match(text, "^CDC|(.+)$")
    if not profession then return end
    profession = canon(profession)
    local kept = {}
    for _, cooldown in ipairs(b.cooldowns[name] or {}) do
      if cooldown.prof ~= profession then table.insert(kept, cooldown) end
    end
    b.cooldowns[name] = kept
    b.cooldownAt[name] = serverTime()
  elseif kind == "CD" then
    local profession, readyAt, cooldownName = string.match(text, "^CD|([^|]+)|(%d+)|(.*)$")
    if not profession then return end
    profession = canon(profession)
    local list = b.cooldowns[name] or {}
    if #list < MAX_COOLDOWNS then
      table.insert(list, { prof = profession, name = cooldownName, readyAt = tonumber(readyAt) })
    end
    b.cooldowns[name] = list
    b.cooldownAt[name] = serverTime()
    if ns.onRecipesChange then pcall(ns.onRecipesChange) end
  end
end

-- ---------------------------------------------------------------------
-- Questions
-- ---------------------------------------------------------------------

-- Who can craft a recipe key: { { name = "Ann", profession = "Alchemy" }, ... }
function recipes.crafters(key)
  local b = book()
  local found = {}
  if not (b and key) then return found end
  for player, professions in pairs(b.people) do
    for profession, entry in pairs(professions) do
      for _, known in ipairs(entry.keys) do
        if known == key then table.insert(found, { name = player, profession = profession, seen = entry.v }) break end
      end
    end
  end
  table.sort(found, function(x, y) return x.name < y.name end)
  return found
end

-- Recipe keys whose name contains the text (matches only names the game has told us).
local function keysNamed(text)
  local b = book()
  local needle = string.lower(text or "")
  local keys, seen = {}, {}
  if not b or needle == "" then return keys end
  for _, professions in pairs(b.people) do
    for _, entry in pairs(professions) do
      for _, key in ipairs(entry.keys) do
        if not seen[key] then
          seen[key] = true
          local name = b.names[key] or nameFor(key)
          if string.find(string.lower(name), needle, 1, true) then table.insert(keys, key) end
        end
      end
    end
  end
  table.sort(keys)
  return keys
end

-- ---------------------------------------------------------------------
-- Item tooltip: who can craft it. Setting: off | compact (default) | full.
--   compact  "Guilded (dot) First Aid: 4 crafters" and up to 3 names (you, then online, then the
--            most recently shared); more than 6 crafters shows only the count.
--   Shift    held (or mode full): every crafter on its own line with online status.
-- ---------------------------------------------------------------------
local TOOLTIP_MODES = { off = true, compact = true, full = true }
local COMPACT_NAMES = 3      -- names shown on the compact line
local COUNT_ONLY_ABOVE = 6   -- more crafters than this: count only, until Shift
local COMPACT_LINE_MAX = 64   -- characters: a compact line with last-seen notes stays one line
local FULL_LIST_MAX = 40     -- lines in the Shift list
local DOT = " \194\183 "     -- middle dot, written as bytes: the addon files stay ASCII

recipes.MODE_WORD = { off = "Off", compact = "Compact", full = "Full" }
recipes.MODES = { "off", "compact", "full" }

function recipes.tooltipMode()
  local s = ns.getSettings and ns.getSettings()
  local mode = s and s.tooltipCrafters
  return TOOLTIP_MODES[mode] and mode or "compact"
end

function recipes.setTooltipMode(mode)
  mode = string.lower(tostring(mode or ""))
  local s = ns.getSettings and ns.getSettings()
  if not (TOOLTIP_MODES[mode] and s) then return false end
  s.tooltipCrafters = mode
  return true
end

-- Guildmates online right now, and when the others were last seen (a few seconds' cache:
-- tooltips are built often). `seen[name]` is a unix time from GetGuildRosterLastOnline.
local onlineCache, seenCache, onlineAt
local MAX_SEEN = 600
local function onlineSet()
  local stamp = GetTime and GetTime() or 0
  if onlineCache and onlineAt == stamp then return onlineCache, seenCache end
  local set, seen = {}, {}
  local now = time and time() or 0
  if GetNumGuildMembers and GetGuildRosterInfo then
    for i = 1, math.min(GetNumGuildMembers() or 0, 1000) do
      local rosterName, _, _, _, _, _, _, _, online = GetGuildRosterInfo(i)
      if rosterName then
        local name = ns.normalizeName and ns.normalizeName(rosterName) or rosterName
        if name then
          if online then
            set[name] = true
            seen[name] = now
          elseif GetGuildRosterLastOnline then
            local years, months, days, hours = GetGuildRosterLastOnline(i)
            if type(years) == "number" then
              local hoursAgo = (((years or 0) * 365 + (months or 0) * 30 + (days or 0)) * 24) + (hours or 0)
              seen[name] = now - hoursAgo * 3600
            end
          end
        end
      end
    end
  end
  onlineCache, seenCache, onlineAt = set, seen, stamp
  return set, seen
end

-- Remembers when crafters were last seen (SavedVariables), so the tooltip still has an answer
-- while the roster is not loaded. `read` is when the roster was read.
local function rememberSeen(names, seen)
  local d = ns.getDb and ns.getDb()
  if not d then return end
  d.crafterSeen = type(d.crafterSeen) == "table" and d.crafterSeen or {}
  local now = time and time() or 0
  local count = 0
  for _ in pairs(d.crafterSeen) do count = count + 1 end
  for _, name in ipairs(names) do
    if seen[name] then
      if not d.crafterSeen[name] then count = count + 1 end
      if count <= MAX_SEEN then d.crafterSeen[name] = { at = seen[name], read = now } end
    end
  end
end

-- "online", or how long ago in a few characters: 5h, 3d, 2w, 4mo, 1y. nil when unknown.
function recipes.lastSeenText(name, online, seenAt)
  if online then return L("online") end
  if type(seenAt) ~= "number" then
    local d = ns.getDb and ns.getDb()
    local cached = d and type(d.crafterSeen) == "table" and d.crafterSeen[name]
    seenAt = cached and cached.at
  end
  if type(seenAt) ~= "number" then return nil end
  local age = math.max(0, (time and time() or 0) - seenAt)
  local hours = math.floor(age / 3600)
  if hours < 1 then return L("<1h") end
  if hours < 24 then return string.format(L("%dh"), hours) end
  local days = math.floor(hours / 24)
  if days < 14 then return string.format(L("%dd"), days) end
  if days < 60 then return string.format(L("%dw"), math.floor(days / 7)) end
  if days < 365 then return string.format(L("%dmo"), math.floor(days / 30)) end
  return string.format(L("%dy"), math.floor(days / 365))
end

-- One recipe as the Crafting page shows it: { key, name, crafters = { { name, shown, online, me, seenAt, seen, profession } } },
-- the crafters you first, then online, then the most recently seen.
local function buildEntry(key, me, online, seen)
  local entry, byName = { key = key, name = nameFor(key), crafters = {} }, {}
  for _, found in ipairs(recipes.crafters(key)) do
    if not byName[found.name] then
      byName[found.name] = true
      local mine = found.name == me
      table.insert(entry.crafters, { name = found.name, shown = displayName(found.name), me = mine, online = mine or online[found.name] == true,
        seenAt = seen[found.name], seen = found.seen, profession = found.profession })
    end
  end
  table.sort(entry.crafters, function(x, y)
    if x.me ~= y.me then return x.me end
    if x.online ~= y.online then return x.online end
    if (x.seen or 0) ~= (y.seen or 0) then return (x.seen or 0) > (y.seen or 0) end
    return x.name < y.name
  end)
  return entry
end

function recipes.entry(key)
  if not key then return nil end
  local online, seen = onlineSet()
  return buildEntry(key, ns.playerName and ns.playerName(), online, seen)
end

-- Every recipe anyone shared, grouped by profession (the Crafting page's tree):
-- { { profession = "Tailoring", entries = { { key, name, crafters = n, online = n } } } }, professions and recipes by name.
function recipes.browse()
  local b = book()
  local groups, byProfession = {}, {}
  if not b then return groups end
  local me = ns.playerName and ns.playerName()
  local online = onlineSet()
  for player, professions in pairs(b.people) do
    local here = player ~= me and online[player] == true   -- a guildmate online now (you do not count)
    for profession, entry in pairs(professions) do
      local group = byProfession[profession]
      if not group then group = { profession = profession, entries = {}, index = {} }; byProfession[profession] = group; groups[#groups + 1] = group end
      for _, key in ipairs(entry.keys) do
        local item = group.index[key]
        if not item then
          item = { key = key, name = b.names[key] or nameFor(key), crafters = 0, online = 0, profession = profession }
          group.index[key] = item
          group.entries[#group.entries + 1] = item
        end
        item.crafters = item.crafters + 1
        if here then item.online = item.online + 1 end
      end
    end
  end
  for _, group in ipairs(groups) do
    group.index = nil
    table.sort(group.entries, function(x, y) if x.name ~= y.name then return x.name < y.name end return x.key < y.key end)
  end
  table.sort(groups, function(x, y) return x.profession < y.profession end)
  return groups
end

-- Search for the Crafting page: a name (or part of one), a shift-clicked item link or an item id.
-- Returns { { key, name, crafters = { { name, shown, online, me, seenAt, profession } } } }, matches
-- (at most `limit` entries; crafters: you first, then online, then the most recently seen).
function recipes.search(query, limit)
  local text = string.match(tostring(query or ""), "^%s*(.-)%s*$") or ""
  local results, matches = {}, 0
  if #text < 2 then return results, 0 end
  local keys = {}
  local linked = keyFromLink(text) or (string.match(text, "^%d+$") and tonumber(text)) or nil
  if linked then keys[1] = linked else keys = keysNamed(string.match(text, "%[(.-)%]") or text) end
  matches = #keys
  local me = ns.playerName and ns.playerName()
  local online, seen = onlineSet()
  for i = 1, math.min(#keys, limit or 4) do
    table.insert(results, buildEntry(keys[i], me, online, seen))
  end
  return results, matches
end

local function shiftHeld() return IsShiftKeyDown and IsShiftKeyDown() and true or false end

-- First names only, unless two crafters share one (then the full names).
local function shortNames(group)
  local counts = {}
  for _, crafter in ipairs(group) do
    local first = string.lower(string.match(crafter.shown, "^(%S+)") or crafter.shown)
    counts[first] = (counts[first] or 0) + 1
  end
  for _, crafter in ipairs(group) do
    local first = string.match(crafter.shown, "^(%S+)") or crafter.shown
    crafter.short = counts[string.lower(first)] > 1 and crafter.shown or first
  end
end

-- Lines for the tooltip: { raw = "text", wrap = bool } entries (Tooltip.lua adds no prefix to
-- these). Second result: true when holding Shift would show more than is shown now.
function recipes.tooltipLines(id, opts)
  opts = opts or {}
  local mode = opts.mode or recipes.tooltipMode()
  local found = recipes.crafters(id)
  if mode == "off" or #found == 0 then return {}, false end
  local expanded = mode == "full" or (opts.shift ~= nil and opts.shift) or (opts.shift == nil and shiftHeld())
  local me = ns.playerName and ns.playerName()
  local online, seen = onlineSet()
  local seenNames = {}
  local groups, order = {}, {}
  for _, crafter in ipairs(found) do
    if not groups[crafter.profession] then
      groups[crafter.profession] = {}
      table.insert(order, crafter.profession)
    end
    crafter.shown = displayName(crafter.name)
    crafter.me = crafter.name == me
    crafter.online = crafter.me or online[crafter.name] == true
    crafter.seenAt = seen[crafter.name]
    table.insert(seenNames, crafter.name)
    table.insert(groups[crafter.profession], crafter)
  end
  rememberSeen(seenNames, seen)
  local lines, hidden = {}, false
  for _, profession in ipairs(order) do
    local group = groups[profession]
    table.sort(group, function(x, y)
      if x.me ~= y.me then return x.me end
      if x.online ~= y.online then return x.online end
      if (x.seen or 0) ~= (y.seen or 0) then return (x.seen or 0) > (y.seen or 0) end
      return x.name < y.name
    end)
    shortNames(group)
    local count = #group
    local countText = count == 1 and L("1 crafter") or string.format(L("%d crafters"), count)
    local head = "Guilded" .. DOT .. label(profession) .. ": "
    if expanded then
      table.insert(lines, { raw = head .. countText })
      for i = 1, math.min(FULL_LIST_MAX, count) do
        local crafter = group[i]
        local label = crafter.me and (crafter.shown .. " (" .. L("you") .. ")") or crafter.shown
        local state = crafter.online and ("|cff40ff40" .. L("online") .. "|r") or ("|cff9d9d9d" .. L("offline") .. "|r")
        local ago = not crafter.online and recipes.lastSeenText(crafter.name, false, crafter.seenAt)
        if ago then state = state .. " |cff9d9d9d(" .. ago .. ")|r" end
        table.insert(lines, { raw = "  " .. label .. " - " .. state })
      end
      if count > FULL_LIST_MAX then table.insert(lines, { raw = "  +" .. (count - FULL_LIST_MAX) .. " " .. L("more") }) end
    else
      local names, plain = {}, {}
      for i = 1, math.min(COMPACT_NAMES, count) do
        local crafter = group[i]
        local base = crafter.me and L("you") or crafter.short
        local ago = not crafter.me and recipes.lastSeenText(crafter.name, crafter.online, crafter.seenAt)
        table.insert(plain, base)
        table.insert(names, ago and (base .. " (" .. ago .. ")") or base)
      end
      local more = count - #names
      local tail = more > 0 and (" +" .. more .. " " .. L("more")) or ""
      -- "last seen" must not make the tooltip taller: when the annotated names would no longer
      -- fit on one line, show the plain names.
      local annotated = table.concat(names, ", ") .. tail
      local nameText = (#head + #annotated <= COMPACT_LINE_MAX) and annotated or (table.concat(plain, ", ") .. tail)
      if count <= COMPACT_NAMES then
        table.insert(lines, { raw = head .. nameText, wrap = true })
      elseif count <= COUNT_ONLY_ABOVE then
        table.insert(lines, { raw = head .. countText })
        table.insert(lines, { raw = nameText, wrap = true })
        hidden = true
      else
        table.insert(lines, { raw = head .. countText })
        hidden = true
      end
    end
  end
  return lines, hidden
end

local function whoText(query)
  local key = keyFromLink(query)
  local keys = key and { key } or keysNamed(query)
  if #keys == 0 then
    return string.format(L("Nobody is known to craft \"%s\" yet. Only players with Guilded who have opened their profession window show up."), query)
  end
  local lines = {}
  for i = 1, math.min(6, #keys) do
    local crafters = recipes.crafters(keys[i])
    local parts = {}
    for _, crafter in ipairs(crafters) do table.insert(parts, string.format("%s (%s)", displayName(crafter.name), label(crafter.profession))) end
    table.insert(lines, nameFor(keys[i]) .. ": " .. (#parts > 0 and table.concat(parts, ", ") or L("nobody known")))
  end
  if #keys > 6 then table.insert(lines, string.format(L("... and %d more matches. Be more specific."), #keys - 6)) end
  return table.concat(lines, "\n")
end

local function mineText()
  local b, me = book(), ns.playerName()
  local mine = b and me and b.people[me]
  if not mine then return L("Open your profession windows once so Guilded can read your recipes.") end
  local names = {}
  for profession in pairs(mine) do table.insert(names, profession) end
  table.sort(names)
  local lines = {}
  for _, profession in ipairs(names) do
    table.insert(lines, string.format("%s: %d %s", label(profession), #mine[profession].keys, L("recipes")))
  end
  local people = 0
  for _ in pairs(b.people) do people = people + 1 end
  table.insert(lines, string.format(L("%d guild members' recipes are known to you."), people))
  return table.concat(lines, "\n")
end

-- Materials for a recipe you know, times a count, as a shopping list.
local function matsText(query, count)
  local b = book()
  local key = keyFromLink(query)
  if not key then
    local keys = keysNamed(query)
    key = keys[1]
  end
  local mats = key and recipes.matsFor(key)
  if not mats then
    return L("Guilded only knows the materials of recipes you know yourself. Open the profession window, then try again.")
  end
  count = math.max(1, math.floor(tonumber(count) or 1))
  local lines = { string.format(L("Materials for %d x %s:"), count, nameFor(key)) }
  for _, mat in ipairs(mats) do
    local need = mat.count * count
    local have = ns.craftOrders and ns.craftOrders.haveCount and ns.craftOrders.haveCount(mat.id) or (GetItemCount and GetItemCount(mat.id, true) or nil)
    table.insert(lines, string.format("%d x %s%s", need, mat.name, have and string.format(" (%s %d)", L("you have"), have) or ""))
  end
  return table.concat(lines, "\n")
end

local function duration(seconds)
  if seconds <= 0 then return L("ready") end
  local hours = math.floor(seconds / 3600)
  local minutes = math.floor((seconds % 3600) / 60)
  if hours >= 24 then return string.format("%dd %dh", math.floor(hours / 24), hours % 24) end
  if hours > 0 then return string.format("%dh %dm", hours, minutes) end
  return string.format("%dm", math.max(1, minutes))
end
recipes.duration = duration

function recipes.cooldownLines(onlyMine)
  local b, me = book(), ns.playerName()
  local rows = {}
  if not b then return rows end
  local now = serverTime()
  for player, list in pairs(b.cooldowns) do
    if not onlyMine or player == me then
      for _, cooldown in ipairs(list) do
        table.insert(rows, { player = player, name = cooldown.name, prof = cooldown.prof, left = cooldown.readyAt - now })
      end
    end
  end
  table.sort(rows, function(x, y)
    if x.left ~= y.left then return x.left < y.left end
    return x.player < y.player
  end)
  local lines = {}
  for _, row in ipairs(rows) do
    table.insert(lines, string.format("%s - %s (%s): %s", displayName(row.player), row.name, label(row.prof), duration(row.left)))
  end
  return lines
end

-- ---------------------------------------------------------------------
-- A reminder for professions never read
-- ---------------------------------------------------------------------

-- The game gives addons a recipe list only while its window is open, so a profession nobody
-- opened yet is unknown. Gathering skills have no recipes and are left out (by skill line id,
-- which does not depend on the game language).
local GATHERING = { [182] = true, [186] = true, [393] = true, [356] = true, [794] = true }

function recipes.unreadProfessions()
  local out = {}
  if not (GetProfessions and GetProfessionInfo) then return out end
  local b, me = book(), ns.playerName()
  local mine = (b and me and b.people[me]) or {}
  local ok, a, b2, c, d, e, f = pcall(GetProfessions)
  if not ok then return out end
  for _, index in ipairs({ a or false, b2 or false, c or false, d or false, e or false, f or false }) do
    if index then
      local infoOk, name, _, _, _, _, _, skillLine = pcall(GetProfessionInfo, index)
      -- The book is keyed by the English name: compare with that, not with the game's own (French "Cuisine") spelling,
      -- or a French client is told to open a window it already read.
      local key = infoOk and type(name) == "string" and not (ns.isSecret and ns.isSecret(name)) and canon(name, skillLine) or nil
      if key and not GATHERING[tonumber(skillLine) or 0] and not mine[key] then
        table.insert(out, key)
      end
    end
  end
  return out
end

-- Once per character and profession, a line saying which window to open once. Returns the names.
function recipes.remindUnread()
  local b, me = book(), ns.playerName()
  if not (b and me) then return {} end
  b.reminded = b.reminded or {}
  local names = {}
  for _, name in ipairs(recipes.unreadProfessions()) do
    local key = me .. ":" .. name
    if not b.reminded[key] then
      b.reminded[key] = true
      table.insert(names, name)
    end
  end
  if #names > 0 then
    local shown = {}
    for index, name in ipairs(names) do shown[index] = label(name) end -- shown in the player's language, stored in English
    ns.infoMessage(string.format(L("Open your %s window once so your guild can see what you craft (Guilded reads it by itself)."), table.concat(shown, ", ")))
  end
  return names
end

-- ---------------------------------------------------------------------
-- Commands and events
-- ---------------------------------------------------------------------

recipes.whoText = whoText
recipes.mineText = mineText

ns.commandHandlers = ns.commandHandlers or {}
ns.commandHandlers["recipes"] = function(args)
  local action = string.lower(args[1] or "")
  table.remove(args, 1)
  if action == "who" or action == "craft" then
    local query = table.concat(args, " ")
    if query == "" then ns.message(L("Usage:") .. " /guilded recipes who <item link or name>") return end
    ns.message(whoText(query))
  elseif action == "mine" or action == "list" then ns.message(mineText())
  elseif action == "mats" or action == "materials" then
    local count = tonumber(args[#args])
    if count and #args > 1 then table.remove(args) else count = 1 end
    local query = table.concat(args, " ")
    if query == "" then ns.message(L("Usage:") .. " /guilded recipes mats <item link> [count]") return end
    ns.message(matsText(query, count))
  elseif action == "tooltip" then
    local mode = string.lower(args[1] or "")
    if recipes.setTooltipMode(mode) then
      ns.message(string.format(L("Item tooltips: crafters %s."), L(recipes.MODE_WORD[mode])))
      if ns.options and ns.options.refresh then pcall(ns.options.refresh) end
    else
      ns.message(string.format(L("Item tooltips: crafters %s."), L(recipes.MODE_WORD[recipes.tooltipMode()])) .. " /guilded recipes tooltip off | compact | full")
    end
  elseif action == "share" then
    local sent = recipes.shareMine()
    ns.message(sent > 0 and L("Sending your recipes to the guild.") or L("Open your profession windows once so Guilded can read your recipes."))
  else
    ns.message("/guilded recipes who <item> | mine | mats <item> [count] | share   -   /guilded cooldowns [mine]")
  end
end

ns.commandHandlers["cooldowns"] = function(args)
  local lines = recipes.cooldownLines(string.lower(args[1] or "") == "mine")
  if #lines == 0 then ns.message(L("No profession cooldowns are known. They are read when you open a profession window.")) return end
  for i = 1, math.min(15, #lines) do ns.message(lines[i]) end
  if #lines > 15 then ns.message(string.format(L("... and %d more."), #lines - 15)) end
end
ns.commandHelp = ns.commandHelp or {}
table.insert(ns.commandHelp, "/guilded recipes who <item> - who in the guild can craft it; /guilded cooldowns - profession cooldowns")

local function onEvent(_, event, ...)
  if event == "PLAYER_LOGIN" then
    ns.comm.register(PREFIX)
    -- Tell the guild what you know, once in a while and not all at the same second.
    if C_Timer and C_Timer.After then
      C_Timer.After(12, function()
        recipes.pruneMine()
        if ns.isOfficer and ns.isOfficer() then
          enqueue("Q|" .. serverTime()) -- collect online guildmates' recipes for an officer relay
          if ns.send then ns.send("PROFREQ|" .. serverTime(), "GUILD") end
        end
      end)
      C_Timer.After(45 + math.random(0, 60), function()
        local b = book()
        if b then recipes.shareMine() end
        pcall(recipes.remindUnread)
      end)
    end
  elseif event == "TRADE_SKILL_SHOW" or event == "TRADE_SKILL_UPDATE" or event == "TRADE_SKILL_LIST_UPDATE" then
    recipes.later("trade")
  elseif event == "CRAFT_SHOW" or event == "CRAFT_UPDATE" then
    recipes.later("craft")
  elseif event == "CHAT_MSG_ADDON" then
    local prefix, text, channel, sender = ...
    if not ns.comm.accept(prefix, text, channel, sender, PREFIX) then return end
    if ns.isSecret(prefix) or ns.isSecret(text) or ns.isSecret(sender) or prefix ~= PREFIX or channel ~= "GUILD" then return end
    if ns.normalizeName(sender) == ns.playerName() then return end
    onMessage(text, sender)
  end
end

-- The window fires many updates while it fills; read it once things settle.
local waiting = {}
function recipes.later(kind)
  if waiting[kind] then return end
  waiting[kind] = true
  if C_Timer and C_Timer.After then
    C_Timer.After(0.7, function() waiting[kind] = nil; scan(kind) end)
  else
    waiting[kind] = nil
    scan(kind)
  end
end

local frame = CreateFrame("Frame")
for _, event in ipairs({ "PLAYER_LOGIN", "TRADE_SKILL_SHOW", "TRADE_SKILL_UPDATE", "TRADE_SKILL_LIST_UPDATE", "CRAFT_SHOW", "CRAFT_UPDATE", "CHAT_MSG_ADDON" }) do
  -- Crafting events vary by client; unsupported alternatives are expected.
  local optional = event ~= "PLAYER_LOGIN" and event ~= "CHAT_MSG_ADDON"
  if ns.compat and ns.compat.registerEvent then ns.compat.registerEvent(frame, event, optional)
  else pcall(frame.RegisterEvent, frame, event) end
end
frame:SetScript("OnEvent", function(...)
  if ns.moduleActive and not ns.moduleActive("recipes") then return end -- /guilded modules
  local ok, err = pcall(onEvent, ...)
  if not ok and ns.logDiagnostic then ns.logDiagnostic("LUA_ERROR", "recipes: " .. tostring(err)) end
end)
